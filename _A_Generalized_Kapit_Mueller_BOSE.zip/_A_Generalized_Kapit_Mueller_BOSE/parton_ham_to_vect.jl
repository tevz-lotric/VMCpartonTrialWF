using LinearAlgebra

function get_vectors_for_ham(hamiltonian,number_vectors;number_uc_for_a_full_flux=1)
    # simply return the lowest eigenvectors...
    # for each element of H that crosses 

    fluxfactor = cis(2*π/number_uc_for_a_full_flux)

    # for x in 1:Nx, y in 1:Ny, z in 1:2
    #     for xp in 1:Nx, yp in 1:Ny, zp in 1:2
    #         li = (x-1)*Ny*2+(y-1)*2+z
    #         ri = (xp-1)*Ny*2+(yp-1)*2+zp

    #         # got to figure out if there should be a flux insertion and handle it!
    #         if []
                
    #         end
    #     end
    # end    

    val,us = eigen(hamiltonian)

    order = sortperm(val)
    partonvecs = [us[:,order[j]] for j in 1:number_vectors]

    return partonvecs,us[:,order]
end


# old one, can only do eg 1/2 flux per plaquette
# function get_factor_of_gauge(Nx,Ny,flux_per_uc)
#     ncomp = Nx*Ny*2

#     vals = ones(ComplexF64,(ncomp,ncomp))

#     for x in 1:Nx, y in 1:Ny, z in 1:2
#         for xp in 1:Nx, yp in 1:Ny, zp in 1:2
#             vals[(x-1)*Ny*2+(y-1)*2+z,(xp-1)*Ny*2+(yp-1)*2+zp]=cis(2*π*0.5*(x+xp)*(y-yp)*flux_per_uc)
#         end
#     end
#     return vals
# end
function get_best_path(start,finish,period)
    # returns best path from start to finish, given the period
    # path is allowed to wind around the torus, so it is periodic
    # start and finish are 1-indexed, so they are in [1,period]
    # returns a vector of integers, which are the path points
    # e.g. if start=1, finish=3, period=4, then
    # it returns [1,2,3] or [1,4,3]

    if start==finish
        return [start]
    end

    if start<finish
        if finish-start <= period/2 + 1e-3
            return collect(start:finish)
        else
            return vcat(collect(start:-1:1),collect(period:-1:finish))

        end
    else
        if start-finish <= period/2 + 1e-3
            return collect(start:-1:finish)
        else
            return vcat(collect(start:period),collect(1:finish))

        end
    end
end

# new one, it is supposed to be able to do any flux per plaquette f as long as f*Nx*Ny = integer.
function get_factor_of_gauge(Nx,Ny,flux_per_uc,UC_DIM) # set_of_fluxes is a vector of plaquettes which have pi-flux extra
    ncomp = Nx*Ny*UC_DIM


    vals = ones(ComplexF64,(ncomp,ncomp))

    for x in 1:Nx, y in 1:Ny, z in 1:UC_DIM
        for xp in 1:Nx, yp in 1:Ny, zp in 1:UC_DIM
            # so should interpret this as going x->xp,...
            # idea is to do x->xp, then y->yp and finally add a term to pretend you went along diagonal...
            
            xpath = get_best_path(x,xp,Nx)
            ypath = get_best_path(y,yp,Ny)

            dirx,diry=0,0

            if length(xpath)>1
                dirx = 1
                if mod(xpath[2]-xpath[1],Nx)>Nx/2
                    dirx = -1
                end
            end
            
            if length(ypath)>1
                diry= 1
                if mod(ypath[2]-ypath[1],Ny)>Ny/2
                    diry = -1
                end
            end

            angle = 0
            for (xl,xr) in zip(xpath[1:end-1],xpath[2:end])
                if xr==1 && xl==Nx
                    angle = angle + 2*π*flux_per_uc*y*Nx
                end
                if xr==Nx && xl==1
                    angle = angle - 2*π*flux_per_uc*y*Nx
                end
            end

            for (yl,yr) in zip(ypath[1:end-1],ypath[2:end])
                angle = angle - 2*π*flux_per_uc*xp*diry
            end

            # correction from the half-triangle...
            angle = angle+2*π*flux_per_uc*0.5*(length(ypath)-1)*(length(xpath)-1)*dirx*diry
            
            vals[(x-1)*Ny*UC_DIM+(y-1)*UC_DIM+z,(xp-1)*Ny*UC_DIM+(yp-1)*UC_DIM+zp]=cis(angle)

        end
    end
    

    if maximum(abs.(vals-vals'))>1e-6
        @warn "Gauge factor matrix is not hermitian, something is wrong!"
        return vals
    end

    return 0.5*(vals+vals') # make it hermitian, so that it is a gauge factor
end

# newest one, it is supposed to be able to do any flux pattern, as long as sum(fluxes)=integer
function get_factor_of_gauge_nonuniform(Nx,Ny,fluxes,dflt,UC_DIM) # the distances to know which fluxes to even care about...
    ncomp = Nx*Ny*UC_DIM

    vals = ones(ComplexF64,(ncomp,ncomp))

    for x in 1:Nx, y in 1:Ny, z in 1:UC_DIM
        for xp in 1:Nx, yp in 1:Ny, zp in 1:UC_DIM
            # so should interpret this as going x->xp,...
            # idea is to do x->xp, then y->yp and finally add a term to pretend you went along diagonal...
            
            xpath = get_best_path(x,xp,Nx)
            ypath = get_best_path(y,yp,Ny)

            dirx,diry=0,0

            if length(xpath)>1
                dirx = 1
                if mod(xpath[2]-xpath[1],Nx)>Nx/2
                    dirx = -1
                end
            end
            
            if length(ypath)>1
                diry= 1
                if mod(ypath[2]-ypath[1],Ny)>Ny/2
                    diry = -1
                end
            end

            angle = 0
            for (xl,xr) in zip(xpath[1:end-1],xpath[2:end])
                if xr==1 && xl==Nx
                    angle = angle + 2*π*sum(fluxes[:,1:y])
                end
                if xr==Nx && xl==1
                    angle = angle - 2*π*sum(fluxes[:,1:y])
                end
            end

            for (yl,yr) in zip(ypath[1:end-1],ypath[2:end])
                # take the bigger of the y's, unless its (1,Ny) or (Ny,1) in which case take 1
                righty = max(yl,yr)
                other = min(yl,yr)
                if righty==Ny && other==1
                    righty = 1
                end
                angle = angle - 2*π*sum(fluxes[1:xp,righty])*diry
            end

            # correction from the half-triangle... Now very convoluted because you have to be careful of which fluxes to take!
            # CURRENTLY A HIGHLY SIMPLIFIED IMPLEMENTATION RELYING ON THE FACT THAT YOU WILL NEVER DO A JUMP BY MORE THAN
            # (1,1) OR (2,0) UNIT-CELLS, EG NO JUMPS BY (2,1) OR (1,2) UNIT-CELLS (those are huge!)
            # in essence distance <~sqrt(10) is required! In reality <3 because unit-cells A,B are not at the same point...
            if abs(dirx*diry)>1e-6
                # just take the one point for all!
                righty = max(y,y+diry)
                if righty>Ny
                    righty = 1
                end

                rightx = max(x,x+dirx)
                if rightx>Nx
                    rightx = 1
                end

                angle = angle+2*π*fluxes[rightx,righty]*0.5*(length(ypath)-1)*(length(xpath)-1)*dirx*diry
            end
            


            vals[(x-1)*Ny*UC_DIM+(y-1)*UC_DIM+z,(xp-1)*Ny*UC_DIM+(yp-1)*UC_DIM+zp]=cis(angle)

        end
    end
    

    if maximum(abs.((vals.*dflt)-(vals.*dflt)'))>1e-6
        @warn "Gauge factor matrix is not hermitian, something is wrong!"
        return vals
    end

    return 0.5*(vals+vals') # make it hermitian, so that it is a gauge factor
end

# NOTE: IMPORTANTLY CHANGE THE WAY YOU DO ADAM TO HAVE THE 'MOMENTUM' ON H PARAMETERS
# should be better because eg if eigenvector ordering changes or something, those will all just break!!

function parton_ham_truncate_and_symmetrize(ham,distances,parton_MF_Ham_enforced_periods,parton_MF_Ham_max_range,Nx,Ny,UC_DIM)
    ham = ham.*(distances.<parton_MF_Ham_max_range)
    ham2 = zeros(ComplexF64,size(ham))
    N_components=size(ham)[1]

    # now symmetrize wrt shifts...
    xshiftlocs = 0:parton_MF_Ham_enforced_periods[1]:(Nx-1)
    yshiftlocs = 0:parton_MF_Ham_enforced_periods[2]:(Ny-1)

    
    for xshift in xshiftlocs, yshift in yshiftlocs
        # got to see how that re-orders the terms...
        order = zeros(Int64,N_components)
        for x in 1:Nx, y in 1:Ny, z in 1:UC_DIM
            xp = mod(x+xshift-1,Nx)+1
            yp = mod(y+yshift-1,Ny)+1
            order[(x-1)*Ny*UC_DIM+(y-1)*UC_DIM+z]=(xp-1)*Ny*UC_DIM+(yp-1)*UC_DIM+z
        end
        #@show order

        ham2 += ham[order,order]
    end

    # finally, simply multiply by

    return ham2/(length(xshiftlocs)*length(yshiftlocs))
end