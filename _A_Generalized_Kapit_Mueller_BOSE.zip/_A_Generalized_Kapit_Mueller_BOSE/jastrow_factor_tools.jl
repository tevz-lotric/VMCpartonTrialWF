
# jastrowfunct is a (dims[1] x dims[2] x dims[3]) x (dims[1] x dims[2] x dims[3]) array of numbers.
# You need to multiply in e^(-J[x,y]) for each pair (x,y) of physical particles.
# The full jastrowfunct factor SHOULD have constraints
# (1) The periodicity
# (2) Longest independent distance beyond which jastrowfunct = 0
# (3) J[x,y] = J[y,x]
# (4) J is always REAL!

function full_jastrow(Positions,jastrowfunct,dims) #
    fact = 1
    for (id,p1) in enumerate(Positions)
        for p2 in Positions[id+1:end]
            index1 = (p1[1]-1)*dims[2]*dims[3] + (p1[2]-1)*dims[3] + p1[3]
            index2 = (p2[1]-1)*dims[2]*dims[3] + (p2[2]-1)*dims[3] + p2[3]
            fact = fact*exp(-0.5*(jastrowfunct[index1,index2]+jastrowfunct[index2,index1]))
        end
    end
    return fact
end

function jastrow_update(mover_id,mover_newpos,Positions,jastrowfunct,dims)
    fact = 1
    mop = (Positions[mover_id][1]-1)*dims[2]*dims[3] + (Positions[mover_id][2]-1)*dims[3] + Positions[mover_id][3]
    mnp = (mover_newpos[1]-1)*dims[2]*dims[3] + (mover_newpos[2]-1)*dims[3] + mover_newpos[3]
    for (id,p) in enumerate(Positions)
        if id!=mover_id
            indexp = (p[1]-1)*dims[2]*dims[3] + (p[2]-1)*dims[3] + p[3]
            fact = fact*exp(-0.5*(jastrowfunct[indexp,mnp]+jastrowfunct[mnp,indexp])+0.5*(jastrowfunct[indexp,mop]+jastrowfunct[mop,indexp]))
        end
    end

    return fact
end

function jastrow_derivative(Positions,jastrowfunct,dims) # computes (1/psi) * (dpsi / dJ_xy)
    derivatives = zeros(Float64,size(jastrowfunct))
    for (id,p1) in enumerate(Positions)
        for p2 in Positions[id+1:end]
            index1 = (p1[1]-1)*dims[2]*dims[3] + (p1[2]-1)*dims[3] + p1[3]
            index2 = (p2[1]-1)*dims[2]*dims[3] + (p2[2]-1)*dims[3] + p2[3]
            derivatives[index1,index2] = -1
            derivatives[index2,index1] = -1
        end
    end
    return derivatives
end

function jastrow_truncate_and_symmetrize(jf,distances,jastrow_enforced_periods,jastrow_max_range,Nx,Ny,UC_DIM)
    jf = jf.*(distances.<jastrow_max_range)

    # can take all elements as real anyway
    jf = real.(jf)
    # and enforce Hermiticity!
    jf = 0.5*(jf+jf')

    jf2 = zeros(Float64,size(jf))
    N_components=size(jf)[1]

    # now symmetrize wrt shifts...
    xshiftlocs = 0:jastrow_enforced_periods[1]:(Nx-1)
    yshiftlocs = 0:jastrow_enforced_periods[2]:(Ny-1)

    
    for xshift in xshiftlocs, yshift in yshiftlocs
        # got to see how that re-orders the terms...
        order = zeros(Int64,N_components)
        for x in 1:Nx, y in 1:Ny, z in 1:UC_DIM
            xp = mod(x+xshift-1,Nx)+1
            yp = mod(y+yshift-1,Ny)+1
            order[(x-1)*Ny*UC_DIM+(y-1)*UC_DIM+z]=(xp-1)*Ny*UC_DIM+(yp-1)*UC_DIM+z
        end
        #@show order

        jf2 += jf[order,order]
    end

    # finally, simply divide out to make it nice in size! NOTE THAT NOW MAGNITUDE MATTERS HERE FOR JASTROWS!
    return jf2/(length(xshiftlocs)*length(yshiftlocs))
end