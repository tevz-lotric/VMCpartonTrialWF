include("optimizer_function.jl")
using UnicodePlots
using Distributed
using UnicodePlots
using DataFrames
using CSV
using ParallelDataTransfer
using ProgressMeter

#kill all uselss workers
if nprocs()>1 
    rmprocs(workers());
end
NRWS = 6#length(Sys.cpu_info())-2 # this should give #CPU cores!
# ACTUALLY ADD THE WORKERS
addprocs(NRWS-nprocs())

@everywhere number_workers=nprocs()
@everywhere include("WF_evaluation.jl")
@everywhere include("gradients_and_ham.jl")
@everywhere include("MonteCarloSampler.jl")
@everywhere include("parton_ham_to_vect.jl")
@everywhere include("jastrow_factor_tools.jl")
# START THE DATA HERE!

NUMBER_PARTONS_WANTED = 2
Wanted_Filling_Fraction = 1/2
# how much extra flux to add
Deviation_from_wanted_filling = 0

Wanted_NX = 6 # you ideally want this to be even if you will then do half-flux...
Wanted_NY = 8

# about the parton MF Hamiltonians...
parton_MF_Ham_max_range = 2.5#sqrt(2)+0.01 # furthest hop (physical distance) for partons you can tolerate. NN distance is =1.
parton_MF_Ham_enforced_periods = [1,1] # self-descriptionary really. In underlying bose units!
jastrow_enforced_periods = [1,1]
jastrowmax = 3.1#3.1#3.1#1.45 # max Jastrow factor range that is nonzero!
flux_per_uc = [1/2]#, 2/3] # Have to be positive seems like in this convention... +1/3 and -1/3 are not equivalent of course!
# trying a few things for nu=2/3 fermions too?

# of course only value mod 1 matters!

flux_pattern = [ fuc*ones(Wanted_NX,Wanted_NY) for fuc in flux_per_uc ]

# idk, see what's good if you do this!
# flux_pattern[1,1] -=0.5
# flux_pattern[4,2] -=0.5

@show total_flux = sum.(flux_pattern)
TF = round.(Int64,total_flux)

parton_gauge_charges = [[1,-1]]##,0],[0,1,-1]]
# gives MF fluxes [1/3, 1/3,-2/3]. Note that this is equivalent to all being eg 1/3
# point is that you can add 2π MF flux for free: the diagonal hoppings change, but all the changes are in 
# a translationally invariant way, so a re-definition of the MF hamiltonian saves all the issiues!


# note: careful with uc periodicity: eg for the thing to work [current code]
# at pi-flux per UC, you need each X,Y to be a multiple of 4!!
# maybe if you change your gauge definitions, all will be different...
# GAUGE DEF HAS CHANGED, SO ALL IS GOOD NOW!

if parton_MF_Ham_max_range>=3-1e-4
    @warn "You are using a very large parton MF Hamiltonian range ($parton_MF_Ham_max_range), which allows partons to jump by more than (2,1) unit-cells! Your flux implementation (if flux is not uniform) may be wrong!"
end

# if you want to read Hamiltonian
hamiltonian_read_file = "startinglogs/Hams_QUENCH_3_FLUX_[12]_,2partons,nu-0.5,HOFSTADER,V1_0_Vmodulated_0.005_UCSIZE_3x3_Size_4x6_hamcutoffdist_2.5_nrRuns_130.csv" #"logs/Hams_QUENCH_2_FLUX_[8, 16]_,3partons,nu-0.3333333333333333,HOFSTADER,V1_6_Vmodulated_0.005_UCSIZE_3x3_Size_6x4_hamcutoffdist_2.5_nrRuns_75.csv"

# REGARDLESS OF THE HAMILTONIANS, THE PROGRAM WILL CUT OFF/SYMMETRIZE AS DICTATED ABOVE!

# ideally want Wanted_Filling_Fraction * NX to be an integer so that you will be able to do something nice later on!
worker = Dict("runs_per_worker"=>1500,"warmups_per_worker"=>250)

# HOFSTADER HAMILTONIAN DETAILS!

# NN INTERACTION
v1_value = 0
# This hopefully matches what the ED code does...

# UNIT-CELL SIZE. (Flux is 1/dxdx)
dx,dy=3,3

# STRENGTH OF MODULATION (modulates between +Vm,-Vm)
# will be related to anyon dispersion, etc
Vm = 0.005




# note: initial way code was written was in disagreement with how DiagHam counts interactions for this model!
# so now simply putting in 2*V1, looks like DiagHam uses a convention which double-counts for some reason!
hamiltonian = Dict("name" => "Hofstader","dx"=>dx,"dy"=>dy,"NX"=>Wanted_NX, "NY"=>Wanted_NY,  "V1" => v1_value,"NR_PARTICLES"=>round(Int64,Wanted_Filling_Fraction*Wanted_NY*Wanted_NX+Deviation_from_wanted_filling),"Vm"=>Vm)

adamS_LIST = [
    Dict("Optimizer_steps"=>75, "Learn_rate"=>0.05, "beta1"=>0.9, "beta2"=>0.999, "epsilon"=>1e-5),
    Dict("Optimizer_steps"=>75, "Learn_rate"=>0.03, "beta1"=>0.9, "beta2"=>0.999, "epsilon"=>1e-5),
    Dict("Optimizer_steps"=>130, "Learn_rate"=>0.02, "beta1"=>0.9, "beta2"=>0.999, "epsilon"=>1e-5),
    # Dict("Optimizer_steps"=>140, "Learn_rate"=>0.01, "beta1"=>0.9, "beta2"=>0.999, "epsilon"=>1e-5),
    # Dict("Optimizer_steps"=>100, "Learn_rate"=>0.01, "beta1"=>0.9, "beta2"=>0.999, "epsilon"=>1e-5),
    # Dict("Optimizer_steps"=>100, "Learn_rate"=>0.01, "beta1"=>0.9, "beta2"=>0.999, "epsilon"=>1e-5),
    # Dict("Optimizer_steps"=>100, "Learn_rate"=>0.006, "beta1"=>0.9, "beta2"=>0.999, "epsilon"=>1e-5),
   #Dict("Optimizer_steps"=>1, "Learn_rate"=>0.003, "beta1"=>0.9, "beta2"=>0.999, "epsilon"=>1e-5, "nr_runs_per_worker"=> 80000, "record_data" => true) #the final run to collect good data!
]

# adamS_LIST = [
#     Dict("Optimizer_steps"=>15, "Learn_rate"=>0.05, "beta1"=>0.9, "beta2"=>0.999, "epsilon"=>1e-5),
#     Dict("Optimizer_steps"=>3, "Learn_rate"=>0.05, "beta1"=>0.9, "beta2"=>0.999, "epsilon"=>1e-5),
# ]


N_bose = hamiltonian["NR_PARTICLES"]

println("Doing $(N_bose) particles on a $(Wanted_NX)x$(Wanted_NY) = $(Wanted_NX*Wanted_NY) grid, so filling is $(N_bose/(Wanted_NX*Wanted_NY)).")
println("Generalized Kapit-Mueller model on (dx,dy)=($dx,$dy). NN interaction is $v1_value. Modulation is by $Vm.")

N_components = hamiltonian["NX"]*hamiltonian["NY"]*dx*dy # hard coded the *2 for two original bosonic bands....
dims = [hamiltonian["NX"],hamiltonian["NY"],dx*dy,NUMBER_PARTONS_WANTED]

distances = get_HH_distances(dx,dy,hamiltonian["NX"],hamiltonian["NY"])

xshiftlocs = 0:parton_MF_Ham_enforced_periods[1]:(hamiltonian["NX"]-1)
yshiftlocs = 0:parton_MF_Ham_enforced_periods[2]:(hamiltonian["NY"]-1)

nrparams_nosym = sum((distances.<parton_MF_Ham_max_range)) # offdiags are counted twice, but
how_many_restrictions = length(xshiftlocs)*length(yshiftlocs)

nindeprealparams=nrparams_nosym/how_many_restrictions
println("Distance cutoff $parton_MF_Ham_max_range and H periodicity $(parton_MF_Ham_enforced_periods): have $nindeprealparams free real parameters!")

global partonHams = []

for _ in 1:NUMBER_PARTONS_WANTED
    random_ahh_ham = randn(ComplexF64,(N_components,N_components))
    # hermitize
    random_ahh_ham = (random_ahh_ham+random_ahh_ham')
    
    random_ahh_ham=parton_ham_truncate_and_symmetrize(random_ahh_ham,distances,parton_MF_Ham_enforced_periods,parton_MF_Ham_max_range,hamiltonian["NX"],hamiltonian["NY"],hamiltonian["dx"]*hamiltonian["dy"])

    push!(partonHams, random_ahh_ham)
end

dims = [hamiltonian["NX"],hamiltonian["NY"],dx*dy]
nc = prod(dims)

if !isnothing(hamiltonian_read_file)
    println("Reading parton MF from $hamiltonian_read_file")
    # read the whatever is given. If the given is too big, just ignore some elements!
    partonHams = [zeros(ComplexF64,(N_components,N_components)) for _ in 1:NUMBER_PARTONS_WANTED]

    pdf = CSV.read(hamiltonian_read_file,DataFrame)
    #make it consistent with
    for r in eachrow(pdf)
        pid = r.Parton
        x,y,z=parse.(Int64,split(r.Start[2:end-1],", "))
        xp,yp,zp=parse.(Int64,split(r.End[2:end-1],", "))
        amp = parse(ComplexF64,r.Amplitude)

        iL=(xp-1)*dims[2]*dims[3]+(yp-1)*dims[3]+zp
        iR=(x-1)*dims[2]*dims[3]+(y-1)*dims[3]+z
        partonHams[pid][mod(iL-1,nc)+1,mod(iR-1,nc)+1]=amp
    end

    for p in 1:NUMBER_PARTONS_WANTED
        partonHams[p]=parton_ham_truncate_and_symmetrize(partonHams[p],distances,parton_MF_Ham_enforced_periods,parton_MF_Ham_max_range,hamiltonian["NX"],hamiltonian["NY"],hamiltonian["dx"]*hamiltonian["dy"])
    end
end

global jastrowfunct = 0.3*randn(Float64,(N_components,N_components)) # make them relatively small to sstart with I guess...
jastrowfunct = jastrow_truncate_and_symmetrize(jastrowfunct,distances,jastrow_enforced_periods,jastrowmax,dims[1],dims[2],dims[3])


slowstart = -1
if !isnothing(hamiltonian_read_file)
    slowstart=10 # so no updates for first 10 rounds of first optimizer to get a good adam...
end

println("Starting optimizer...")
# initial one to find good positions....
dfe, partonHams,jastrowfunct,positions, adam_steps,mt,vt = run_optimizer(adamS_LIST[1],hamiltonian,worker,partonHams,jastrowfunct,"QUENCH_1_FLUX_$(TF)_",distances,parton_MF_Ham_enforced_periods,parton_MF_Ham_max_range,jastrow_enforced_periods,jastrowmax,which_hamiltonian=hamiltonian["name"],start_slow=slowstart,flux_pattern=flux_pattern,parton_charges = parton_gauge_charges);
@show mean(dfe.Real_Energy)


counter = 1

for adam in adamS_LIST[2:length(adamS_LIST)]
    record_corr = false
    if haskey(adam, "record_data")
        record_corr = true
    end

    workerc = copy(worker)
    if haskey(adam, "nr_runs_per_worker")
        workerc["runs_per_worker"]=adam["nr_runs_per_worker"]
    end
    
    global counter+=1 # just to have differning filenames!


    c_dfe, c_partonHams,c_jastrowfunct,c_positions,c_adam_steps,c_mt,c_vt = run_optimizer(adam,hamiltonian,workerc,partonHams,jastrowfunct,"QUENCH_$(counter)_FLUX_$(TF)_",distances,parton_MF_Ham_enforced_periods,parton_MF_Ham_max_range,jastrow_enforced_periods,jastrowmax,which_hamiltonian = hamiltonian["name"],startingPos = positions,record_corr=record_corr,adam_nr_done=adam_steps,adam_previous_m=mt,adam_previous_v=vt,flux_pattern=flux_pattern,parton_charges = parton_gauge_charges);

    global adam_steps = c_adam_steps
    global mt = deepcopy(c_mt)
    global vt = deepcopy(c_vt)

    global partonHams = deepcopy(c_partonHams)
    global jastrowfunct = deepcopy(c_jastrowfunct)
    global positions = deepcopy(c_positions)
    global dfe = deepcopy(c_dfe)
    @show mean(dfe.Real_Energy)
end

# clean up workers once done
if nprocs()>1 
    rmprocs(workers());
end

# to visualise what jastrows do 
# dvec = vec(distances);
# jvec = vec(jastrowfunct);
# using Plots
# using LaTeXStrings
# Plots.scatter(dvec[dvec.>0.01],jvec[dvec.>0.01],xlabel=L"Distance $d(x,y)$",ylabel=L"Jastrow $J(x,y)$",title=L"Factor is $e^{-J(x,y)}$",label="V1=$v1_value")

# plotval = mean(dfe.Real_Energy)*N_bose - v1_value


# dvec = vec(distances);
# jvec = vec(jastrowfunct);
# using Plots
# using LaTeXStrings
# ax=Plots.scatter(dvec[dvec.>0.01],exp.(-jvec[dvec.>0.01]),xlabel=L"Distance $d(x,y)$",ylabel=L"Jastrow $f(x,y)$",label="V1=$v1_value")
# Plots.savefig(ax,"jastrow_v1_$(round(v1_value,digits=3))_v2_$(round(v2_value,digits=3)).pdf")