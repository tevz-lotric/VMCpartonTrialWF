include("WF_evaluation.jl")
include("gradients_and_ham.jl")
@everywhere include("jastrow_factor_tools.jl")

using Distributed

using ProgressMeter

# Given current wavefunction parameters and some initial position,
# sample Monte Carlo and return the objects of interest for the optimizer.
# also return the position where you end up...
@everywhere function MC_sample(NR_RUNS,NR_WARMUP,initial_positions,partonWFs,jastrows,dims,validMoves,interactions,determinant_scale_factor;INVERSE_SMALL_UPDATE_LIMIT = 15)



    L = length(initial_positions)
    Number_Partons = length(partonWFs)

    NR_X_Cells = dims[1]
    NR_Y_Cells = dims[2]

    PSI_MAGNITUDE_LOG = 0
    NR_PSI_MAG_LOGGED = 0

    # keep the only relevant cumulants - conjugated gradient and energy
    eConjgradCum = zeros(ComplexF64,(Number_Partons,L,dims[1]*dims[2]*dims[3]))
    gradCum =  zeros(ComplexF64,(Number_Partons,L,dims[1]*dims[2]*dims[3]))


    eCum = 0.0 + 0.0*im
    
    Pos = deepcopy(initial_positions)

    currEconjG =  zeros(ComplexF64,(Number_Partons,L,dims[1]*dims[2]*dims[3]))
    currG =  zeros(ComplexF64,(Number_Partons,L,dims[1]*dims[2]*dims[3]))
    numbercomponents = prod(dims[1:3])
    currJG = zeros(ComplexF64,(numbercomponents,numbercomponents))
    currEconjJG = zeros(ComplexF64,(numbercomponents,numbercomponents))
    JastrowGradCum = zeros(ComplexF64,(numbercomponents,numbercomponents))
    eJastrowCgradCum = zeros(ComplexF64,(numbercomponents,numbercomponents))

    currE = 0.0 + 0.0*im
    currPsi = 0.0 + 0.0*im


    pinverses = []
    for _ in 1:length(partonWFs)
        push!(pinverses,Matrix(I,L,L)*(1+0.0*im))
    end
    


    # if you did NOT make a move!
    USE_OLD_VALS = false 


    # only start cumulating AFTER you reach a nonzero psi
    NR_CUMULATED = 0

    NX=dims[1]
    NY=dims[2]
    buc=dims[3]

    bosonCumulant = zeros(ComplexF64,(NX,NY,buc,NX,NY,buc))
    densityCumulant = zeros(Float64,(NX,NY,buc,NX,NY,buc))

    bc = zeros(ComplexF64,(NX,NY,buc,NX,NY,buc))
    dc = zeros(Float64,(NX,NY,buc,NX,NY,buc))

    get_psi_from_scratch = true

    number_done_by_small_update = 0

    mover_identity = 0
    mover_old_pos = [0,0,0]
    
    # NEED TO ADD:
    # (1) A COUNTER OF HOW MANY 'SMALL' UPDATES YOU HAVE DONE


    for ind in 1:(NR_RUNS+NR_WARMUP)
        if !USE_OLD_VALS


            if get_psi_from_scratch
                currPsi,pinverses = parton_WF_and_inverse(Pos,partonWFs,jastrows,dims,parton_rescale_factor=determinant_scale_factor)
                get_psi_from_scratch = false
                number_done_by_small_update=0
                    
            else
                currPsi,pinverses = parton_WF_and_inverse_from_old(mover_identity,Pos[mover_identity],mover_old_pos,currPsi,pinverses,partonWFs,jastrows,Pos,dims)
                #currPsi2,pinverses2 = parton_WF_and_inverse(Pos,partonWFs,dims,parton_rescale_factor=determinant_scale_factor)
                
                # max_in_diff=0
                # for (p1i, p2i) in zip(pinverses,pinverses2)
                #     differences_in_inverses = abs.(p1i-p2i)/((abs.(p1i)+abs.(p2i)))

                #     max_in_diff=max(max_in_diff,maximum(differences_in_inverses))

                # end

                # if number_done_by_small_update>95 && rand()<0.001
                #     println("Rel inverse dif: $max_in_diff")
                # end
                number_done_by_small_update+=1
                if number_done_by_small_update>INVERSE_SMALL_UPDATE_LIMIT
                    get_psi_from_scratch = true
                end
            end

            PSI_MAGNITUDE_LOG += abs(currPsi)
            NR_PSI_MAG_LOGGED +=1


            ham = full_hop_ham_FAST(Pos,partonWFs,pinverses,validMoves,jastrows,dims) + full_interaction_HAM(Pos,interactions,dims)
            indices, grads = get_gradients_Fast(Pos,pinverses,dims)
            # have grads[j,pid] being the vector of gradients of orbital j, parton pid
            currE = ham
            for j in 1:L, pid in 1:Number_Partons
                currEconjG[pid,j,:]=conj.(grads[j,pid]).*ham
                currG[pid,j,:]=grads[j,pid]
            end

            #bc, dc = get_all_cumulants(Pos,partonWFs,pinverses,dims)
                
            # do a thing for Jastrow grads here! 
            currJG = jastrow_derivative(Pos,jastrows,dims)
            currEconjJG = conj.(currJG).*ham
        end

        #cumulate if Psi is nonzero nd you have done enough warmup...
        if !iszero(currPsi) && ind>NR_WARMUP
            eConjgradCum+=currEconjG
            gradCum+=currG
            eCum+=currE
            NR_CUMULATED+=1

            bosonCumulant+=bc
            densityCumulant+=dc
            # cumulate also Jastrow grads here
            JastrowGradCum +=currJG
            eJastrowCgradCum +=currEconjJG
        end

        # now decide on a move, do it MAYBE.
        p_mover_identity = rand(1:L)

        Dx=rand(-2:2)
        Dy=rand(-2:2)

        newID = rand(1:dims[3])
        
        # to ensure it is not the same as before...

        while (abs(Dx)<0.5 && abs(Dy)<0.5 && abs(newID-Pos[p_mover_identity][3])<0.5)
            Dx=rand(-2:2)
            Dy=rand(-2:2)

            newID = rand(1:dims[3])
        end


        newX = (NR_X_Cells-1+Pos[p_mover_identity][1]+Dx)%NR_X_Cells+1
        newY = (NR_Y_Cells-1+Pos[p_mover_identity][2]+Dy)%NR_Y_Cells+1

        # now need to cumpute the WF ratio after this move
        fullratio=jastrow_update(p_mover_identity,[newX,newY,newID],Pos,jastrows,dims)

        newFullID = (newX-1)*dims[2]*dims[3]+(newY-1)*dims[3]+newID

        for pid in 1:length(partonWFs)
            
            vecP = map(j->partonWFs[pid][j][newFullID],1:length(Pos))
            pRatio = transpose(pinverses[pid][:,p_mover_identity])*vecP
            fullratio*=abs(pRatio)
        end
        

        if isnan(fullratio) # if currPsi was zero...
            fullratio=1
        end


        if rand()<fullratio^2
            # make the move
            USE_OLD_VALS=false # obviously need to compute now
            mover_old_pos = Pos[p_mover_identity]
            Pos[p_mover_identity]=[newX,newY,newID]
            mover_identity=p_mover_identity
        else
            # no move, so just remember that to not wast time re-computing
            USE_OLD_VALS = true
        end
    end
    
    #=
    Fs = eConjgradCum/NR_CUMULATED - (eCum/NR_CUMULATED)*(conj(gradCum)/NR_CUMULATED)
    EvOfE = eCum/NR_CUMULATED
    S = varGradCum/NR_CUMULATED - ((conj(gradCum))*conj(gradCum)')/(NR_CUMULATED^2)
    =#
    
    # FOR THIS SECOND PART, NEED TO CONJUGATE FIRST... BECAUSE THE ' ALREADY CONJUGATES...
    return NR_CUMULATED,eCum, gradCum,eConjgradCum, Pos, PSI_MAGNITUDE_LOG/NR_PSI_MAG_LOGGED, bosonCumulant, densityCumulant, JastrowGradCum, eJastrowCgradCum
end

#= 
Now set up some random vectors and positions to see what this thing returns... 
=#

#=
MaxX=4# how many unit cells each way

MaxY=4
NR_UNIT_CELLS = MaxX*MaxY # equals to the number of BOSONS!


# just to try stuff out
RMAT = rand(Int64,(NR_UNIT_CELLS,3))
Positions = deepcopy([RMAT[i,:] for i in 1:size(RMAT,1)])
function goodform(v)
    v[1]=abs((v[1]-1)%MaxX) + 1
    v[2]=abs((v[2]-1)%MaxY) + 1
    v[3]=abs((v[3]-1)%4) + 1
end
map(goodform,Positions)

# ACTUALLY JUST FIX POSITIONS REASONABLY TO START IN A GOOD, NOT HARD-CORE STATE
for a in 1:MaxX
    for b in 1:MaxY
        Positions[(a-1)*MaxY+b][1]=a
        Positions[(a-1)*MaxY+b][2]=b
    end
end       


Rs = randn((NR_UNIT_CELLS,4))+im*randn((NR_UNIT_CELLS,4))
Parton1VecMC = [Rs[i,:] for i in 1:size(Rs,1)]

Rs = randn((NR_UNIT_CELLS,4))+im*randn((NR_UNIT_CELLS,4))
Parton2VecMC = [Rs[i,:] for i in 1:size(Rs,1)]


# SHOULD NOT BE RANDOM BUT WHO CARES...
Ms = pi*randn((NR_UNIT_CELLS,2))
momenta = [Ms[i,:] for i in 1:size(Ms,1)]


get_WF(Positions,Parton1VecMC,Parton2VecMC,momenta)



# RUN THE MC AND SEE WHAT HAPPENS!
NewPos = deepcopy(Positions)

NR_CUMULATED,E,G,EG,VG,NewPos = MC_sample(convert(Int64,200),20,NewPos,Parton1VecMC,Parton2VecMC,momenta,MaxX,MaxY)

=#