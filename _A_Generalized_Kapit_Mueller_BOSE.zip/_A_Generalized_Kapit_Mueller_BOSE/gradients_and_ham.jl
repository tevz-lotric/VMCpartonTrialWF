include("WF_evaluation.jl")
using BenchmarkTools
using LinearAlgebra

# now FAST gradients - should also have parton inverse matrices as inputs! Note: returns gradients/Psi!!
function get_one_gradient_FAST(which_component,positions::Vector{Vector{Int64}},invPartons,dims)
    orbital_index = which_component["orbital_index"]
    partonID = which_component["parton"]


    # since each 'f' appears only once in each term of the expansion, this is the way to take the gradient wrt components
    grads = zeros(ComplexF64,dims[1]*dims[2]*dims[3])


    for j in 1:length(positions)
        pos = positions[j]

        index =(pos[1]-1)*dims[2]*dims[3]+(pos[2]-1)*dims[3]+pos[3]
        # need to dot the vector where there only is a 1 if the position coindides with positions[j].
        # So really (due to hard-core) this is only one element of the inverse matrix....
        grads[index]=invPartons[partonID][orbital_index,j]
    end
    return grads
end
# use the Fast gradient function. AGAIN THE RETURN IS DIVIDED BY OVERALL WF ALREADY!
function get_gradients_Fast(positions::Vector{Vector{Int64}},invPartons,dims)
    L = length(positions) # the number of components

    identifiers = [Dict("orbital_index"=>orbind, "parton"=>pid) for orbind in 1:L, pid in 1:length(invPartons)]

    gradients = map(x -> get_one_gradient_FAST(x,positions,invPartons,dims),identifiers)

    return identifiers,gradients
end


# this encodes the BOSONIC Hamiltonian ----------------------------------------------------------------------

# should be a list of moves: each move is [Ending_IND,Starting_IND,EndX-StartX,EndY-StartY, AMPLITUDE]
# sorted by STARTING_IND
# note the amplitude should include the overall (-1) factor in front!

# the valid moves now have only two valid i
function get_valid_moves_hex(t,tprime,tpp)

    valid_moves = [
        Dict("End" => 1, "Start" => 1, "Dx" => 0, "Dy" => 1,"amplitude"=>-conj(tprime)), #OK
        
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => 0,"amplitude"=>-t), #OK
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => 1,"amplitude"=>-tpp), #OK
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => -1,"amplitude"=>-tpp), #OK

        Dict("End" => 2, "Start" => 1, "Dx" => -2, "Dy" => 1,"amplitude"=>-tpp), #OK

        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => 0,"amplitude"=>-tprime), #OK
        Dict("End" => 1, "Start" => 1, "Dx" => -1, "Dy" => 1,"amplitude"=>-tprime), #OK

        
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => 0,"amplitude"=>-t), #OK
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => 1,"amplitude"=>-t), #OK

        Dict("End" => 2, "Start" => 2, "Dx" => 0, "Dy" => 1,"amplitude"=>-tprime), #OK

        Dict("End" => 2, "Start" => 2, "Dx" => -1, "Dy" => 1,"amplitude"=>-conj(tprime)), #OK
        Dict("End" => 2, "Start" => 2, "Dx" => -1, "Dy" => 0,"amplitude"=>-tprime), #OK
    ]

    # Now ensure this is hermitian [ADD REVERSE MOVES!]
    L = length(valid_moves)
    for moveID in 1:L #have to do this, otherwise you get an infinite loop...
        move = valid_moves[moveID]
        reverseDir = Dict("Start"=>move["End"],"End"=>move["Start"],"Dx"=>-move["Dx"],"Dy"=>-move["Dy"],"amplitude"=>conj(move["amplitude"]))
        #print(reverseDir)
        push!(valid_moves,reverseDir)
    end

    sort!(valid_moves,by=x->x["End"]) # sort by the end of the move...

    return valid_moves
end


function get_valid_moves_checkerboard(t,t1p,t2p,tpp)
    # from [42] with a (-1) sign to make flatband the bottom!

    valid_moves = [
        # first NN
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => 0,"amplitude"=>conj(t))
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => 0,"amplitude"=>t)
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => -1,"amplitude"=>t)
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => -1,"amplitude"=>conj(t))
        # this is NNN        
        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => 0,"amplitude"=>t1p)
        Dict("End" => 1, "Start" => 1, "Dx" => 0, "Dy" => 1,"amplitude"=>t2p)
        Dict("End" => 2, "Start" => 2, "Dx" => 1, "Dy" => 0,"amplitude"=>t2p)
        Dict("End" => 2, "Start" => 2, "Dx" => 0, "Dy" => 1,"amplitude"=>t1p)
        # finally NNNN 
        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => 1,"amplitude"=>tpp)
        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => -1,"amplitude"=>tpp)
        Dict("End" => 2, "Start" => 2, "Dx" => 1, "Dy" => 1,"amplitude"=>tpp)
        Dict("End" => 2, "Start" => 2, "Dx" => 1, "Dy" => -1,"amplitude"=>tpp)
    ]

    # Now ensure this is hermitian [ADD REVERSE MOVES!]
    L = length(valid_moves)
    for moveID in 1:L #have to do this, otherwise you get an infinite loop...
        move = valid_moves[moveID]
        reverseDir = Dict("Start"=>move["End"],"End"=>move["Start"],"Dx"=>-move["Dx"],"Dy"=>-move["Dy"],"amplitude"=>conj(move["amplitude"]))
        #print(reverseDir)
        push!(valid_moves,reverseDir)
    end

    sort!(valid_moves,by=x->x["End"]) # sort by the end of the move...

    return valid_moves
end

# END of bosonic Hamiltonian definition ----------------------------------------------------------------------
function get_uc_ind(X,Y,In,dims)
    while X<1
        X=X+dims[1]
    end
    while X>dims[1]
        X=X-dims[1]
    end
    while Y<1
        Y=Y+dims[2]
    end
    while Y>dims[2]
        Y=Y-dims[2]
    end

    return (X-1)*dims[2]*dims[3]+(Y-1)*dims[3]+In
end


# NOW DO THE 'FAST' ONE!! RETURNS (H PSI) / PSI !!
function ham_move_one_FAST(ID_of_mover,positions,partons,parton_inverses,validMoves,jastrows,dims)
    Hamvalue = 0.0 + 0.0*im
    pos_in_UC = positions[ID_of_mover][3]
    origX = positions[ID_of_mover][1]
    origY = positions[ID_of_mover][2]

    for move in validMoves
        if pos_in_UC == move["End"] # assumes only two basis points, '1' and '2'

            # need to do this because the hamiltonian only has one unit cell's worth of terms!
            currUC=move["Start"]
            currX=mod(origX-round(Int64,move["Dx"])-1,dims[1])+1 # - sign as the otherpos is start and positions is end...
            currY=mod(origY-round(Int64,move["Dy"])-1,dims[2])+1
            # now do the mod Nx
            
            fullIndex = get_uc_ind(currX,currY,currUC,dims)

            # now get the relative WF value... for each parton...
            WFratio = jastrow_update(ID_of_mover,[currX,currY,currUC],positions,jastrows,dims)
            for np in 1:length(partons)
                vecParton = map(j->partons[np][j][fullIndex],1:length(positions))
                ratioP = transpose(parton_inverses[np][:,ID_of_mover])*vecParton
                WFratio=WFratio*ratioP
            end

            Hamvalue+=move["amplitude"]*WFratio
        end
    end
    return Hamvalue
end

# a fast H on Psi. Note that this one returns (Hamiltonian on Psi ) / Hamiltonian 
function full_hop_ham_FAST(positions::Vector{Vector{Int64}}, partons,parton_inverses,validMoves,jastrows,dims)
    allHams = map(x->ham_move_one_FAST(x,positions,partons,parton_inverses,validMoves,jastrows,dims),1:length(positions))
    # always look at energy per particle... Should not be the biggest deal ever, just a scale factor!
    return sum(allHams)/length(positions)
end

# do function which give the ONE-SIDED interaction terms..

function nicemod(x,M)
    return sign(x)* ( (abs(x)+3*M/2)%M -M/2)
end


# do an interaction one
function full_interaction_HAM(positions::Vector{Vector{Int64}}, interaction_terms, dims) # WF doesnt matter here if you assume your Monte Carlo is sampling correctly
    # Take both positions, check if their locations are meant to interact, add the interaction strength to the cumulant
    ham_cumulant = 0.0
    
    L = length(positions)

    for a in 1:L, b in 1:L, int in interaction_terms
        diffX = positions[a][1]-positions[b][1]
        diffY = positions[a][2]-positions[b][2]

        startUC = positions[b][3]
        endUC = positions[a][3]

        
        if iszero(nicemod(diffX,dims[1])-int["dx"]) && iszero(nicemod(diffY,dims[2])-int["dy"]) && iszero(startUC-int["startIND"]) && iszero(endUC-int["endIND"])
            ham_cumulant+=int["Strength"]
        end
    end
    return ham_cumulant/L # DOUBLE CHECK - IS THIS THE NORMALIZATION YOU WANT?
end

function get_interactions_checkerboard(V1,V2) # MAKE IT ONE-WAY ONLY! FUNCTIOJN ABOVE SYMMETRIZES ANYWAY!
    valid_moves = [
        Dict("startIND" => 1, "endIND" => 2, "dx" => 0, "dy" => 0,"Strength"=>V1),
        Dict("startIND" => 1, "endIND" => 2, "dx" => -1, "dy" => 0,"Strength"=>V1),
        Dict("startIND" => 1, "endIND" => 2, "dx" => 0, "dy" => -1,"Strength"=>V1),
        Dict("startIND" => 1, "endIND" => 2, "dx" => -1, "dy" => -1,"Strength"=>V1),

        Dict("startIND" => 1, "endIND" => 1, "dx" => 1, "dy" => 0,"Strength"=>V2),
        Dict("startIND" => 1, "endIND" => 1, "dx" => 0, "dy" => 1,"Strength"=>V2),
        Dict("startIND" => 2, "endIND" => 2, "dx" => 1, "dy" => 0,"Strength"=>V2),
        Dict("startIND" => 2, "endIND" => 2, "dx" => 0, "dy" => 1,"Strength"=>V2)
    ]

    return valid_moves
end

function get_interactions_hex(V1,V2) # MAKE IT ONE-WAY ONLY! FUNCTIOJN ABOVE SYMMETRIZES ANYWAY!
    valid_moves = [

        Dict("endIND" => 2, "startIND" => 1, "dx" => 0, "dy" => 0,"Strength"=>V1),
        Dict("endIND" => 2, "startIND" => 1, "dx" => -1, "dy" => 0,"Strength"=>V1),
        Dict("endIND" => 2, "startIND" => 1, "dx" => -1, "dy" => 1,"Strength"=>V1),

        Dict("endIND" => 1, "startIND" => 1, "dx" => 1, "dy" => 0,"Strength"=>V2),
        Dict("endIND" => 1, "startIND" => 1, "dx" => -1, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 1, "startIND" => 1, "dx" => 0, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 2, "startIND" => 2, "dx" => 0, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 2, "startIND" => 2, "dx" => -1, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 2, "startIND" => 2, "dx" => -1, "dy" => 0,"Strength"=>V2)
    ]

    return valid_moves
end

function get_all_cumulants(positions::Vector{Vector{Int64}}, partons,parton_inverses,dims)
    # should compute all bosonic expectations + all density-density correlations!
    L = length(positions)

    NX=dims[1]
    NY=dims[2]
    buc=dims[3]

    bosonCumulant = zeros(ComplexF64,(NX,NY,buc,NX,NY,buc))
    densityCumulant = zeros(Float64,(NX,NY,buc,NX,NY,buc))

    for j in 1:L
        for currX in 1:NX, currY = 1:NY, currUC=1:buc
            currInd = (currX-1)*NY*buc+(currY-1)*buc + currUC

            ratio = 1+0*im
            for pid in 1:length(partons)
                vecP = map(j->partons[pid][j][currInd],1:length(positions))
                ratio  = ratio*transpose(parton_inverses[pid][:,j])*vecP
            end
            
            bosonCumulant[ positions[j][1], positions[j][2],positions[j][3], currX,currY,currUC ] += ratio
        end

        for m in 1:L
 
            densityCumulant[positions[j][1], positions[j][2],positions[j][3],positions[m][1], positions[m][2],positions[m][3]]+=1
        end
    end

    return bosonCumulant, densityCumulant

end

function get_checkerboard_distances_matrix(Nx,Ny)
    distances = zeros(Float64,(Nx*Ny*2,Nx*Ny*2))

    unitcell_locations = [[0,0],[1,1]/sqrt(2)]
    uc_vectors = [[sqrt(2),0],[0,sqrt(2)]]
    nuc = length(unitcell_locations)

    bigshifts = [[0,0],Nx*uc_vectors[1],Ny*uc_vectors[2],Nx*uc_vectors[1]+Ny*uc_vectors[2],Nx*uc_vectors[1]-Ny*uc_vectors[2]]

    for jx in 1:Nx, jy in 1:Ny, juc in 1:nuc
        for kx in 1:Nx, ky in 1:Ny, kuc in 1:nuc
            
            j = (jx-1)*Ny*nuc+(jy-1)*nuc+juc
            k = (kx-1)*Ny*nuc+(ky-1)*nuc+kuc

            jcoords = jx*uc_vectors[1]+jy*uc_vectors[2]+unitcell_locations[juc]
            kcoords = kx*uc_vectors[1]+ky*uc_vectors[2]+unitcell_locations[kuc]

            dist = Inf
            for bs in bigshifts
                dn = min(norm(jcoords+bs-kcoords),norm(jcoords-bs-kcoords))
                if dn<dist
                    dist=dn
                end
            end
            distances[j,k]=dist
        end
    end

    return distances
end


# Vm generates a BG potential. The idea is to do sth like (cos(2pi xuc/dx) + cos(2pi yuc/dy)) which makes the thing as smooth as possible 
function create_HH_hops_and_interactions(dx,dy,IntStrength;Vm=nothing)
    hops = []
    interactions = []

    for xuc in 1:dx, yuc in 1:dy
        # first the x hop
        id = dy*(xuc-1)+yuc
        hopped_id = dy*mod(xuc,dx)+yuc

        if hopped_id>id
            push!(hops,Dict("Start"=>id,"End"=>hopped_id,"Dx"=>0,"Dy"=>0,"amplitude"=>1))
            push!(interactions,Dict("startIND"=>id,"endIND"=>hopped_id,"dx"=>0,"dy"=>0,"Strength"=>IntStrength))
        else # so you jumped across unitcell
            # + get a phase
            push!(hops,Dict("Start"=>id,"End"=>hopped_id,"Dx"=>1,"Dy"=>0,"amplitude"=>cis(-2*π*yuc/dy)))
            push!(interactions,Dict("startIND"=>id,"endIND"=>hopped_id,"dx"=>1,"dy"=>0,"Strength"=>IntStrength))

        end

        # now the y hop
        hopped_id = dy*(xuc-1)+mod(yuc,dy)+1
        if hopped_id>id
            push!(hops,Dict("Start"=>id,"End"=>hopped_id,"Dx"=>0,"Dy"=>0,"amplitude"=>cis(2*π*xuc/(dx*dy))))
            push!(interactions,Dict("startIND"=>id,"endIND"=>hopped_id,"dx"=>0,"dy"=>0,"Strength"=>IntStrength))

        else
            push!(hops,Dict("Start"=>id,"End"=>hopped_id,"Dx"=>0,"Dy"=>1,"amplitude"=>cis(2*π*xuc/(dx*dy))))
            push!(interactions,Dict("startIND"=>id,"endIND"=>hopped_id,"dx"=>0,"dy"=>1,"Strength"=>IntStrength))

        end
    end

    L = length(hops)
    for moveID in 1:L #have to do this, otherwise you get an infinite loop...
        move = hops[moveID]
        reverseDir = Dict("Start"=>move["End"],"End"=>move["Start"],"Dx"=>-move["Dx"],"Dy"=>-move["Dy"],"amplitude"=>conj(move["amplitude"]))
        #print(reverseDir)
        push!(hops,reverseDir)
    end

    # finally, the bg potential
    if !isnothing(Vm)
        for xuc in 1:dx, yuc in 1:dy
            id = dy*(xuc-1)+yuc
            fval = 0.5*(cos(2*π*xuc/dx)+cos(2*π*yuc/dy)) # so between -1,1
            push!(hops,Dict("Start"=>id,"End"=>id,"Dx"=>0,"Dy"=>0,"amplitude"=>Vm*fval))
        end
    end


    sort!(hops,by=x->x["End"]) # sort by the end of the move...

    # note: INTERACTIONS DO NOT NEED TO BE DOUBLED TO AVOID DOUBLE-COUNTING!

    return hops, interactions, dx*dy # final one just says U.C. dimension!
end

function get_HH_distances(dx,dy,Nx,Ny)

    distances = zeros(Float64,(dx*dy*Nx*Ny,dx*dy*Nx*Ny))
    for x1 in 1:Nx, y1 in 1:Ny, x2 in 1:Nx, y2 in 1:Ny
        for x1i in 1:dx, y1i in 1:dy, x2i in 1:dx, y2i in 1:dy
            id1=(x1-1)*Ny*dx*dy + (y1-1)*dx*dy + (x1i-1)*dy + y1i
            id2=(x2-1)*Ny*dx*dy + (y2-1)*dx*dy + (x2i-1)*dy + y2i
        
            # each (dx,dy) small cell is considered as one unit!
            r = [x1*dx+x1i,y1*dy+y1i]-[x2*dx+x2i,y2*dy+y2i]
        
            dist = Inf
            for xshift in [-Nx*dx,0,Nx*dx], yshift in [-Ny*dy,0,Ny*dy]
                d = norm(r-[xshift,yshift])
                if d<dist
                    dist=d
                end
            end
            distances[id1,id2]=dist
        end
    end

    return distances
end


# basically just checking that distance definition is consistent with how you draw hoppings!
# NX=20
# NY=20
# moves =get_valid_moves_checkerboard(1,0,0,0)
# dists = get_checkerboard_distances_matrix(NX,NY)

# for move in moves
#     if abs(move["amplitude"])>0.001
#         X=rand(1:NX)
#         Y=rand(1:NY)

#         startindex = 2*(X-1)*NY+2*(Y-1)+move["Start"]

#         Xp = mod(X+move["Dx"]-1,NX)+1
#         Yp = mod(Y+move["Dy"]-1,NY)+1

#         endindex = 2*(Xp-1)*NY+2*(Yp-1)+move["End"]

#         @show (X,Y,move["Start"]), (Xp,Yp,move["End"]), dists[startindex,endindex]
#     end
# end

# a=2

#=
MaxX=200# how many unit cells each way
MaxY=200 

NR_UNIT_CELLS = 100


# just to try stuff out
RMAT = rand(Int64,(NR_UNIT_CELLS,3))
Positions = deepcopy([RMAT[i,:] for i in 1:size(RMAT,1)])
function goodform(v)
    v[3]=abs((v[3]-1)%4) + 1
    v[1]=abs((v[1]-1)%MaxX) + 1
    v[2]=abs((v[2]-1)%MaxY) + 1
end
map(goodform,Positions)


Rs = randn((NR_UNIT_CELLS,4))+im*randn((NR_UNIT_CELLS,4))
Parton1Vec = [Rs[i,:] for i in 1:size(Rs,1)]

Rs = randn((NR_UNIT_CELLS,4))+im*randn((NR_UNIT_CELLS,4))
Parton2Vec = [Rs[i,:] for i in 1:size(Rs,1)]


# SHOULD NOT BE RANDOM BUT WHO CARES...
Ms = pi*randn((NR_UNIT_CELLS,2))
momenta = [Ms[i,:] for i in 1:size(Ms,1)]


indices, grads = get_gradients(Positions,Parton1Vec,Parton2Vec,momenta)
grads

H=full_hop_ham(Positions,Parton1Vec,Parton2Vec,momenta)

WF,invP1,invP2=get_WF_and_inverses(Positions,Parton1Vec,Parton2Vec,momenta)

println("Slow ratio of H $(H/WF)")

Hrat = full_hop_ham_FAST(Positions,Parton1Vec,Parton2Vec,invP1,invP2,momenta)

println("Fast ratio is $Hrat")

diff = abs(Hrat - H/WF)/(abs(Hrat)+abs(H/WF))
println("Slow vs fast Ham: $(diff)")


Findices, Fgrads = get_gradients_Fast(Positions,invP1,invP2,momenta)
=#

#=

# a quick gradient checker...
which_parton = 1
which_momentum = 15
which_index = 1

function gradient_check(which_parton,which_momentum,which_index)
    p1P=deepcopy(Parton1Vec)
    p2P=deepcopy(Parton2Vec)

    p1M=deepcopy(Parton1Vec)
    p2M=deepcopy(Parton2Vec)


    epsilon = 1e-7

    if which_parton==1
        p1P[which_momentum][which_index]+=epsilon/2
        p1M[which_momentum][which_index]-=epsilon/2

    else
        p2P[which_momentum][which_index]+=epsilon/2
        p2M[which_momentum][which_index]-=epsilon/2

    end

    finite_diff = (get_WF_and_inverses(Positions,p1P,p2P,momenta)[1]-get_WF_and_inverses(Positions,p1M,p2M,momenta)[1])/epsilon

    myGrad=Fgrads[which_momentum,which_parton][which_index]*WF

    relDIff = abs((finite_diff-myGrad)/(abs(myGrad)+abs(finite_diff)))

    return relDIff
end

NRTODO=1000

MDIFF = 0

for j in 1:NRTODO
    which_parton=rand(1:2)
    which_momentum=rand(1:NR_UNIT_CELLS)
    which_index=rand(1:4)

    rdiff = gradient_check(which_parton,which_momentum,which_index)

    if rdiff>MDIFF
        MDIFF=rdiff
    end
end
print("Max rel diff: $MDIFF")
# LOOKS LIKE GRADIENT WORKS PERFECTLY WELL!

=#