using CSV
using DataFrames
using Plots
include("gradients_and_ham.jl")

# idea here is to take the MF parton EV's and compute the flux going through plaquettes

#wf_file = "logs/wavefunctions_QUENCH_6,2partons,filling-0.4375,checkerboard,V10,V20,size_4x4_nrRuns_100.csv"
#wf_file = "logs/wavefunctions_QUENCH_2,2partons,filling-0.4722222222222222,checkerboard,V10,V20,size_6x6_nrRuns_150.csv"
#wf_file = "logs/wavefunctions_QUENCH_3,2partons,filling-0.45,checkerboard,V10,V20,size_4x5_nrRuns_100.csv"
# wf_file = "wstation_logs/wavefunctions_QUENCH_3,2partons,filling-0.4722222222222222,checkerboard,V10,V20,size_6x6_nrRuns_100.csv"
#wf_file = "wstation_logs/wavefunctions_QUENCH_7,2partons,filling-0.4722222222222222,checkerboard,V10,V20,size_6x6_nrRuns_100.csv"
wf_file = "wstation_logs/wavefunctions_QUENCH_7,2partons,filling-0.4791666666666667,checkerboard,V10,V20,size_6x8_nrRuns_100.csv"

#wf_file = "wstation_logs/wavefunctions_REQUENCH_7,2partons,filling-0.4791666666666667,checkerboard,V10,V20,size_6x8_nrRuns_100.csv"

#wf_file = "wstation_logs/wavefunctions_QUENCH_7,2partons,filling-0.47619047619047616,checkerboard,V10,V20,size_6x7_nrRuns_100.csv"

# as a control - fully half-filled band
#wf_file = "logs/wavefunctions_QUENCH_3,2partons,filling-0.5,checkerboard,V10,V20,size_4x5_nrRuns_100.csv"

#wf_file = "logs/wavefunctions_QUENCH_7,2partons,filling-0.4444444444444444,checkerboard,V10,V20,size_3x6_nrRuns_100.csv"

#wf_file = "wstation_logs_1_anyon/wavefunctions_QUENCH_7,2partons,filling-0.4666666666666667,checkerboard,V10,V20,size_3x5_nrRuns_100.csv"
#wf_file = "wstation_logs_1_anyon/wavefunctions_QUENCH_7,2partons,filling-0.4666666666666667,checkerboard,V10,V20,size_5x3_nrRuns_100_NONDISP.csv"

wf_file = "wstation_logs_two_anyon_disp/wstation_logs_2_anyon_disp.csv"


# check a bloch-like one 
# wf_file = "logs/wavefunctions_BLOCH_QUENCH_2,2partons,filling-0.4583333333333333,checkerboard,V10,V20,size_6x4_nrRuns_150.csv"
# wf_file = "wstation_logs/wavefunctions_BLOCH_QUENCH_7,2partons,filling-0.4722222222222222,checkerboard,V10,V20,size_6x6_nrRuns_100.csv"

df = CSV.read(wf_file,DataFrame)

ns=names(df)

number_orbitals = maximum(parse.(Int64,getindex.(split.(ns[contains.(ns,"Parton_1")],"_"),4)))
Nx = maximum(df."RX")
Ny = maximum(df."RY")
Nu = maximum(df."RI")

# parse this dataframe into something sensible
numberpartons = maximum(parse.(Int64,getindex.(split.(ns[contains.(ns,"Parton")],"_"),2)))

partonWFS = [zeros(ComplexF64,(number_orbitals,Nx*Ny*Nu)) for _ in 1:numberpartons]
for row in eachrow(df)
    id = row.:RI + (row.:RY-1)*Nu + (row.:RX-1)*Nu*Ny
    
    for partonid in 1:numberpartons, orbitalid in 1:number_orbitals
        partonWFS[partonid][orbitalid,id]=parse(ComplexF64,row["Parton_$(partonid)_Orbital_$(orbitalid)"])
    end
end


# now compute a thing getting the MF EV of <f1^\dag f_1> betweem sites
# is it just taking summing the amplitudes over the orbitals? Probably... BUT DERIVE IT!

# left,right : [X,Y,UC]. Index is then UC + U*(Y-1) + U*Ny*(X-1)
function toindex(coords)
    return coords[3]+Nu*(coords[2]-1)+Nu*Ny*(coords[1]-1)
end

for parton_id in [1,2]
@show parton_id

all_mf_evs = partonWFS[parton_id]'*partonWFS[parton_id]

# now do the plaquette flux thing... Need to think of sub-sites, etc...
# get list of all NN hops

hops = get_valid_moves_checkerboard(im,0,0,0)
nn_hops = hops[abs.(getindex.(hops,"amplitude").-im).<0.3]

# try this way, will see what you get!
loop_big = [
    [0,0,1],
    [0,1,1],
    [1,1,1],
    [1,0,1]
]


fluxes_big_loop = zeros(Float64,Nx,Ny)
for X in 1:Nx, Y in 1:Ny
    sites = [[mod(X+st[1]-1,Nx)+1,mod(Y+st[2]-1,Ny)+1,st[3]] for st in loop_big]
    indices = toindex.(sites)
    
    # now compute correlators and the loop!
    u12 = all_mf_evs[indices[1],indices[2]]
    u23 = all_mf_evs[indices[2],indices[3]]
    u34 = all_mf_evs[indices[3],indices[4]]
    u41 = all_mf_evs[indices[4],indices[1]]

    # compute the flux in this way to subtract away pi-flux...
    fluxes_big_loop[X,Y] = angle(-u12*u23*u34*u41)/(2*π)
end
@show sum(fluxes_big_loop)
@show maximum(abs.(fluxes_big_loop))
@show fluxes_big_loop
# need better way!

loop1 = [
    [0,0,1],
    [0,0,2],
    [0,1,1],
    [-1,0,2]
]
loop1_cumulative_phase_of_hoppings = -1 # because 'bare' NN hoppings give π together...


loop2 = [
    [0,0,1],
    [0,-1,2],
    [1,0,1],
    [0,0,2]
]
loop2_cumulative_phase_of_hoppings = -1 # same as above!


fluxes = zeros(Float64,(Nx,Ny,2))
for X in 1:Nx, Y in 1:Ny
    sites = [[mod(X+st[1]-1,Nx)+1,mod(Y+st[2]-1,Ny)+1,st[3]] for st in loop1]
    indices = toindex.(sites)
    
    # now compute correlators and the loop!
    u12 = all_mf_evs[indices[1],indices[2]]
    u23 = all_mf_evs[indices[2],indices[3]]
    u34 = all_mf_evs[indices[3],indices[4]]
    u41 = all_mf_evs[indices[4],indices[1]]

    # compute the flux in this way to subtract away pi-flux...
    fluxes[X,Y,1] = angle(u12*u23*u34*u41*loop1_cumulative_phase_of_hoppings)/(2*π)

    sites = [[mod(X+st[1]-1,Nx)+1,mod(Y+st[2]-1,Ny)+1,st[3]] for st in loop2]
    indices = toindex.(sites)
    
    # now compute correlators and the loop!
    u12 = all_mf_evs[indices[1],indices[2]]
    u23 = all_mf_evs[indices[2],indices[3]]
    u34 = all_mf_evs[indices[3],indices[4]]
    u41 = all_mf_evs[indices[4],indices[1]]

    fluxes[X,Y,2] = angle(u12*u23*u34*u41*loop2_cumulative_phase_of_hoppings)/(2*π)

end
@show sum(fluxes);
@show maximum(abs.(fluxes))

@show fluxes[:,:,1]+fluxes[:,:,2]
end