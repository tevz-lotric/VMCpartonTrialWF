include("quencher_FUNCTION.jl")



# for Vm in [-0.02,0,0.02,-0.01,0.01]#,0.1]
#     for nparticles in -1:-1:-6#[-2,-4]
#         for flux in 0:abs(nparticles)
#             println("Doping $nparticles, FLUX DEVIATION $flux")
#             run_with_data(nparticles,flux,Vm)
#         end            
#     end
# end

# note that the Km=1 one is just the normal run you have done!
Vm = -0.03
for Km in [0.5,0,-0.5,-1]#,0,0.02,-0.01,0.01]#,0.1]
    for nparticles in -1:-1:-4#[-2,-4]
        for flux in 0:abs(nparticles)
            println("Doping $nparticles, FLUX DEVIATION $flux")
            run_with_data(nparticles,flux,Vm,Km=Km)
        end            
    end
end
