using LinearAlgebra
include("jastrow_factor_tools.jl")

# this is slow, ~O(N^2)
function parton_WF_and_inverse(positions::Vector{Vector{Int64}}, partons, jastrowfunct,dims;parton_rescale_factor=1) # dims should be (Nx, Ny, Number_Bosonic_Bands)
    L = length(positions)

    # automatically quit if two positions coincide...
    usepositions = deepcopy(positions)
    sort!(usepositions) # does not matter if we shap positions anyway. Sorting is faster than pairwise comparison!
    diff = usepositions[2:L]-usepositions[1:L-1]
    if any(diff.==[[0,0,0]])
        return 0, []
    end

    # first retrieve the 'x' and 'y' components
    xs = first.(positions)
    ys = getindex.(positions,2)
    unitcellindices = last.(positions)

    full_indices = (xs.-1)*dims[2]*dims[3] + (ys.-1)*dims[3] + unitcellindices

    # compute by what do scale to keep reasonable values \Psi.
    # basically assume the full parton vector is normalized. So need to multiply by ~
    # ~ sqrt(dims[1]*dims[2]*dims[3] / L) to have the magnitude of what's inside on average be 1.
    scalefactor = sqrt(dims[1]*dims[2]*dims[3]/L) * parton_rescale_factor

    total_factor = 1+0*im
    parton_inverses = []
    for curr_parton in partons
        partonComponents = reduce(hcat,getindex.(curr_parton,[full_indices]))
        PartonFactor = det(partonComponents*scalefactor)

        total_factor=total_factor*PartonFactor

        push!(parton_inverses, inv(partonComponents))
    end

    return total_factor*full_jastrow(positions,jastrowfunct,dims), parton_inverses
end

# an O(N^2)
function parton_WF_and_inverse_from_old(mover_ID,mover_new_position,mover_old_position,old_total_factor,old_inverses,partons,jastrowfunct,oldPositions,dims)
   
    total_factor = 1+0*im
    parton_inverses=[]


    for (parton,inverse) in zip(partons,old_inverses)
    
        # first figure out the new vector

        posID=(mover_new_position[1]-1)*dims[2]*dims[3]+(mover_new_position[2]-1)*dims[3]+mover_new_position[3]
        newVector = getindex.(parton,posID)

        # and will also need the old one later on 
        oldPosID=(mover_old_position[1]-1)*dims[2]*dims[3]+(mover_old_position[2]-1)*dims[3]+mover_old_position[3]
        oldVector = getindex.(parton,oldPosID)
        # now find the new determinant (ie just the ratio)
        
        # this you have done before... 
        ratioP = transpose(inverse[:,mover_ID])*newVector
        total_factor=total_factor*ratioP


        # use Sherman-Morrison formula to find the new inverses. NO nonsense with scale factors here
        # again careful with columns, vectors...
        v_vector = newVector-oldVector

        new_inverse = inverse - inverse[:,mover_ID].*((transpose(v_vector)*inverse)) / (1+transpose(v_vector)*inverse[:,mover_ID])

        push!(parton_inverses,new_inverse)
    end
    return total_factor*old_total_factor*jastrow_update(mover_ID,mover_new_position,oldPositions,jastrowfunct,dims), parton_inverses
end