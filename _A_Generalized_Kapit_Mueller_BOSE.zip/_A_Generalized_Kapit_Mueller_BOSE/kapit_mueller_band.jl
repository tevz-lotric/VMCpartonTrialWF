function get_best_path(start,finish,period)
    # returns best path from start to finish, given the period
    # path is allowed to wind around the torus, so it is periodic
    # start and finish are 1-indexed, so they are in [1,period]
    # returns a vector of integers, which are the path points
    # e.g. if start=1, finish=3, period=4, then
    # it returns [1,2,3] or [1,4,3]

    if start==finish
        return [start]
    end

    if start<finish
        if finish-start <= period/2 + 1e-3
            return collect(start:finish)
        else
            return vcat(collect(start:-1:1),collect(period:-1:finish))

        end
    else
        if start-finish <= period/2 + 1e-3
            return collect(start:-1:finish)
        else
            return vcat(collect(start:period),collect(1:finish))

        end
    end
end

# new one, it is supposed to be able to do any flux per plaquette f as long as f*Nx*Ny = integer.
function get_factor_of_gauge(Nx,Ny,flux_per_uc) # set_of_fluxes is a vector of plaquettes which have pi-flux extra
    ncomp = Nx*Ny

    UC_DIM=1

    vals = ones(ComplexF64,(ncomp,ncomp))

    for x in 1:Nx, y in 1:Ny, z in 1:UC_DIM
        for xp in 1:Nx, yp in 1:Ny, zp in 1:UC_DIM
            # so should interpret this as going x->xp,...
            # idea is to do x->xp, then y->yp and finally add a term to pretend you went along diagonal...
            
            xpath = get_best_path(x,xp,Nx)
            ypath = get_best_path(y,yp,Ny)

            dirx,diry=0,0

            if length(xpath)>1
                dirx = 1
                if mod(xpath[2]-xpath[1],Nx)>Nx/2
                    dirx = -1
                end
            end
            
            if length(ypath)>1
                diry= 1
                if mod(ypath[2]-ypath[1],Ny)>Ny/2
                    diry = -1
                end
            end

            angle = 0
            for (xl,xr) in zip(xpath[1:end-1],xpath[2:end])
                if xr==1 && xl==Nx
                    angle = angle + 2*π*flux_per_uc*y*Nx
                end
                if xr==Nx && xl==1
                    angle = angle - 2*π*flux_per_uc*y*Nx
                end
            end

            for (yl,yr) in zip(ypath[1:end-1],ypath[2:end])
                angle = angle - 2*π*flux_per_uc*xp*diry
            end

            # correction from the half-triangle...
            angle = angle+2*π*flux_per_uc*0.5*(length(ypath)-1)*(length(xpath)-1)*dirx*diry
            
            vals[(x-1)*Ny*UC_DIM+(y-1)*UC_DIM+z,(xp-1)*Ny*UC_DIM+(yp-1)*UC_DIM+zp]=cis(angle)

        end
    end
    

    if maximum(abs.(vals-vals'))>1e-6
        @warn "Gauge factor matrix is not hermitian, something is wrong!"
        return vals
    end

    return 0.5*(vals+vals') # make it hermitian, so that it is a gauge factor
end

# so for any hop between "i" and "j", you can figure out the gauge field factor based on the other script...

# (1): Decide on a UC shape and on a MAXIMAL hopping distance
# (2): Identify all hoppings up to that range... For each, find the W(z) and make the dictionary

function KMW(hop,phi)
    x,y=hop

    Gz = cis(π*(x+y+x*y))

    # for the on-site terms, do a +1 in order to make the band (hopefully) at E=0
    return Gz*exp(-(π/2)*(1-phi)*(x^2+y^2))
end

function make_Kapit_Mueller(dx,dy,MAX_DISTANCE)
    hops = []


    FLUX_PER_PLAQ = 1/(dx*dy)
    flux_UC = get_factor_of_gauge(dx,dy,FLUX_PER_PLAQ)
    # id = (x-1)*dy+y

    BN = ceil(Int64,MAX_DISTANCE+1e-7)

    bigarr = [[a,b] for a in -BN:BN, b in -BN:BN];
    possiblehops = bigarr[norm.(bigarr).<=MAX_DISTANCE+1e-7]

#    @show possiblehops

    locs = [[0.0,0.0] for _ in 1:dx*dy]

    for startingx in 1:dx,startingy in 1:dy
        Sid = (startingx-1)*dy+startingy

        locs[Sid]=[(startingx-1)/dx, (startingy-1)/dy]

        for hop in possiblehops
            endingx = startingx + hop[1]
            endingy = startingy + hop[2]


            finalxuc = mod(endingx-1,dx)+1
            finalyuc = mod(endingy-1,dy)+1

            Fid = (finalxuc-1)*dy+finalyuc

            nucx = round(Int64,(endingx-finalxuc)/dx)
            nucy = round(Int64,(endingy-finalyuc)/dy)

            # so full hop is between "Start" and "End" + "Dx" + "Dy"...
            push!(hops,Dict("Start"=>Sid,"End"=>Fid,"Dx"=>nucx,"Dy"=>nucy,"amplitude"=>KMW(hop,FLUX_PER_PLAQ)*flux_UC[Fid,Sid]))
            end
    end

    return hops,locs
end

# make a nice "generalized" GM band 

using LinearAlgebra

function bloch_H(kx,ky,N,hops,locs)
    Hbloch = zeros(ComplexF64,(N,N))

    for hop in hops
        LeftID = hop["End"]
        LeftFullLoc = locs[LeftID] + [hop["Dx"],hop["Dy"]]

        RightID = hop["Start"]
        RightFullLoc = locs[RightID] 

        Hbloch[LeftID,RightID]+=hop["amplitude"]*cis([kx,ky]' * (LeftFullLoc-RightFullLoc) )

#        @show norm(LeftFullLoc-RightFullLoc) # can use to check that the Dx,Dy logic is right!

    end

    return Hermitian(Hbloch)
end


function generalized_KM(kmhops,kmlocs,Kfunction,Vfunction;factor=1)
    Nkx = 10
    Nky = 10

    dkx = 2*π/Nkx
    dky = 2*π/Nky

    kxs = range(-π,π-2*π/Nkx,Nkx)
    kys = range(-π,π-2*π/Nky,Nky)

    dispersion = [eigen(bloch_H(kx,ky,length(Kfunction),kmhops,kmlocs)).values for kx in kxs, ky in kys]

    # basically need to shift the band by this much...
    extra_mu = sum(getindex.(dispersion,1))/(Nkx*Nky)

    newhops = []
    for hop in kmhops
        toadd = 0
        if hop["End"]==hop["Start"] && hop["Dx"]==0 && hop["Dy"]==0
            toadd = - extra_mu + Vfunction[hop["Start"]]/factor
        end

        hop["amplitude"]=factor*(hop["amplitude"]+toadd)*exp(Kfunction[hop["Start"]]+Kfunction[hop["End"]])
        push!(newhops,hop)
    end

    return newhops
end