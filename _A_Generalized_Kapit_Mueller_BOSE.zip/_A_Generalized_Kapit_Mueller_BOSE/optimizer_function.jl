using Distributed
using UnicodePlots
using DataFrames
using CSV
using ParallelDataTransfer
using ProgressMeter
using LinearAlgebra
using Random


@everywhere include("WF_evaluation.jl")
@everywhere include("gradients_and_ham.jl")
@everywhere include("MonteCarloSampler.jl")
@everywhere include("jastrow_factor_tools.jl")
@everywhere include("kapit_mueller_band.jl")


function run_optimizer(adam_params,hamiltonian_params,worker_params,partonHamiltonians,jastrowfunct,message,distances,parton_MF_Ham_enforced_periods,parton_MF_Ham_max_range,jastrow_periods,jastrow_maxrange;which_hamiltonian="hex",startingPos = nothing,record_corr=false,adam_nr_done=nothing,adam_previous_m=nothing,adam_previous_v=nothing,force_bloch_projection=false,MOMENTA_TO_PROJECT_ONTO=nothing,PROJECTOR_DIMS=nothing,start_slow=-1,flux_pattern=[],parton_charges = [1,-1],ADDITIONAL_KM_K_PARAMETER_FACTOR=1.0)


    determinant_scale_factor = 1 # the factor by which to multiply WF's before taking determinant to avoid overflow!

    # DEFINE YOUR MONTE CARLO PARAMETERS HERE....
    each_iteration_per_worker = worker_params["runs_per_worker"]
    each_iteration_warmups = worker_params["warmups_per_worker"]


    # HAMILTONIAN!!
    validMoves=[]
    interactionTerms = []

    V1=0;V2=0

    if haskey(hamiltonian_params,"V1")
        V1 = hamiltonian_params["V1"]
    end
    if haskey(hamiltonian_params, "V2")
        V2 = hamiltonian_params["V2"]
    end

    if which_hamiltonian=="Hofstader"
        fakemoves,ints,dims = create_HH_hops_and_interactions(hamiltonian_params["dx"],hamiltonian_params["dy"],V1,Vm=hamiltonian_params["Vm"])#*2) # the x2 is to agree wit DiagHam!

        dx,dy=hamiltonian_params["dx"],hamiltonian_params["dy"]
        maxdist = 1.51
        hopsfirst,locs=make_Kapit_Mueller(dx,dy,maxdist);

        Kfactor = 0.5
        sx,sy=0/dx,0/dy # if you wanted to shift centres for any reason...
        Kfunct = Kfactor*(cos.(2*π*(getindex.(locs,1).+sx))+cos.(2*π*(getindex.(locs,2).+sy)))/2

        # Note that Beff ~ Kfunct, and that by your theory, the correlation between these two is the important thing!
        Vfunct = hamiltonian_params["Vm"] * Kfunct/ maximum(abs.(Kfunct))
    
        # so adds the non-uniformity Kfunct and dispersive potential Vfunct.
        # finally, the "factor" re-scales the hoppings such that the NN hopping is = 1 EXACTLY!
        # this essentially means that the scales are ~ what you are used to!. The Vfunct is measured in units of the FINAL thing!
        moves = generalized_KM(hopsfirst,locs,ADDITIONAL_KM_K_PARAMETER_FACTOR.*Kfunct,Vfunct;factor=exp(π*(1-1/(dx*dy))/2))

        validMoves = moves
        interactionTerms = ints
    else
        @warn "NOT USING HOFSTADER HAMILTONIAN!"
        validMoves = get_valid_moves_checkerboard(hamiltonian_params["t"],hamiltonian_params["tp1"],hamiltonian_params["tp2"],hamiltonian_params["tpp"])
        interactionTerms = get_interactions_checkerboard(V1,V2)
    end

   # @show validMoves

    # ADAM PARAMETERS
    NUMBER_OPTIMIZER_STEPS = adam_params["Optimizer_steps"]
    adam_Beta1 = adam_params["beta1"]
    adam_Beta2 = adam_params["beta2"]
    adam_epsilon = adam_params["epsilon"]
    adam_gamma_learn_rate_first_phase = adam_params["Learn_rate"]


    NR_TO_START_SECOND = 150
    adam_gamma_learn_rate_second_phase = adam_gamma_learn_rate_first_phase

    global adam_gamma_learn_rate = adam_gamma_learn_rate_first_phase

    # was gamma=0.005 in [35], COULD BE ALSO A FUNCTION OF IT NR., STH LIKE 1/i, see [33] for why this is good! (basically infinite distance covered but finite var...)

    # x cells are double the size. So want NR_Y ~ 2xNR_X for a roughly square system!
    #NR_BOSONS IS THE PRODUCT OF THESE TWO!
    NUMBER_X_CELLS = hamiltonian_params["NX"]
    NUMBER_Y_CELLS = hamiltonian_params["NY"]


    N_bose = hamiltonian_params["NR_PARTICLES"]

    global filling_fraction = N_bose/(NUMBER_X_CELLS*NUMBER_Y_CELLS)



    dims = [NUMBER_X_CELLS,NUMBER_Y_CELLS,hamiltonian_params["dx"]*hamiltonian_params["dy"]]
    ncomponents=prod(dims)

    # first guess for eigenvectors
    global Number_Partons = length(partonHamiltonians)

    gaugephasefactors=[]
    for pid in 1:Number_Partons
        thispartonfactor = ones(ComplexF64,size(partonHamiltonians[1]))
        for (gauge_id,fp) in enumerate(flux_pattern)
            thispartonfactor = thispartonfactor.*get_factor_of_gauge_nonuniform(dims[1],dims[2],parton_charges[gauge_id][pid].*fp,distances.<parton_MF_Ham_max_range,hamiltonian_params["dx"]*hamiltonian_params["dy"])
        end
        push!(gaugephasefactors,thispartonfactor)
        #@show thispartonfactor
    end
    # essntiallu, if this is X, the true Hamiltonian is H.*X, but you only save H...

    # here must get partonVectors from partonHamiltonians
    global PartonVectors = [get_vectors_for_ham(X.*gpf,N_bose)[1] for (X,gpf) in zip(partonHamiltonians,gaugephasefactors)]
    global PartonHamFullUnitaries = [get_vectors_for_ham(X.*gpf,N_bose)[2] for (X,gpf) in zip(partonHamiltonians,gaugephasefactors)]

    function get_some_positions()
        # first find total number of places: 
        nr_sites = NUMBER_X_CELLS*NUMBER_Y_CELLS*2

        particle_locs = randperm(nr_sites)[1:N_bose]

        Positions = [[0,0,0] for _ in 1:N_bose]
        for pn in 1:N_bose
            uc_id=mod(particle_locs[pn]-1,dims[3])+1

            remainder = round(Int64,(particle_locs[pn]-uc_id)/dims[3])
            yid = mod(remainder-1,NUMBER_Y_CELLS)+1

            remainder = round(Int64,(remainder-yid)/dims[2])
            xid = mod(remainder-1,NUMBER_X_CELLS)+1

            Positions[pn]=[xid,yid,uc_id] # initialize to the biggest-`s` state always...
            
        end

        return Positions
    end

    # run the above for all workers
    FullPositions = map(x->get_some_positions(),1:number_workers )

    if startingPos!=nothing
        FullPositions=deepcopy(startingPos)
    end

    # initialize adam's cumulants. The FINAL Number_Partons+1 thing of vt,mt is the JASTROW!!!

    global vt = zeros(Float64,(Number_Partons+1,ncomponents,ncomponents))

    global mt = zeros(ComplexF64,(Number_Partons+1,ncomponents,ncomponents))

    adam_base = 0 
    if adam_nr_done!=nothing
        global vt = deepcopy(adam_previous_v)
        global vm = deepcopy(adam_previous_m)
        adam_base = adam_nr_done
    end


    Energy_EV_LOG = zeros(ComplexF64,NUMBER_OPTIMIZER_STEPS)

    bosonCumulant = zeros(ComplexF64,(NUMBER_X_CELLS,NUMBER_Y_CELLS,dims[3],NUMBER_X_CELLS,NUMBER_Y_CELLS,dims[3]))
    densityCumulant = zeros(Float64,(NUMBER_X_CELLS,NUMBER_Y_CELLS,dims[3],NUMBER_X_CELLS,NUMBER_Y_CELLS,dims[3]))


    aa,bb=hamiltonian_params["dx"],hamiltonian_params["dy"]
    vmval = hamiltonian_params["Vm"]
    identifier="$(message),$(Number_Partons)partons,nu-$(filling_fraction),HOFSTADER,V1_$(V1)_Vmodulated_$(vmval)_ExtraKFact_$(ADDITIONAL_KM_K_PARAMETER_FACTOR)_UCSIZE_$(aa)x$(bb)_Size_$(NUMBER_X_CELLS)x$(NUMBER_Y_CELLS)_hamcutoffdist_$(round(parton_MF_Ham_max_range,digits=2))_nrRuns_$(NUMBER_OPTIMIZER_STEPS)"

    
    # NOW START THE BIG LOOP!
    @showprogress 1 "Optimizing..." for it_nr in 1:NUMBER_OPTIMIZER_STEPS
        # first run the monte carlos. The X iterates over all positions
        MCRAN = pmap(X->MC_sample(each_iteration_per_worker,each_iteration_warmups,X,PartonVectors,jastrowfunct,dims,validMoves,interactionTerms,determinant_scale_factor),FullPositions)

        # To continue coding here. To do:
        # (1) Add Jastrow+gradients to MC Sampler!


        # now sum cumulants, also update positions
        eConjgradCum = zeros(ComplexF64,(Number_Partons,N_bose,dims[1]*dims[2]*dims[3]))
        gradCum = zeros(ComplexF64,(Number_Partons,N_bose,dims[1]*dims[2]*dims[3]))
        jastrowGrads = zeros(ComplexF64,(ncomponents,ncomponents))
        jastrowGradsCE = zeros(ComplexF64,(ncomponents,ncomponents))

        eCum = 0.0 + 0.0*im
        NR_CUMULATED = 0

        bosonCumulant=0*bosonCumulant
        densityCumulant=0*densityCumulant


        psiscale=0

        for wrk in 1:number_workers
            FullPositions[wrk]=deepcopy(MCRAN[wrk][5])
            NR_ON_THIS,E,G,EG = MCRAN[wrk][1:4]
            NR_CUMULATED+=NR_ON_THIS
            eConjgradCum+=EG
            gradCum+=G
            eCum+=E
            psiscale+=MCRAN[wrk][6]
            bosonCumulant+=MCRAN[wrk][7]
            densityCumulant+=MCRAN[wrk][8]
            jastrowGrads+=MCRAN[wrk][9]
            jastrowGradsCE +=MCRAN[wrk][10]
        end
        psiscale=psiscale/number_workers

        bosonCumulant=bosonCumulant/NR_CUMULATED
        densityCumulant=densityCumulant/NR_CUMULATED
        
        # get EV's and the needed matrices!
        Fs = eConjgradCum/NR_CUMULATED - (eCum/NR_CUMULATED)*(conj(gradCum)/NR_CUMULATED)
        EvOfE = eCum/NR_CUMULATED

        Fs_jastrow = jastrowGradsCE/NR_CUMULATED - (eCum/NR_CUMULATED)*(conj.(jastrowGrads)/NR_CUMULATED)

        # (1) so you want to change the values with 'force' Fs. now convert to Hamiltonian gradients:
        
        ncomponents = size(partonHamiltonians[1])[1]
        Fs_ham = zeros(ComplexF64,(Number_Partons,ncomponents,ncomponents))

        for pid in 1:Number_Partons
            step_size_for_trying_gradient = (-1)*(1e-5) * (maximum(abs.(PartonHamFullUnitaries[pid]))/maximum(abs.(Fs[pid,:,:]))) # just to have a reasonably small value...
            new_u_matrix = PartonHamFullUnitaries[pid]#
            for j in 1:N_bose
                new_u_matrix[:,j]=new_u_matrix[:,j]+step_size_for_trying_gradient*(Fs[pid,j,:]) #  because [j,:] is vector in Fs, while 
            end
            changeoverU = (PartonHamFullUnitaries[pid])*(new_u_matrix')
            new_ham =((changeoverU')*(partonHamiltonians[pid].*gaugephasefactors[pid])*changeoverU).*conj.(gaugephasefactors[pid])

            # crop it off
            new_ham = parton_ham_truncate_and_symmetrize(new_ham,distances,parton_MF_Ham_enforced_periods,parton_MF_Ham_max_range,dims[1],dims[2],dims[3])

            # finally compute the gradients in this way...
            hdiff=(new_ham-partonHamiltonians[pid])/(step_size_for_trying_gradient)
            # to ensure hermiticity...
            hdiff = 0.5*(hdiff+hdiff')
            Fs_ham[pid,:,:]=parton_ham_truncate_and_symmetrize(hdiff,distances,parton_MF_Ham_enforced_periods,parton_MF_Ham_max_range,dims[1],dims[2],dims[3])
            Fs_ham[pid,:,:]=Fs_ham[pid,:,:]
        end

        # (2) end of conversion. Now you do ADAM on Hamiltonian gradients 
        Fs_full = zeros(ComplexF64,(Number_Partons+1,ncomponents,ncomponents))
        Fs_full[1:Number_Partons,:,:]=Fs_ham
        Fs_full[Number_Partons+1,:,:]=Fs_jastrow

        mtP = adam_Beta1*mt + (1-adam_Beta1)*Fs_full
        mtPCorrected = mtP/(1-adam_Beta1^(it_nr+adam_base))

        #
        vtP = adam_Beta2*vt + (1-adam_Beta2)*(abs.(Fs_full).^2)
        vtPCorrected = vtP/(1-adam_Beta2^(it_nr+adam_base))

        if it_nr>NR_TO_START_SECOND
            global adam_gamma_learn_rate=adam_gamma_learn_rate_second_phase
        end
        if it_nr<start_slow # eg if you read 
            global  adam_gamma_learn_rate = 0
        end

        #(3) OK, now actually do the update of the Hamiltonian as you see fit! [as ADAM says!]

        # update, orthonormalize
        for pid in 1:Number_Partons
            partonHamiltonians[pid]=partonHamiltonians[pid]-adam_gamma_learn_rate.*mtPCorrected[pid,:,:]./(sqrt.(vtPCorrected[pid,:,:]).+adam_epsilon)

            partonHamiltonians[pid] = parton_ham_truncate_and_symmetrize(partonHamiltonians[pid],distances,parton_MF_Ham_enforced_periods,parton_MF_Ham_max_range,dims[1],dims[2],dims[3])
            partonHamiltonians[pid] = 0.5*(partonHamiltonians[pid]+partonHamiltonians[pid]')

            # make < \lambda^2 > =1 for all parton Hams ...
            typical_eigenvalue = sqrt(tr(partonHamiltonians[pid]'*partonHamiltonians[pid])/size(partonHamiltonians[pid])[1])
            partonHamiltonians[pid]=partonHamiltonians[pid]./typical_eigenvalue

            PartonVectors[pid],PartonHamFullUnitaries[pid]=get_vectors_for_ham(partonHamiltonians[pid].*gaugephasefactors[pid],N_bose)
        end

        # finally, also update the jastrows!
        id = Number_Partons+1
        jastrowfunct = jastrowfunct - real.(adam_gamma_learn_rate.*mtPCorrected[id,:,:]./(sqrt.(vtPCorrected[id,:,:]).+adam_epsilon))
        # do the symmetry thing...
        jastrowfunct = jastrow_truncate_and_symmetrize(jastrowfunct,distances,jastrow_periods,jastrow_maxrange,dims[1],dims[2],dims[3])


        # (2) UPDATE THE THING YOU PASS TO THE DET CALCULATION TO KEEP THE DETERMINANT OK
        newDetfactor = (1/psiscale)^(1/(Number_Partons*N_bose))

        determinant_scale_factor*=newDetfactor

        # and remember the new ADAM parameters!
        global mt = copy(mtP)
        global vt = copy(vtP)

        # log energy
        Energy_EV_LOG[it_nr]=EvOfE
    
        dfE = DataFrame(Index=1:length(Energy_EV_LOG),Real_Energy=real.(Energy_EV_LOG),Imag_Energy=imag.(Energy_EV_LOG))


        CSV.write("logs/ENs_$identifier.csv",dfE)
    end
    FirstToShow = 1 #round(Int64,NUMBER_OPTIMIZER_STEPS/4)

    plt=lineplot(FirstToShow:NUMBER_OPTIMIZER_STEPS, real.(Energy_EV_LOG[FirstToShow:NUMBER_OPTIMIZER_STEPS]), title="Optimization of Energy", name="Re", xlabel="Iteration number",ylabel="Energy EV")
    #lineplot!(plt,FirstToShow:NUMBER_OPTIMIZER_STEPS, imag.(Energy_EV_LOG[FirstToShow:NUMBER_OPTIMIZER_STEPS]), name="Im",color=:cyan)

    display(plt)



    nrpartons = length(PartonVectors)



    nrrows = dims[1]*dims[2]*dims[3]
    
    # each row should have a note of the X, Y, I position and then P_a_Orbital_b for a in 1:#parotns, b in 1:#orbitals
    
    # now save the hamiltonian as a set of hopping amplitudes!
    hop_dicts=[]
    for pid in 1:Number_Partons
        for x in 1:dims[1], y in 1:dims[2], z in 1:dims[3]
            for xp in 1:dims[1], yp in 1:dims[2], zp in 1:dims[3]
                amp = partonHamiltonians[pid][(xp-1)*dims[2]*dims[3]+(yp-1)*dims[3]+zp,(x-1)*dims[2]*dims[3]+(y-1)*dims[3]+z]
                if abs(amp)>1e-9
                    push!(hop_dicts,Dict("Parton"=>pid,"Start"=>[x,y,z],"End"=>[xp,yp,zp],"Amplitude"=>amp))
                end
            end
        end
    end
    df = DataFrame(hop_dicts)
    CSV.write("hamlogs/Hams_$identifier.csv",df)

    gaugedhams = [partonHamiltonians[pid].*gaugephasefactors[pid] for pid in 1:Number_Partons]

    hop_dicts=[]
    for pid in 1:Number_Partons
        for x in 1:dims[1], y in 1:dims[2], z in 1:dims[3]
            for xp in 1:dims[1], yp in 1:dims[2], zp in 1:dims[3]
                amp = gaugedhams[pid][(xp-1)*dims[2]*dims[3]+(yp-1)*dims[3]+zp,(x-1)*dims[2]*dims[3]+(y-1)*dims[3]+z]
                if abs(amp)>1e-9
                    push!(hop_dicts,Dict("Parton"=>pid,"Start"=>[x,y,z],"End"=>[xp,yp,zp],"Amplitude"=>amp))
                end
            end
        end
    end
    df = DataFrame(hop_dicts)
    CSV.write("hamlogs/Gauged_Hams_$identifier.csv",df)

    # df = DataFrame(Index=1:nrrows,RX=zeros(Int64,nrrows),RY=zeros(Int64,nrrows),RI=zeros(Int64,nrrows))
    # for xind in 1:dims[1], yind in 1:dims[2], iind in 1:dims[3]
    #     rowname = dims[2]*dims[3]*(xind-1)+dims[3]*(yind-1)+iind

    #     df[rowname,:RX]=xind
    #     df[rowname,:RY]=yind
    #     df[rowname,:RI]=iind
    # end

    # for pid in 1:Number_Partons, j in 1:N_bose
    #     currVector = PartonVectors[pid][j]

    #     name = "Parton_$(pid)_Orbital_$(j)"
    #     df[!,name]=currVector
    # end

    # CSV.write("logs/hamiltonians_$identifier.csv",df)
    #and the energy log

    dfE = DataFrame(Index=1:length(Energy_EV_LOG),Real_Energy=real.(Energy_EV_LOG),Imag_Energy=imag.(Energy_EV_LOG))


    CSV.write("logs/ENs_$identifier.csv",dfE)


    # L = length(bosonCumulant)
    # DfB = DataFrame(Index=1:L,X1=zeros(Int64,L),X2=zeros(Int64,L),Y1=zeros(Int64,L),Y2=zeros(Int64,L),Ind1=zeros(Int64,L),Ind2=zeros(Int64,L),boseCorr=zeros(ComplexF64,L),densityCorr=zeros(Float64,L))
    # j=1
    # for x1 in 1:size(bosonCumulant)[1], x2 in 1:size(bosonCumulant)[4], y1 in 1:size(bosonCumulant)[2], y2 in 1:size(bosonCumulant)[5], index1 in 1:size(bosonCumulant)[3], index2 in 1:size(bosonCumulant)[6]
    #     DfB."X1"[j]=x1
    #     DfB."X2"[j]=x2
    #     DfB."Y1"[j]=y1
    #     DfB."Y2"[j]=y2
    #     DfB."Ind1"[j]=index1
    #     DfB."Ind2"[j]=index2
    #     DfB."boseCorr"[j]=bosonCumulant[x1,y1,index1,x2,y2,index2]
    #     DfB."densityCorr"[j]=densityCumulant[x1,y1,index1,x2,y2,index2]

    #     j+=1
    # end

    # if record_corr
    #     CSV.write("logs/Correlators_$identifier.csv", DfB ) 
    # else
    #     CSV.write("logs/smallSizeCorrelators_$identifier.csv", DfB ) 
    # end

#    CSV.write("logs/SWEEP_vectors_result_$identifier.csv",df)
    return dfE, partonHamiltonians,jastrowfunct,FullPositions, adam_base+NUMBER_OPTIMIZER_STEPS,mt, vt
end

