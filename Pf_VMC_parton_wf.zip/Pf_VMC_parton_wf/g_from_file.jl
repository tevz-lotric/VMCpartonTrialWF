using DataFrames
using CSV

function read_g_from_file(filename,nr_partons,nr_ucs,nr_s)
    gdf= select(DataFrame(CSV.File(filename)), Not("Index"))

    all_columns = DataFrames.names(gdf)
    all_columns = all_columns[length.(all_columns).>4] # filter out the "X" and "Y" columns...


    Nx=maximum(gdf[!,:X])
    Ny=maximum(gdf[!,:Y])


    dims = [Nx,Ny,nr_ucs,nr_partons,nr_s]

    g_real = zeros(ComplexF64,(Nx,Ny,nr_ucs*nr_partons,nr_ucs*nr_partons,nr_s,nr_s))


    for p1 in 1:nr_partons, p2 in 1:nr_partons, uc1 in 1:nr_ucs, uc2 in 1:nr_ucs, rX in 1:Nx, rY in 1:Ny,s in 1:dims[5], sprime in 1:dims[5]
        column_name="P$(p1)_UC$(uc1)_S_$(s)-_P$(p2)_UC$(uc2)_S_$(sprime)"

        row_id=(rX-1)*Ny+rY
        # check that you have the right row
        if gdf[row_id,:X]!=rX || gdf[row_id,:Y]!=rY
            println("Row mismatch in reading g dataframe :(")
        end

        g_real[rX,rY,(p1-1)*nr_ucs+uc1,(p2-1)*nr_ucs+uc2,s,sprime]=parse(ComplexF64,gdf[row_id,column_name])
    end
    return g_real
end

#gfunct = read_g_from_file("logs/g_function_QUENCH_1,BC_PP,PFAFFIAN_2partons,filling-1.0,hex,V10,V20_t_1,tprime0.5999999999999999,tpp-0.58,size_2x3_nrRuns_1000.csv",2,4)