include("quencher.jl")

whichone = 1
if length(ARGS)>0
    whichone = parse(Int64,ARGS[1])
end

function dothething(whichone)

options = [(1, vcat([0,0],0:0.05:0.45)), (1,vcat([0.5,0.5],0.5:0.05:0.95)),(-1, vcat([0,0],0:0.05:0.45)), (-1,vcat([0.5,0.5],0.5:0.05:0.95))]

factor_term_to_use,hamparams = options[whichone]

old_output = nothing
for hamp in hamparams
    old_output=run_quencher(hamp,TERMFACTOR=factor_term_to_use,input_file=old_output)
end

end

dothething(whichone)
