include("optimizer_function.jl")
include("padding_function.jl")
include("g_from_file.jl")
include("WF_computation.jl")
include("grads_and_ham.jl")
include("MC_sampler.jl")


using UnicodePlots
using DataFrames
using CSV
using ProgressMeter
using .Threads

function run_quencher(hamparam;TERMFACTOR=1,input_file=nothing)
    # START THE DATA HERE!
    NUMBER_PARTONS_WANTED = 2
    Wanted_Filling_Fraction = 1/2

    # How many terms to take for each parton
    NUMBER_OF_S_WANTED = 1

    # DECIDE WHETHER TO READ A FILE
     #"starting_spots_tplxint2/big_g_function_QUENCH_5,CHI_2,BC_PP,PFAFFIAN_3partons,filling-0.3333333333333333,V1_2.0,V2_0,checkerboard,t_1.0,phi_0.7853981633974483,tp1_0.2928932188134525,tp2_-0.2928932188134525,tpp_0.20710678118654754,ucfactors_3x1_size_2x2_nrRuns_80.csv"
    NUMBER_OF_S_IN_READ_FILE = 1#parse(Int64,split(split(input_file,"CHI_")[2],",BC")[1])

    # SET UP THE `PROGRAM`
    # number unitcells in each direction0
    nxuc = 3
    nyuc = 3
    # size of unit-cell
    xucs = 2
    yucs = 1


    dev = -hamparam/(2+sqrt(2))
    wanted_t2 = 1/(2+sqrt(2))+dev
    wanted_phase_dev = dev/π


    steps = [ # A FCI-SFM sweep
        Dict("name" => "checkerboard","t"=>exp(im*π*(0.25+wanted_phase_dev)), "tp1"=>wanted_t2, "tp2"=>-wanted_t2, "tpp"=>1/(2+2*sqrt(2)), "NX"=>nxuc, "NY"=>nyuc, "UCx"=>xucs, "UCy"=>yucs,"V1" => 0.0, "V2" => 0, "Optimizer_steps"=>350, "Learn_rate"=>0.05, "hopping_fraction"=>1, "BCs"=>(1,1),"br_bose_c_steps"=>-5),
        Dict("name" => "checkerboard","t"=>exp(im*π*(0.25+wanted_phase_dev)), "tp1"=>wanted_t2, "tp2"=>-wanted_t2, "tpp"=>1/(2+2*sqrt(2)), "NX"=>nxuc, "NY"=>nyuc, "UCx"=>xucs, "UCy"=>yucs,"V1" => 0.0, "V2" => 0, "Optimizer_steps"=>120, "Learn_rate"=>0.04, "hopping_fraction"=>1, "BCs"=>(1,1),"br_bose_c_steps"=>-5),
        Dict("name" => "checkerboard","t"=>exp(im*π*(0.25+wanted_phase_dev)), "tp1"=>wanted_t2, "tp2"=>-wanted_t2, "tpp"=>1/(2+2*sqrt(2)), "NX"=>nxuc, "NY"=>nyuc, "UCx"=>xucs, "UCy"=>yucs,"V1" => 0.0, "V2" => 0, "Optimizer_steps"=>120, "Learn_rate"=>0.03, "hopping_fraction"=>1, "BCs"=>(1,1),"br_bose_c_steps"=>-5),
        Dict("name" => "checkerboard","t"=>exp(im*π*(0.25+wanted_phase_dev)), "tp1"=>wanted_t2, "tp2"=>-wanted_t2, "tpp"=>1/(2+2*sqrt(2)), "NX"=>nxuc, "NY"=>nyuc, "UCx"=>xucs, "UCy"=>yucs,"V1" => 0.0, "V2" => 0, "Optimizer_steps"=>120, "Learn_rate"=>0.02, "hopping_fraction"=>1, "BCs"=>(1,1),"br_bose_c_steps"=>-5),
     ]
    #steps = vcat(stepsa,stepsb,stepsc)

    # worker settings...
    worker = Dict("runs_per_worker"=>3500,"warmups_per_worker"=>50,"workers_per_iteration"=>nthreads())
    adam_details = Dict("beta1"=>0.9,"beta2"=>0.993,"epsilon"=>1e-5)





    # compute the UC multiplier 
    WANTED_MULTIPLIERs = (steps[1]["UCx"],steps[1]["UCy"])

    PartonTimesUC = NUMBER_PARTONS_WANTED*WANTED_MULTIPLIERs[1]*WANTED_MULTIPLIERs[2]*2 # hard coded the *2 for two original bosonic bands....

    # INITIALIZE A g_funct, EITHER RANDOM OR READ FROM FILE!

    how_big_the_other_terms = 0.2
    gfunct = zeros(ComplexF64,(steps[1]["NX"],steps[1]["NY"],PartonTimesUC,PartonTimesUC,NUMBER_OF_S_WANTED,NUMBER_OF_S_WANTED))
    for s in 1:NUMBER_OF_S_WANTED, sprime in 1:NUMBER_OF_S_WANTED
        f=1
        if s>1
            f=f*how_big_the_other_terms
        end
        if sprime>1
            f=f*how_big_the_other_terms
        end
        
        gfunct[:,:,:,:,s,sprime]=f*randn(ComplexF64,(steps[1]["NX"],steps[1]["NY"],PartonTimesUC,PartonTimesUC))

    end


    if input_file!=nothing
        println("Reading g_funct from $input_file ...")
        gfunct = read_g_from_file(input_file,NUMBER_PARTONS_WANTED,round(Int64,PartonTimesUC/NUMBER_PARTONS_WANTED),NUMBER_OF_S_IN_READ_FILE)
    end



    # same with POSITIONS
    Pos = nothing

    # load the adam parameter things...
    adam_steps = nothing
    adam_mt=nothing
    adam_vt=nothing

    dfe = nothing
    gfunctname=""

    for (step, counter) in zip(steps, 1:length(steps))
        # check if new system size matches up with g_funct, pad if necessary
        # but reset the adam parameter things to sth low 
        # also delete positions...
        if step["UCx"]*step["UCy"]*2*NUMBER_PARTONS_WANTED != size(gfunct)[3]
            nds=(step["NX"],step["NY"],step["UCx"]*step["UCy"]*2*NUMBER_PARTONS_WANTED)
            println("Re-randomizing from $(size(gfunct)[1:3]) to $nds")
            PartonTimesUC = 2*NUMBER_PARTONS_WANTED*step["UCx"]*step["UCy"]
            gfunct = randn(ComplexF64,(step["NX"],step["NY"],PartonTimesUC,PartonTimesUC))
            adam_steps = nothing
            adam_mt=nothing
            adam_vt=nothing
            Pos = nothing
            
        else
            if step["NX"]!=size(gfunct)[1] || step["NY"]!=size(gfunct)[2] || NUMBER_OF_S_WANTED!=size(gfunct)[5]
                nds=(step["NX"],step["NY"])
                println("Resizing from $(size(gfunct)[1:2]) to $nds and chi from $(size(gfunct)[5]) to $NUMBER_OF_S_WANTED.")
                gfunct = mypad(gfunct,step["NX"],step["NY"],0.15,newS=NUMBER_OF_S_WANTED) # just make it a small random value i guess...
                adam_steps = nothing
                adam_mt=nothing
                adam_vt=nothing
                Pos = nothing
            end
        end
        # set up the correct hamiltonian, everything...
        hamc = copy(step) # can have the redundant values...
        hamc["NR_PARTICLES"]=round(Int64,step["NX"]*step["NY"]*step["UCx"]*step["UCy"]*Wanted_Filling_Fraction)
        adam = copy(adam_details)
        adam["Learn_rate"]=step["Learn_rate"]
        adam["Optimizer_steps"]=step["Optimizer_steps"]
        workerc=copy(worker)
        if haskey(step,"runs_per_worker")
            workerc["runs_per_worker"]=step["runs_per_worker"]
        end

        # do the run! Keep count... Also save the things you compute, etc.
        println("Doing step $counter which is:")
        @show step
        println("Have $(hamc["NR_PARTICLES"]) particles.")
        res = run_optimizer(adam,hamc,workerc,NUMBER_PARTONS_WANTED,(step["UCx"],step["UCy"]),gfunct,"QUENCH_$(counter)_TERMFACTOR_$(TERMFACTOR)",which_hamiltonian = step["name"],startingPos = Pos,adam_nr_done=adam_steps,adam_previous_m=adam_mt,adam_previous_v=adam_vt,FRACTION_HOP=step["hopping_fraction"],boundary_conditions=step["BCs"],nr_steps_to_compute_bose_correlators=step["br_bose_c_steps"],factor_in_sum_of_terms=TERMFACTOR);
        dfe=res[1]; gfunct=res[2]; Pos = res[3]; adam_steps=res[4]; adam_mt=res[5]; adam_vt=res[6]; gfunctname = res[7];
        println("Denominator EV on average")
        @show sum(dfe."Denominator")/size(dfe)[1]
    end
 
    # figure out the final filename, RETURN IT!
    return gfunctname
end

# arg = 0 
# if length(ARGS)>0
#     arg = parse(Float64,ARGS[1])
# end

# run_quencher(arg,TERMFACTOR=-1)