# take in problem dimensions, number of bosons and g(r), an array of form (dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4])
# Use all that to figure out the mean-field solution's CHERN NUMBER, bose occupation
using LinearAlgebra
using FFTW

function get_UV(g_k,r) # r is the undetermined angle, it is [0,1]
    # output is 2D x D, first D rows are V and second D rows are U.
    
    # say that g_k is DxD. Then construct D vectors of size 2D and ortho-normalize
    D = size(g_k)[1]

    vectors=zeros(ComplexF64,(2*D,D))

    vectors[1:D,:].=-transpose(g_k) .* cos(π*r/2)
    vectors[D+1:2*D,:]=convert.(ComplexF64,Matrix(I,(D,D))).*sin(π*r/2)
    return Matrix(qr(vectors,ColumnNorm()).Q) # basically given a g_k and a scale, find U_k and V_k
end

function get_nk(UV_k)
    D = size(UV_k)[2]

    Vk = UV_k[1:D,1:D]

    return real(tr(Vk'*Vk))
end

# have a big array. Note that g_fourier is shape (dims[1],dims[2],D,D).
function get_total_n(g_fourier,r)
    nX=size(g_fourier)[1]
    nY=size(g_fourier)[2]
    
    as = [(x,y) for x in 1:nX, y in 1:nY]

    ns = map(xv -> get_nk(get_UV(g_fourier[xv[1],xv[2],:,:],r)), as)
    return sum(ns)
end

function find_r(g_fourier,wanted_MF_N_Particles;epsilon=1e-7) # the epsilon is the max uncertainty in 'r'
    # do bisection. 

    lb=0.0
    ub=1.0 # to avoid

    while ub-lb > epsilon
        currN = get_total_n(g_fourier,(ub+lb)/2)
        if currN>wanted_MF_N_Particles
            # want to increase the 'r' range.
            lb = (ub+lb)/2
        else
            ub = (ub+lb)/2
        end
    end

    finalr = (ub+lb)/2
    return finalr, get_total_n(g_fourier,finalr)
end

function get_berry_chern(vs) # the first two indices are momenta, the last are (2*D,D)... The D indexes eigenvectors with 2D components
    Nx = size(vs)[1]
    Ny = size(vs)[2]

    berries = zeros(Float64,(Nx,Ny))

    for a in 1:Nx, b in 1:Ny
        ap = mod(a,Nx)+1
        bp = mod(b,Ny)+1

        VB = vs[a,b,:,:]
        VX = vs[ap,b,:,:]
        VXY = vs[ap,bp,:,:]
        VY = vs[a,bp,:,:]

        U12 = VX'*VB
        U23 = VXY' * VX
        U34 = VY' * VXY
        U41 = VB'*VY

        holonomy = det(U12)*det(U23)*det(U34)*det(U41)
        berries[a,b] = angle(holonomy)/(2*π)
    end

    # as you already divided by 2pi, the sum is already the Chern!
    return sum(berries), berries
end

function antisymmetrise_g_f(gfun)
    antisym_g = zeros(ComplexF64,size(gfun))
    
    
    for xval in 1:size(gfun)[1],yval in 1:size(gfun)[2], p1val in 1:size(gfun)[3], p2val in 1:size(gfun)[4]
        minusX = mod(-xval-1,size(gfun)[1])+1
        minusY = mod(-yval-1,size(gfun)[2])+1 
        antisym_g[xval,yval,p1val,p2val] = 0.5*(gfun[xval,yval,p1val,p2val] - gfun[minusX,minusY,p2val,p1val])
    end
    return antisym_g
end


function compute_properties(g_real,dims;NR_MF_PART=nothing) # the full thing you call from elsewhere
    # ensure antisyymetry
    g_real = antisymmetrise_g_f(g_real)
    # if not specified, assume bosons fill one band
    if NR_MF_PART==nothing
        NR_MF_PART = dims[1]*dims[2]*dims[4] #the final factor is # partons.
    end
    
    # F.T. g_real to get g_fourier
    g_fourier = zeros(ComplexF64,size(g_real))
    for a in 1:size(g_real)[3], b in 1:size(g_real)[4]
        g_fourier[:,:,a,b]=fft(circshift(g_real[:,:,a,b],[1,1]))
    end
    # now find the proper 'r' value
    ratio_val,totnr = find_r(g_fourier,NR_MF_PART)

    # given this 'r', compute Uk's and Vk's

    D = size(g_fourier)[3]
    UVs = zeros(ComplexF64,(dims[1],dims[2],2*D,D))
    Delta_Ks = zeros(ComplexF64,(dims[1],dims[2],D,D))
    
    Number_Ks = zeros(ComplexF64,(dims[1],dims[2]))

    for kx in 1:dims[1], ky in 1:dims[2]
        UVs[kx,ky,:,:]=get_UV(g_fourier[kx,ky,:,:],ratio_val)
        # the pairing Delta_k is just U^\dagger * V.
        # but must remember that U,V are transposed in the UV thing, so UNDO that here!
        Number_Ks[kx,ky] = get_nk(UVs[kx,ky,:,:])
        Delta_Ks[kx,ky,:,:]=conj.(UVs[kx,ky,D+1:2*D,:]) * transpose(UVs[kx,ky,1:D,:])
    end


    Delta_Rs = zeros(ComplexF64,size(Delta_Ks))
    for a in 1:D, b in 1:D
        Delta_Rs[:,:,a,b]=circshift(ifft(Delta_Ks[:,:,a,b]),[-1,-1]) # shift back to your convention!
    end

    chern_nr, berries = get_berry_chern(UVs)

    # the delta_Rs should be symmetric already, but do it just in case here
    return chern_nr,antisymmetrise_g_f(Delta_Rs),Delta_Ks,Number_Ks,berries
end

function correct_g_scale(g_real,dims;NR_MF_PART=nothing)
    # ensure antisyymetry
    g_real = antisymmetrise_g_f(g_real)
    # if not specified, assume bosons fill one band
    if NR_MF_PART==nothing
        NR_MF_PART = dims[1]*dims[2]*dims[4] #the final factor is # partons.
    end
    
    # F.T. g_real to get g_fourier
    g_fourier = zeros(ComplexF64,size(g_real))
    for a in 1:size(g_real)[3], b in 1:size(g_real)[4]
        g_fourier[:,:,a,b]=fft(circshift(g_real[:,:,a,b],[1,1]))
    end
    # now find the proper 'r' value
    ratio_val,totnr = find_r(g_fourier,NR_MF_PART)

    # need to multiply 'g' by this!
    return cot(ratio_val*π/2) 
end


# Nx=10
# Ny=10
# g_real = antisymmetrise_g_f(randn(ComplexF64,(Nx,Ny,8,8)))

# Chern,delta,nrks,berries= compute_properies(g_real,[Nx,Ny,4,2])
# println("Chern: $Chern")
# delta[Nx,Ny,:,:]