include("quencher_IS.jl")

whichone = 1
if length(ARGS)>0
    whichone = parse(Int64,ARGS[1])
end

function dothething(whichone)

options = [(1, vcat([0,0],0:0.1:0.9)), (1,vcat([1.0,1.0],1.0:0.1:2.0)),(-1, vcat([0,0],0:0.1:0.9)), (-1,vcat([1,1],1:0.1:2.0))]

factor_term_to_use,hamparams = options[whichone]

old_output = nothing
for hamp in hamparams
    old_output=run_quencher(hamp,TERMFACTOR=factor_term_to_use,input_file=old_output)
end

end

dothething(whichone)
