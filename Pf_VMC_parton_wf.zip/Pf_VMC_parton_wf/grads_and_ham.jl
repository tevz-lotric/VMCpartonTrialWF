include("WF_computation.jl")
include("linear_alg_lib.jl")
using Random

# Result is divided by the WF already!!
# and the returned thing are the CONJUGATE gradients!
function get_all_gradients(positions::Vector{Vector{Int64}},invG,dims)
    gradients = zeros(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4],dims[5],dims[5]))

    N = length(positions)
    
    Xs = getindex.(positions,1)
    Ys = getindex.(positions,2)

    # compute pairwise differences:
    deltaXs = mod.(Xs .-transpose(Xs) .- 1, dims[1]).+1 # the shift by 1 to ensure that 0 lands onto dims[1]...
    deltaYs = mod.(Ys .-transpose(Ys) .- 1, dims[2]).+1 # the shift by 1 to ensure that 0 lands onto dims[1]...

    for a in 1:N, ap in 1:dims[4]
        for b in 1:N, bp in 1:dims[4]
            aid = (ap-1)*dims[3]+positions[a][3] # find the g-index 1...KU from the parton ID and the UC ID.
            bid = (bp-1)*dims[3]+positions[b][3]
            
            # the grads of this specific distance get a contribution. Do a (-1) since you did a transpose of a skew-sym matrix
            # also do *1 = *0.5 *2 since you get a + and a - contribution for each!
            gradients[deltaXs[a,b],deltaYs[a,b],aid,bid,positions[a][4],positions[b][4]] -= conj(invG[(a-1)*dims[4]+ap,(b-1)*dims[4]+bp])
        end
    end

    return gradients
end

function get_all_gradients_inplace(positions::Vector{Vector{Int64}},invG,dims,gradients) # you should pass the container as an argument....
    gradients = zeros(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4],dims[5],dims[5]))

    N = length(positions)
    
    Xs = getindex.(positions,1)
    Ys = getindex.(positions,2)

    # compute pairwise differences:
    deltaXs = mod.(Xs .-transpose(Xs) .- 1, dims[1]).+1 # the shift by 1 to ensure that 0 lands onto dims[1]...
    deltaYs = mod.(Ys .-transpose(Ys) .- 1, dims[2]).+1 # the shift by 1 to ensure that 0 lands onto dims[1]...

    for a in 1:N, ap in 1:dims[4]
        for b in 1:N, bp in 1:dims[4]
            aid = (ap-1)*dims[3]+positions[a][3] # find the g-index 1...KU from the parton ID and the UC ID.
            bid = (bp-1)*dims[3]+positions[b][3]
            
            # the grads of this specific distance get a contribution. Do a (-1) since you did a transpose of a skew-sym matrix
            # also do *1 = *0.5 *2 since you get a + and a - contribution for each!
            gradients[deltaXs[a,b],deltaYs[a,b],aid,bid,positions[a][4],positions[b][4]] -= invG[(a-1)*dims[4]+ap,(b-1)*dims[4]+bp]
        end
    end
end


# this encodes the FULL PARTICLE Hamiltonian ----------------------------------------------------------------------

# should be a list of moves: each move is [Ending_IND,Starting_IND,EndX-StartX,EndY-StartY, AMPLITUDE]
# sorted by STARTING_IND
# note the amplitude should include the overall (-1) factor in front!

# the valid moves now have only two valid i
function get_valid_moves_hex(t,tprime,tpp)

    valid_moves = [
        Dict("End" => 1, "Start" => 1, "Dx" => 0, "Dy" => 1,"amplitude"=>-conj(tprime)), #OK
        
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => 0,"amplitude"=>-t), #OK
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => 1,"amplitude"=>-tpp), #OK
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => -1,"amplitude"=>-tpp), #OK

        Dict("End" => 2, "Start" => 1, "Dx" => -2, "Dy" => 1,"amplitude"=>-tpp), #OK

        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => 0,"amplitude"=>-tprime), #OK
        Dict("End" => 1, "Start" => 1, "Dx" => -1, "Dy" => 1,"amplitude"=>-tprime), #OK

        
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => 0,"amplitude"=>-t), #OK
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => 1,"amplitude"=>-t), #OK

        Dict("End" => 2, "Start" => 2, "Dx" => 0, "Dy" => 1,"amplitude"=>-tprime), #OK

        Dict("End" => 2, "Start" => 2, "Dx" => -1, "Dy" => 1,"amplitude"=>-conj(tprime)), #OK
        Dict("End" => 2, "Start" => 2, "Dx" => -1, "Dy" => 0,"amplitude"=>-tprime), #OK
    ]

    # Now ensure this is hermitian [ADD REVERSE MOVES!]
    L = length(valid_moves)
    for moveID in 1:L #have to do this, otherwise you get an infinite loop...
        move = valid_moves[moveID]
        reverseDir = Dict("Start"=>move["End"],"End"=>move["Start"],"Dx"=>-move["Dx"],"Dy"=>-move["Dy"],"amplitude"=>conj(move["amplitude"]))
        #print(reverseDir)
        push!(valid_moves,reverseDir)
    end

    sort!(valid_moves,by=x->x["End"]) # sort by the end of the move...

    return valid_moves, 2 # the 2 means two sites per uc end
end


function get_valid_moves_checkerboard(t,t1p,t2p,tpp)
    # from [42] with a (-1) sign to make flatband the bottom!

    valid_moves = [
        # first NN
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => 0,"amplitude"=>conj(t))
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => 0,"amplitude"=>t)
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => -1,"amplitude"=>t)
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => -1,"amplitude"=>conj(t))
        # this is NNN        
        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => 0,"amplitude"=>t1p)
        Dict("End" => 1, "Start" => 1, "Dx" => 0, "Dy" => 1,"amplitude"=>t2p)
        Dict("End" => 2, "Start" => 2, "Dx" => 1, "Dy" => 0,"amplitude"=>t2p)
        Dict("End" => 2, "Start" => 2, "Dx" => 0, "Dy" => 1,"amplitude"=>t1p)
        # finally NNNN 
        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => 1,"amplitude"=>tpp)
        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => -1,"amplitude"=>tpp)
        Dict("End" => 2, "Start" => 2, "Dx" => 1, "Dy" => 1,"amplitude"=>tpp)
        Dict("End" => 2, "Start" => 2, "Dx" => 1, "Dy" => -1,"amplitude"=>tpp)
    ]

    # Now ensure this is hermitian [ADD REVERSE MOVES!]
    L = length(valid_moves)
    for moveID in 1:L #have to do this, otherwise you get an infinite loop...
        move = valid_moves[moveID]
        reverseDir = Dict("Start"=>move["End"],"End"=>move["Start"],"Dx"=>-move["Dx"],"Dy"=>-move["Dy"],"amplitude"=>conj(move["amplitude"]))
        #print(reverseDir)
        push!(valid_moves,reverseDir)
    end

    sort!(valid_moves,by=x->x["End"]) # sort by the end of the move...

    return valid_moves, 2 # the 2 means two sites per uc 
end


# need to make it work for both
function increase_unitcell(base_cell_movesandsize,multipliers)
    multiplier_x,multiplier_y=multipliers

    base_cell_moves,base_cell_size = base_cell_movesandsize
    
    big_moves = []

    for move in base_cell_moves
        for shift_x_of_start in 1:multiplier_x, shift_y_of_start in 1:multiplier_y
            shift_x_of_end = shift_x_of_start + move["Dx"]
            shift_y_of_end = shift_y_of_start + move["Dy"]

            final_Dx = floor(Int64,(shift_x_of_end-1+0.01)/multiplier_x)
            final_Dy = floor(Int64,(shift_y_of_end-1+0.01)/multiplier_y)

            shift_x_of_end = mod(shift_x_of_end-1,multiplier_x)+1
            shift_y_of_end = mod(shift_y_of_end-1,multiplier_y)+1

            startID = move["Start"]+base_cell_size*(shift_y_of_start-1) + base_cell_size*multiplier_y*(shift_x_of_start-1)
            endID = move["End"]+base_cell_size*(shift_y_of_end-1) + base_cell_size*multiplier_y*(shift_x_of_end-1)

            push!(big_moves,Dict("End"=>endID,"Start"=>startID,"Dx"=>final_Dx,"Dy"=>final_Dy,"amplitude"=>move["amplitude"]))


        end
    end

    return big_moves
end

function increase_unitcell_interactions(base_cell_movesandsize,multipliers)
    multiplier_x,multiplier_y=multipliers

    base_cell_moves,base_cell_size = base_cell_movesandsize
    
    big_moves = []

    for move in base_cell_moves
        for shift_x_of_start in 1:multiplier_x, shift_y_of_start in 1:multiplier_y
            shift_x_of_end = shift_x_of_start + move["dx"]
            shift_y_of_end = shift_y_of_start + move["dy"]

            final_Dx = floor(Int64,(shift_x_of_end-1+0.01)/multiplier_x)
            final_Dy = floor(Int64,(shift_y_of_end-1+0.01)/multiplier_y)

            shift_x_of_end = mod(shift_x_of_end-1,multiplier_x)+1
            shift_y_of_end = mod(shift_y_of_end-1,multiplier_y)+1

            startID = move["startIND"]+base_cell_size*(shift_y_of_start-1) + base_cell_size*multiplier_y*(shift_x_of_start-1)
            endID = move["endIND"]+base_cell_size*(shift_y_of_end-1) + base_cell_size*multiplier_y*(shift_x_of_end-1)

            push!(big_moves,Dict("endIND"=>endID,"startIND"=>startID,"dx"=>final_Dx,"dy"=>final_Dy,"Strength"=>move["Strength"]))

        end
    end

    return big_moves
end


# END of full particle Hamiltonian definition ----------------------------------------------------------------------


# Should return (H_j PSI) / PSI  for j = ID_of_mover!!
function ham_move_one(ID_of_mover,positions,g_inv,gfunct,validMoves,dims,BCs) #the scale factor tells you what to do in pf.
    Hamvalue = 0.0 + 0.0*im
    origX,origY,pos_in_UC,whichTERM = positions[ID_of_mover]

    for move in validMoves
        if pos_in_UC==move["End"]
            # modified the Hamiltonian to include ALL the terms...
            currUC=move["Start"]
            currX=origX-round(Int64,move["Dx"])# - sign as the otherpos is start and positions is end...
            currY=origY-round(Int64,move["Dy"])


            # now add a CONTINIOUS FACTOR IF YOU WANT ABC
            BCFACTOR = 1+0*im
            if BCs[1]<0
                fraction_delta_x = 
                BCFACTOR*=exp(im*π*(origX-currX)/dims[1])               
            end
            if BCs[2]<0
                BCFACTOR*=exp(im*π*(origY-currY)/dims[2])               
            end

            currX = mod(currX-1,dims[1])+1
            currY = mod(currY-1,dims[2])+1


            # now get the relative WF value...
            Hamvalue+=BCFACTOR*move["amplitude"]*update_pfaffian(ID_of_mover,[currX,currY,currUC,whichTERM],g_inv,gfunct,positions,dims)
        end
    end
    # finally, re-normalize this so that the typical magnitude is independent of how many terms you are taking!
    return Hamvalue
end

# a fast H on Psi. Note that this one returns (Hamiltonian on Psi ) / Hamiltonian 
function full_hop_ham(positions,g_inverse,gfunct,validMoves_p,dims;fraction_particles_to_do=1,boundary_cs=(1,1))
    
    Npart = length(positions)
    nr_to_use = round(Int64,fraction_particles_to_do*Npart) # can randomly select a subset of particles to be faster!
    if nr_to_use<1
        nr_to_use=1
    end
    if nr_to_use>Npart
        nr_to_use=Npart
    end

    # always look at energy per particle... Should not be the biggest deal ever, just a scale factor!
    return mapreduce(x->ham_move_one(x,positions,g_inverse,gfunct,validMoves_p,dims,boundary_cs),+,randperm(length(positions))[1:nr_to_use])/nr_to_use
end

# attempt at same as above but with less memory
function full_hop_ham_smallmalloc(positions,g_inv,gfunct,validMoves,dims;fraction_particles_to_do=1,boundary_cs=(1,1))

    delta_bin = zeros(ComplexF64,(length(positions)*dims[4],dims[4]))
    btg_bin = zeros(ComplexF64,(2*dims[4],2*dims[4]))

    Npart = length(positions)
    nr_to_use = round(Int64,fraction_particles_to_do*Npart) # can randomly select a subset of particles to be faster!
    if nr_to_use<1
        nr_to_use=1
    end
    if nr_to_use>Npart
        nr_to_use=Npart
    end

    # always look at energy per particle... Should not be the biggest deal ever, just a scale factor!
    Hsum = 0.0+0.0*im
    allocCum = 0
    
    for ID_of_mover in randperm(length(positions))[1:nr_to_use]
        origX,origY,pos_in_UC,whichTERM = positions[ID_of_mover]

        for move in validMoves
            if pos_in_UC==move["End"]
                # modified the Hamiltonian to include ALL the terms...
                currX=origX-round(Int64,move["Dx"])# - sign as the otherpos is start and positions is end...
                currY=origY-round(Int64,move["Dy"])
    
    
                # now add a CONTINIOUS FACTOR IF YOU WANT ABC
                BCFACTOR = 1+0*im
                if boundary_cs[1]<0
                    BCFACTOR*=exp(im*π*(origX-currX)/dims[1])               
                end
                if boundary_cs[2]<0
                    BCFACTOR*=exp(im*π*(origY-currY)/dims[2])               
                end
    
                currX = mod(currX-1,dims[1])+1
                currY = mod(currY-1,dims[2])+1    
    
                # now get the relative WF value...
                hterm,allocterm=update_pfaffian_in_bin(ID_of_mover,[currX,currY,move["Start"],whichTERM],g_inv,gfunct,positions,dims,delta_bin,btg_bin)

                Hsum+=BCFACTOR*move["amplitude"]*hterm
                allocCum+=allocterm
            end
        end
    end

    return Hsum/nr_to_use, allocCum
end


# do function which give the ONE-SIDED interaction terms..

function nicemod(x,M)
    return sign(x)* ( (abs(x)+3*M/2)%M -M/2)
end


# do an interaction one
function full_interaction_HAM(positions::Vector{Vector{Int64}}, interaction_terms, dims) # WF doesnt matter here if you assume your Monte Carlo is sampling correctly    
    # Take both positions, check if their locations are meant to interact, add the interaction strength to the cumulant
    ham_cumulant = 0.0
    
    L = length(positions)

    diffX,diffY,startUC,endUC = 0,0,1,1

    for a in 1:L, b in 1:L
        diffX = positions[a][1]-positions[b][1]
        diffY = positions[a][2]-positions[b][2]

        startUC = positions[b][3]
        endUC = positions[a][3]
        # now increase the diffs, ie need diffUC to be 1 or 2, the rest of the factor must be added to diffX... 

        # diffX = nicemod(diffX,dims[1])
        # diffY = nicemod(diffY,dims[2])

        for int in interaction_terms
            # another issiue: for very small systems, if eg the size in a given direction is one, then need to be careful of that wrt
            dxoffset = mod(diffX-int["dx"],dims[1])
            dyoffset = mod(diffY-int["dy"],dims[2])
            if iszero(dxoffset) && iszero(dyoffset) && iszero(startUC-int["startIND"]) && iszero(endUC-int["endIND"])
                ham_cumulant+=int["Strength"]
            end
        end
    end
    return ham_cumulant/L # DOUBLE CHECK - IS THIS THE NORMALIZATION YOU WANT?
end

function get_interactions_checkerboard(V1,V2) # MAKE IT ONE-WAY ONLY! FUNCTIOJN ABOVE SYMMETRIZES ANYWAY!
    valid_moves = [
        Dict("startIND" => 1, "endIND" => 2, "dx" => 0, "dy" => 0,"Strength"=>V1),
        Dict("startIND" => 1, "endIND" => 2, "dx" => -1, "dy" => 0,"Strength"=>V1),
        Dict("startIND" => 1, "endIND" => 2, "dx" => 0, "dy" => -1,"Strength"=>V1),
        Dict("startIND" => 1, "endIND" => 2, "dx" => -1, "dy" => -1,"Strength"=>V1),

        Dict("startIND" => 1, "endIND" => 1, "dx" => 1, "dy" => 0,"Strength"=>V2),
        Dict("startIND" => 1, "endIND" => 1, "dx" => 0, "dy" => 1,"Strength"=>V2),
        Dict("startIND" => 2, "endIND" => 2, "dx" => 1, "dy" => 0,"Strength"=>V2),
        Dict("startIND" => 2, "endIND" => 2, "dx" => 0, "dy" => 1,"Strength"=>V2)
    ]
    number_sites_per_basis = 2
    return valid_moves, number_sites_per_basis
end

function get_interactions_hex(V1,V2) # MAKE IT ONE-WAY ONLY! FUNCTIOJN ABOVE SYMMETRIZES ANYWAY!
    valid_moves = [

        Dict("endIND" => 2, "startIND" => 1, "dx" => 0, "dy" => 0,"Strength"=>V1),
        Dict("endIND" => 2, "startIND" => 1, "dx" => -1, "dy" => 0,"Strength"=>V1),
        Dict("endIND" => 2, "startIND" => 1, "dx" => -1, "dy" => 1,"Strength"=>V1),

        Dict("endIND" => 1, "startIND" => 1, "dx" => 1, "dy" => 0,"Strength"=>V2),
        Dict("endIND" => 1, "startIND" => 1, "dx" => -1, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 1, "startIND" => 1, "dx" => 0, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 2, "startIND" => 2, "dx" => 0, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 2, "startIND" => 2, "dx" => -1, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 2, "startIND" => 2, "dx" => -1, "dy" => 0,"Strength"=>V2)
    ]
    number_sites_per_basis = 2
    return valid_moves, number_sites_per_basis
end


function compute_boson_expectation_values(positions,g_inverse,gfunct,dims)
    bose_evs = zeros(ComplexF64,(dims[1],dims[2],dims[3],dims[3])) # keep the extended UC for now...


    delta_bin = zeros(ComplexF64,(length(positions)*dims[4],dims[4]))
    btg_bin = zeros(ComplexF64,(2*dims[4],2*dims[4]))

    for particleID in 1:length(positions)
        oldID = positions[particleID][3]
        for newX in 1:dims[1], newY in 1:dims[2], newID in 1:dims[3]
            # for positions (x,y,a) and (X,Y,A), take element  bose_evs[x-X,y-Y,a,A]
            # this particular thing has I think the `b` at (newX,newY,newID) and the `bdagger` at the other!
            DX = mod(newX-positions[particleID][1]-1,dims[1])+1
            DY = mod(newY-positions[particleID][2]-1,dims[2])+1

            bose_evs[DX,DY,newID,oldID]+=update_pfaffian_in_bin(particleID,[newX,newY,newID,positions[particleID][4]],g_inverse,gfunct,positions,dims,delta_bin,btg_bin)[1]
        end
    end
    # hermitian-conjugate and return the value PER PARTICLE!
    return 0.5*(bose_evs+0.5*bose_evs)/length(positions)

end


# a quick gradient checker...

# dims = [3,5,4,2]

# positions = [rand(1:1000,3) for _ in 1:15]
# for j in 1:length(positions)
#     positions[j][1]=mod(j,dims[1])+1
#     positions[j][3]=mod(positions[j][3]-1,dims[3])+1
# end


# g_funct = randn(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4]));

# pf,g,ginv=get_wf_g_inv(positions,g_funct,dims)

# maxdiff=0
# allmyder = get_all_gradients(positions,ginv,dims)


# for wX in 1:dims[1], wY in 1:dims[2], wL in 1:dims[3]*dims[4], wR in 1:dims[3]:dims[4]

#     myderivative = allmyder[wX,wY,wL,wR]

#     epsilon = 1e-6
#     ng = copy(g_funct)

#     # must do this to ensure anti-symmetry onwards (as you only use one component in your calc!)
#     ng[wX,wY,wL,wR]+=epsilon
#     mwX = mod(-wX-1,dims[1])+1
#     mwY = mod(-wY-1,dims[2])+1 
#     ng[mwX,mwY,wR,wL]-=epsilon

#     npf, ngg,nginv = get_wf_g_inv(positions,ng,dims)


#     finite_diff = (npf/pf-1)/epsilon

#     finite_diff/myderivative

#     diff = abs(finite_diff-myderivative)
#     if diff>maxdiff
#         maxdiff=diff
#     end
# end
# println(maxdiff)

# suma = 0+0*im
# fract = 0.8
# Nruns =round(Int64,50/fract)

# for _ in 1:Nruns
#     suma+=full_hop_ham(positions,g,g_funct,pf,1,get_valid_moves_hex(1,0.3,0.1),dims,fraction_particles_to_do=fract)
# end

# println(suma/Nruns)