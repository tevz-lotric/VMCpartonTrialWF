using LinearAlgebra
using SkewLinearAlgebra
# g_funct setup: g[X,Y,A,B,s,s'] is g_[A,B](r) where r=(X,Y). The r=(0,0) is really (X,Y)=(dims[1],dims[2])...
# A,B run 1...KU.
# s,s' run 1...CHI (the rank of the SVD decomposition)
# positions are x,y,I where I=1...U is the index within a unit cell.
# Index I of parton P has A = (P-1)*U+I

# the UC dimension 'U' should ALREADY BE THE DOUBLED UNIT-CELL!!

# dims = [Nx, Ny, U, K,CHI]... So dims[4] is the number of partons!!

# positions is a vector of [x,y,UC,s] where the `s` indicates the color at that position...

# constructs the g_ij matrix, computes its pfaffian and inverse. Returns Pf(g), g, inv(g).
function get_wf_g_inv(positions::Vector{Vector{Int64}},g_funct,dims;scale_factor=1)

    N = length(positions)
    Np = N*dims[4]

    # automatically quit if two positions coincide...
    usepositions = deepcopy(positions)
    sort!(usepositions) # does not matter if we shap positions anyway. Sorting is faster than pairwise comparison!
    diff = usepositions[2:N]-usepositions[1:N-1]
    if any(diff.==[[0,0,0,0]])
        return 0, Matrix(I,(Np,Np))*(1+0*im),Matrix(I,(Np,Np))*(1+0*im)
    end


    
    Xs = getindex.(positions,1)
    Ys = getindex.(positions,2)

    # compute pairwise differences:
    deltaXs = mod.(Xs .-transpose(Xs) .- 1, dims[1]).+1 # the shift by 1 to ensure that 0 lands onto dims[1]...
    deltaYs = mod.(Ys .-transpose(Ys) .- 1, dims[2]).+1 # the shift by 1 to ensure that 0 lands onto dims[1]...


    g_mat = zeros(ComplexF64,(Np,Np))


    for a in 1:N, ap in 1:dims[4]
        for b in 1:a, bp in 1:dims[4]
            if a*dims[4]+ap>b*dims[4]+bp # to ensure each pair is added only once
                aid = (ap-1)*dims[3]+positions[a][3] # find the g-index 1...KU from the parton ID and the UC ID.
                bid = (bp-1)*dims[3]+positions[b][3]
                
                g_mat[(a-1)*dims[4]+ap,(b-1)*dims[4]+bp]=g_funct[deltaXs[a,b],deltaYs[a,b],aid,bid,positions[a][4],positions[b][4]]
                g_mat[(b-1)*dims[4]+bp,(a-1)*dims[4]+ap]=-g_funct[deltaXs[a,b],deltaYs[a,b],aid,bid,positions[a][4],positions[b][4]]# to anti-symmetrize

            end
        end
    end

    # for some reason the matrix is not yet skew-symmetric...
    g_matAS = 0.5*(g_mat-transpose(g_mat))*scale_factor*sqrt(dims[4]/N)
    try
        pf=pfaffian!(g_matAS)
        return pf, g_mat, inv(g_mat)
    catch x 
        throw("$x. FYI, det psi is $(det(g_mat)).")
    end
end

# function get_g_inv(positions::Vector{Vector{Int64}},g_funct,dims)

#     N = length(positions)
#     Np = N*dims[4]

#     # automatically quit if two positions coincide...
#     usepositions = deepcopy(positions)
#     sort!(usepositions) # does not matter if we shap positions anyway. Sorting is faster than pairwise comparison!
#     diff = usepositions[2:N]-usepositions[1:N-1]
#     if any(diff.==[[0,0,0,0]])
#         return Matrix(I,(Np,Np))*(1+0*im)
#     end


    
#     Xs = getindex.(positions,1)
#     Ys = getindex.(positions,2)

#     # compute pairwise differences:
#     deltaXs = mod.(Xs .-transpose(Xs) .- 1, dims[1]).+1 # the shift by 1 to ensure that 0 lands onto dims[1]...
#     deltaYs = mod.(Ys .-transpose(Ys) .- 1, dims[2]).+1 # the shift by 1 to ensure that 0 lands onto dims[1]...


#     g_mat = zeros(ComplexF64,(Np,Np))


#     for a in 1:N, ap in 1:dims[4], bp in 1:dims[4]
#         for b in 1:a
#             if a*dims[4]+ap>b*dims[4]+bp # to ensure each pair is added only once
#                 aid = (ap-1)*dims[3]+positions[a][3] # find the g-index 1...KU from the parton ID and the UC ID.
#                 bid = (bp-1)*dims[3]+positions[b][3]
                
#                 g_mat[(a-1)*dims[4]+ap,(b-1)*dims[4]+bp]=g_funct[deltaXs[a,b],deltaYs[a,b],aid,bid,positions[a][4],positions[b][4]]
#                 g_mat[(b-1)*dims[4]+bp,(a-1)*dims[4]+ap]=-g_funct[deltaXs[a,b],deltaYs[a,b],aid,bid,positions[a][4],positions[b][4]]# to anti-symmetrize

#             end
#         end
#     end
#     return inv(g_mat)
# end

# # dims = [10,10,4,2]

# # positions = [rand(1:1000,3) for _ in 1:50]
# # for j in 1:length(positions)
# #     positions[j][3]=mod(positions[j][3]-1,dims[3])+1
# # end


# # g_funct = randn(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4]));

# # pf,g,ginv=get_wf_g_inv(positions,g_funct,dims)

