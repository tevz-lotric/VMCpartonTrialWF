include("WF_computation.jl")
include("grads_and_ham.jl")
include("linear_alg_lib.jl")

using ProgressMeter

# Given current wavefunction parameters and some initial position,
# sample Monte Carlo and return the objects of interest for the optimizer.
# also return the position where you end up...

# needs a given g_{ss'} for all color indices - it should be another function which is concerned with how to set those up!
function MC_sample(NR_RUNS,NR_WARMUP,Pos,g_function,dims,validMoves,interactions;fraction_particles_hopping=1.0,BCs=(1,1),pfaffian_scale_factor = 1.0,collect_bose_data=false,factor_in_sum_of_terms=1)
    CALLTIME = time()
    HAMTIME = 0
    CUMULATETIME = 0
    INVTIME = 0
    
    # memory allocation logs
    Ham_allocated = 0
    Only_PF_alloc = 0
    Grad_allocated = 0
    Step_allocated = 0

TOT_ALLOCATED = @allocated begin

    # make local copies, hopefully makes everything faster, idk?
    # g_function = deepcopy(g_function_pointer)
    # dims = deepcopy(dims_pointer)
    # validMoves = deepcopy(validMoves_pointer)
    # interactions =deepcopy(interactions_pointer)

    
    # # the Pos is the {s} configuration actually used. The PosPrime is the {s'} which only matters for the metric..
    # Pos = deepcopy(initial_positions) # the intiial_positions should be [x,y,UC,s,s'], so all the indices...
    # # copy in order to have it LOCALLY in the memory.
    
    L = length(Pos)

    # keep it as a vector to be able to do the 'S' inversion sensibly.
    gradCum = zeros(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4],dims[5],dims[5]))
    eConjgradCum =zeros(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4],dims[5],dims[5]))
    eCum = 0.0 + 0.0*im
    PHASE_NORM_CUM = 0.0+0.0*im
    boseCUM = zeros(ComplexF64,(dims[1],dims[2],dims[3],dims[3]))

    currGrad = zeros(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4],dims[5],dims[5]))
    currE = 0.0 + 0.0*im
    currPsi = 1.0 + 0.0*im
    curr_PHASE_NORM = 0.0+0.0*im
    currBOSE = zeros(ComplexF64,(dims[1],dims[2],dims[3],dims[3]))


    curr_INTEGRAL_PHASE = 1.0+0.0*im # phase dependent on the two configurations of {s} and {s'} used...


    # if you did NOT make a move!
    USE_OLD_VALS_H = false 
    USE_OLD_VALS_GRAD = false

    # only start cumulating AFTER you reach a nonzero psi
    NR_CUMULATED = 0

    POSs = getindex.(Pos,[[1,2,3,4]])
    POSsprime = getindex.(Pos,[[1,2,3,5]])

    function shiftpos(positions)
        newpos = deepcopy(positions)
        for j in 1:length(newpos)
            newpos[j][3]+=2
            while newpos[j][3]>dims[3]
                newpos[j][1]+=1
                newpos[j][3]-=dims[3]
            end
            while newpos[j][1]>dims[1]
                newpos[j][1]-=dims[1]
            end
        end
        return newpos
    end
    
    POSsS = shiftpos(POSs)
    POSsprimeS = shiftpos(POSsprime)

    # do the first inverse now already as later on you always do it AFTER the move...
    pfPos,gmat,g_matrix_inverse=get_wf_g_inv(POSs,g_function,dims,scale_factor=pfaffian_scale_factor)
    pfPosS,gmatS,g_matrix_inverseS=get_wf_g_inv(POSsS,g_function,dims,scale_factor=pfaffian_scale_factor)


    # this way to get the {s'} coordinates...
    pfPosPrime,gprime,g_prime_inverse = get_wf_g_inv(POSsprime,g_function,dims,scale_factor=pfaffian_scale_factor)
    pfPosPrimeS,gprimeS,g_prime_inverseS = get_wf_g_inv(POSsprimeS,g_function,dims,scale_factor=pfaffian_scale_factor)

    # also do the first angle
    curr_INTEGRAL_PHASE = cis(angle(pfPos+factor_in_sum_of_terms*pfPosS)-angle(pfPosPrime+factor_in_sum_of_terms*pfPosPrimeS))

    PSI_MAGNITUDE_CUM = 0.0
    NR_PSI_LOGGED = 0

    Loop_start_time = time()
    ind = 1
    while ind<=NR_RUNS+NR_WARMUP

        if !USE_OLD_VALS_H
            ct = time()
            Ham_allocated+= @allocated begin 
            ham1,alloccum1 = full_hop_ham_smallmalloc(POSs,g_matrix_inverse,g_function,validMoves,dims,fraction_particles_to_do=fraction_particles_hopping,boundary_cs = BCs)
            ham2,alloccum2 = full_hop_ham_smallmalloc(POSsS,g_matrix_inverseS,g_function,validMoves,dims,fraction_particles_to_do=fraction_particles_hopping,boundary_cs = BCs)

            ham=(pfPos*ham1+factor_in_sum_of_terms*pfPosS*ham2)/(pfPos+factor_in_sum_of_terms*pfPosS)
            alloccum=alloccum1+alloccum2
            
            ham += full_interaction_HAM(POSs,interactions,dims)
            end
            HAMTIME += time()-ct
            Only_PF_alloc+=alloccum

            # if collect_bose_data
            #     currBOSE=compute_boson_expectation_values(POSs,g_matrix_inverse,g_function,dims)
            # end
            # update curr values. Division by Psi already happens INSIDE!
            currE = ham
        end

        if !USE_OLD_VALS_GRAD
            Grad_allocated+= @allocated begin 
                cg1 = get_all_gradients(POSsprime,g_prime_inverse,dims)
                cg2 = get_all_gradients(POSsprimeS,g_prime_inverseS,dims)
                currGrad .= (pfPosPrime.*cg1 + factor_in_sum_of_terms.*pfPosPrimeS.*cg2)./(pfPosPrime+factor_in_sum_of_terms*pfPosPrimeS)
            end
        end
        
         Step_allocated+=@allocated begin
            
 

        time_spent_at_this_spot = 1
        decided_to_move = false

        while !decided_to_move && ind<=NR_RUNS+NR_WARMUP
            # now decide on a move, do it MAYBE.
            mover_identity = rand(1:L)
            
            Dx=rand(-2:2)
            Dy=rand(-2:2)
            
            newID = rand(1:dims[3])
            
            
            newS_term = rand(1:dims[5])
            newSprime_term = rand(1:dims[5])
            
            # to ensure it is not the same as before...
            
            while (abs(Dx)<0.5 && abs(Dy)<0.5 && abs(newID-Pos[mover_identity][3])<0.5 && abs(newS_term-Pos[mover_identity][4])<0.5 && abs(newSprime_term-Pos[mover_identity][5])<0.5 )
                Dx=rand(-2:2)
                Dy=rand(-2:2)
                
                newID = rand(1:dims[3])
                
                newS_term = rand(1:dims[5])
                newSprime_term = rand(1:dims[5])
                # can do this if you want, might as well to not jump around too much
                if rand()<0.5
                    newS_term = Pos[mover_identity][4]
                else
                    newSprime_term = Pos[mover_identity][5]
                end
                
            end
            
            newX = mod(Pos[mover_identity][1]+Dx-1,dims[1])+1
            newY = mod(Pos[mover_identity][2]+Dy-1,dims[2])+1

            newIDS = newID+2
            newXS = newX
            while newIDS>dims[3]
                newXS = newXS+1
                newIDS -=dims[3]
            end
            newXS = mod(newXS-1,dims[1])+1


            # start timing the `inverse` now !
            ct = time()


            sratio = 1
            if Pos[mover_identity][1:4]!=[newX,newY,newID,newS_term]
                sratio = (pfPos*update_pfaffian(mover_identity,[newX,newY,newID,newS_term],g_matrix_inverse,g_function,POSs,dims) + factor_in_sum_of_terms*pfPosS*update_pfaffian(mover_identity,[newXS,newY,newIDS,newS_term],g_matrix_inverseS,g_function,POSsS,dims))/(pfPos+factor_in_sum_of_terms*pfPosS)
            end

            fullratio=abs(sratio)^2

            if dims[5]>1
                sprimeratio = 1
                if Pos[mover_identity][[1,2,3,5]]!=[newX,newY,newID,newSprime_term]
                    sprimeratio = (pfPosPrime*update_pfaffian(mover_identity,[newX,newY,newID,newSprime_term],g_prime_inverse,g_function,POSsprime,dims)+factor_in_sum_of_terms*pfPosPrimeS*update_pfaffian(mover_identity,[newXS,newY,newIDS,newSprime_term],g_prime_inverseS,g_function,POSsprimeS,dims))/(pfPosPrime+factor_in_sum_of_terms*pfPosPrimeS)
                end
                fullratio=abs(sratio*sprimeratio)
            end

            ind+=1

            if isnan(fullratio) # if currPsi was zero...
                fullratio=1
            end

            if rand()<fullratio
                decided_to_move = true

                # now cumulate!
                #cumulate if Psi is nonzero nd you have done enough warmup...
                if !iszero(currPsi) && ind>NR_WARMUP            
                    ct = time()
                    gradCum.+=time_spent_at_this_spot*currGrad.*curr_INTEGRAL_PHASE # really you are cumulating the conjugate of the gradient. Just easier!
                    eConjgradCum.+=time_spent_at_this_spot*(currE*curr_INTEGRAL_PHASE).*currGrad
                    CUMULATETIME+=time()-ct
                    eCum+=time_spent_at_this_spot*currE*curr_INTEGRAL_PHASE
                    PHASE_NORM_CUM+=time_spent_at_this_spot*curr_INTEGRAL_PHASE # this should really take on the role of NR_CUMULATED
                    NR_CUMULATED+=time_spent_at_this_spot
                    boseCUM+=currBOSE*time_spent_at_this_spot*curr_INTEGRAL_PHASE
                end
        


                # make the move
                # re-compute the inverse here while you still know what is moving
                # JUST DO THE INVERSE,...

                # one or both of these will be turned into false a bit later...
                USE_OLD_VALS_H = true
                USE_OLD_VALS_GRAD = true

                position_changed = (Pos[mover_identity][1:3]!=[newX,newY,newID])
                
                # check separately and only update each one if it actually changed
                if position_changed || Pos[mover_identity][4]!=newS_term

                    Pos[mover_identity][1:4]=[newX,newY,newID,newS_term] # UPDATE POS FIRST TO GET USE THE NEW ONE
                    

                    POSs = getindex.(Pos,[[1,2,3,4]])
                    POSsS = shiftpos(POSs) 
                    
                    pfPos,gmat,g_matrix_inverse=get_wf_g_inv(POSs,g_function,dims,scale_factor=pfaffian_scale_factor)
                    pfPosS,gmatS,g_matrix_inverseS=get_wf_g_inv(POSsS,g_function,dims,scale_factor=pfaffian_scale_factor)


                    USE_OLD_VALS_H = false # actually need to re-compute the entire thing if this changed!     
                    PSI_MAGNITUDE_CUM += abs(pfPos)
                    NR_PSI_LOGGED +=1           
                end
                
                # and now for the other one... Already from the function above can assume the first three indices have been moved!
                if position_changed || Pos[mover_identity][5]!=newSprime_term
                    Pos[mover_identity][[1,2,3,5]]=[newX,newY,newID,newSprime_term] # UPDATE POS FIRST TO GET USE THE NEW ONE


                    POSsprime = getindex.(Pos,[[1,2,3,5]])
                    POSsprimeS =shiftpos(POSsprime)


                    pfPosPrime,gprime,g_prime_inverse = get_wf_g_inv(POSsprime,g_function,dims,scale_factor=pfaffian_scale_factor)
                    pfPosPrimeS,gprimeS,g_prime_inverseS = get_wf_g_inv(POSsprimeS,g_function,dims,scale_factor=pfaffian_scale_factor)

                    USE_OLD_VALS_GRAD = false
                    PSI_MAGNITUDE_CUM += abs(pfPosPrime)
                    NR_PSI_LOGGED +=1           
                end


                # also update the angle. This must be done even if only {s'} moved!
                curr_INTEGRAL_PHASE = cis(angle(pfPos+factor_in_sum_of_terms*pfPosS)-angle(pfPosPrime+factor_in_sum_of_terms*pfPosPrimeS))
            else
                # no move, so just remember that to not wast time re-computing
                USE_OLD_VALS_H = true
                USE_OLD_VALS_GRAD = true
                # another day spent here...
                time_spent_at_this_spot+=1
            end
        end
        INVTIME+=time()-ct

        end #this end is for end of the @allocated for the step!
    end
#    GC.gc()

end
    
    # force a garbage-collector maybe, idk?
    return NR_CUMULATED,PHASE_NORM_CUM,eCum, gradCum, eConjgradCum, boseCUM, Pos, PSI_MAGNITUDE_CUM/NR_PSI_LOGGED, [time()-CALLTIME,time()-Loop_start_time,HAMTIME,CUMULATETIME,INVTIME-CUMULATETIME], [TOT_ALLOCATED,Ham_allocated,Only_PF_alloc,Grad_allocated,Step_allocated]
end

#= 
Now set up some random vectors and positions to see what this thing returns... 
=#

#=
MaxX=4# how many unit cells each way

MaxY=4
NR_UNIT_CELLS = MaxX*MaxY # equals to the number of BOSONS!


# just to try stuff out
RMAT = rand(Int64,(NR_UNIT_CELLS,3))
Positions = deepcopy([RMAT[i,:] for i in 1:size(RMAT,1)])
function goodform(v)
    v[1]=abs((v[1]-1)%MaxX) + 1
    v[2]=abs((v[2]-1)%MaxY) + 1
    v[3]=abs((v[3]-1)%4) + 1
end
map(goodform,Positions)

# ACTUALLY JUST FIX POSITIONS REASONABLY TO START IN A GOOD, NOT HARD-CORE STATE
for a in 1:MaxX
    for b in 1:MaxY
        Positions[(a-1)*MaxY+b][1]=a
        Positions[(a-1)*MaxY+b][2]=b
    end
end       


Rs = randn((NR_UNIT_CELLS,4))+im*randn((NR_UNIT_CELLS,4))
Parton1VecMC = [Rs[i,:] for i in 1:size(Rs,1)]

Rs = randn((NR_UNIT_CELLS,4))+im*randn((NR_UNIT_CELLS,4))
Parton2VecMC = [Rs[i,:] for i in 1:size(Rs,1)]


# SHOULD NOT BE RANDOM BUT WHO CARES...
Ms = pi*randn((NR_UNIT_CELLS,2))
momenta = [Ms[i,:] for i in 1:size(Ms,1)]


get_WF(Positions,Parton1VecMC,Parton2VecMC,momenta)



# RUN THE MC AND SEE WHAT HAPPENS!
NewPos = deepcopy(Positions)

NR_CUMULATED,E,G,EG,VG,NewPos = MC_sample(convert(Int64,200),20,NewPos,Parton1VecMC,Parton2VecMC,momenta,MaxX,MaxY)

=#