function mypad(array,newX,newY,padvalue;newS=nothing)
    currX = size(array)[1]
    currY = size(array)[2]

    currS = size(array)[5]
    if newS == nothing
        newS = currS
    end

    halfX = floor(Int64,currX/2+0.001)
    halfY = floor(Int64,currY/2+0.001)
    
    newarray = randn(ComplexF64,(newX,newY,size(array)[3],size(array)[4],newS,newS)).*padvalue

    # now all four combos...        
    for x in 1:halfX, y in 1:halfY
        if x<=currX && y<=currY
            newarray[x,y,:,:,1:currS,1:currS]=array[x,y,:,:,:,:]
        end
    end
    for x in (halfX+1):currX, y in 1:halfY
        if x+newX-currX>0 && y<=currY
            newarray[x+newX-currX,y,:,:,1:currS,1:currS]=array[x,y,:,:,:,:]
        end
    end
    for x in 1:halfX, y in (halfY+1):currY
        if x<=currX && y+newY-currY>0
            newarray[x,y+newY-currY,:,:,1:currS,1:currS]=array[x,y,:,:,:,:]
        end
    end
    for x in (halfX+1):currX, y in (halfY+1):currY
        if x+newX-currX>0 && y+newY-currY>0
            newarray[x+newX-currX,y+newY-currY,:,:,1:currS,1:currS]=array[x,y,:,:,:,:]
        end
    end

    return newarray
end