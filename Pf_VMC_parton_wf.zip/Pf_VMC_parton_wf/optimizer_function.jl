using .Threads
using UnicodePlots
using DataFrames
using CSV
using ProgressMeter
using LinearAlgebra
using Statistics

include("WF_computation.jl")
include("grads_and_ham.jl")
include("MC_sampler.jl")
include("properties_from_g.jl")

function run_optimizer(adam_params,hamiltonian_params,worker_params,NUMBER_PARTONS,UC_MULTIPLIERs,g_function_input,message;which_hamiltonian="hex",startingPos = nothing,adam_nr_done=nothing,adam_previous_m=nothing,adam_previous_v=nothing,pfaffian_scale_factor=1,FRACTION_HOP=1,boundary_conditions=(1,1),nr_steps_to_compute_bose_correlators=0,factor_in_sum_of_terms=1)

   
   
   
    # parton_decomposition_input: an array of length CHI describing the parton decomposition...
    # each entry is a pair (lambda, [U1,U2,U3]) where lambda is the relative weight and the U's are the parton-entangling matrices, normalized to tr(U^\dag U)=dims[3] 
    # the U's should be mostly local, still need to figure how to store them.


    # DEFINE YOUR MONTE CARLO PARAMETERS HERE....
    each_iteration_per_worker = worker_params["runs_per_worker"]
    each_iteration_nr_workers = worker_params["workers_per_iteration"] # would make sense to have this = nthreads(), but can also be a multiple... 
    # in fact this must be the length of positions!
    
    each_iteration_warmups=0
    if haskey(worker_params,"warmups_per_worker")
        each_iteration_warmups = worker_params["warmups_per_worker"]
    end
    

    TIME_WHEN_RAN_OPTIMIZER= time()
    TOTAL_TIME_MULTITHREADING = 0

    # HAMILTONIAN!!
    validMovesSmall=[]
    interactionTermsSmall = []

    V1=0;V2=0

    if haskey(hamiltonian_params,"V1")
        V1 = hamiltonian_params["V1"]
    end
    if haskey(hamiltonian_params, "V2")
        V2 = hamiltonian_params["V2"]
    end

    if which_hamiltonian=="hex"
        validMovesSmall = get_valid_moves_hex(hamiltonian_params["t"],hamiltonian_params["tprime"],hamiltonian_params["tpp"])
        interactionTermsSmall = get_interactions_hex(V1,V2)
    else
        validMovesSmall = get_valid_moves_checkerboard(hamiltonian_params["t"],hamiltonian_params["tp1"],hamiltonian_params["tp2"],hamiltonian_params["tpp"])
        interactionTermsSmall = get_interactions_hex(V1,V2)
    end
    # HEREEEE EXTEND THE UNIT CELLL!!
    validMoves = increase_unitcell(validMovesSmall,UC_MULTIPLIERs)
    interactionTerms = increase_unitcell_interactions(interactionTermsSmall,UC_MULTIPLIERs)


    # ADAM PARAMETERS
    NUMBER_OPTIMIZER_STEPS = round(Int64,adam_params["Optimizer_steps"])
    adam_Beta1 = adam_params["beta1"]
    adam_Beta2 = adam_params["beta2"]
    adam_epsilon = adam_params["epsilon"]
    adam_gamma_learn_rate = adam_params["Learn_rate"]


    # was gamma=0.005 in [35], COULD BE ALSO A FUNCTION OF IT NR., STH LIKE 1/i, see [33] for why this is good! (basically infinite distance covered but finite var...)

    # x cells are double the size. So want NR_Y ~ 2xNR_X for a roughly square system!
    #NR_BOSONS IS THE PRODUCT OF THESE TWO!
    NUMBER_X_CELLS = hamiltonian_params["NX"]
    NUMBER_Y_CELLS = hamiltonian_params["NY"]


    N_bose = hamiltonian_params["NR_PARTICLES"]

    filling_fraction = N_bose/(NUMBER_X_CELLS*NUMBER_Y_CELLS*UC_MULTIPLIERs[1]*UC_MULTIPLIERs[2])


    dims = [NUMBER_X_CELLS,NUMBER_Y_CELLS,validMovesSmall[2]*UC_MULTIPLIERs[1]*UC_MULTIPLIERs[2],NUMBER_PARTONS,size(g_function_input)[5]]

    # first guess for eigenvectors
    Number_Partons = NUMBER_PARTONS


    # come up with filename



    nrpartons = NUMBER_PARTONS

    bc= ['P','P']
    if boundary_conditions[1]<0
        bc[1]='A'
    end
    if boundary_conditions[2]<0
        bc[2]='A'
    end

    bctext=join(bc)

    identifier_hopping_string = ""

    if which_hamiltonian=="hex"
        t=hamiltonian_params["t"]
        tprime=hamiltonian_params["tprime"]
        tpp=hamiltonian_params["tpp"]
        identifier_hopping_string = "hex,t_$t,tprime_$(abs(tprime)),tpp_$tpp"
    end
    if which_hamiltonian=="checkerboard"
        t=abs(hamiltonian_params["t"])
        phi = angle(hamiltonian_params["t"])
        tp1=hamiltonian_params["tp1"]
        tp2=hamiltonian_params["tp2"]
        tpp=hamiltonian_params["tpp"]

        identifier_hopping_string="checkerboard,t_$t,phi_$phi,tp1_$tp1,tp2_$tp2,tpp_$tpp"
    end

    identifier="$(message),CHI_$(dims[5]),BC_$(bctext),PFAFFIAN_$(nrpartons)partons,filling-$(filling_fraction),V1_$(V1),V2_$(V2),$(identifier_hopping_string),ucfactors_$(UC_MULTIPLIERs[1])x$(UC_MULTIPLIERs[2])_size_$(NUMBER_X_CELLS)x$(NUMBER_Y_CELLS)_nrRuns_$(NUMBER_OPTIMIZER_STEPS)"


    function antisymmetrise_g_f(gfun)
        antisym_g = zeros(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4],dims[5],dims[5]))
        
        for xval in 1:dims[1],yval in 1:dims[2], p1val in 1:dims[3]*dims[4], p2val in 1:dims[3]*dims[4], s in 1:dims[5], sprime in 1:dims[5]
            minusX = mod(-xval-1,dims[1])+1
            minusY = mod(-yval-1,dims[2])+1 
            antisym_g[xval,yval,p1val,p2val,s,sprime] = 0.5*(gfun[xval,yval,p1val,p2val,s,sprime] - gfun[minusX,minusY,p2val,p1val,sprime,s])
        end
        return antisym_g
    end


    g_function = antisymmetrise_g_f(g_function_input)





    function get_some_positions()
        # first find total number of places: 
        nr_sites = NUMBER_X_CELLS*NUMBER_Y_CELLS*UC_MULTIPLIERs[1]*UC_MULTIPLIERs[2]*validMovesSmall[2]


        particle_locs = randperm(nr_sites)[1:N_bose]

        Positions = [[0,0,0,0,0] for _ in 1:N_bose]
        for pn in 1:N_bose
            uc_id=mod(particle_locs[pn]-1,dims[3])+1

            remainder = round(Int64,(particle_locs[pn]-uc_id)/dims[3])
            yid = mod(remainder-1,NUMBER_Y_CELLS)+1

            remainder = round(Int64,(remainder-yid)/dims[2])
            xid = mod(remainder-1,NUMBER_X_CELLS)+1

            Positions[pn]=[xid,yid,uc_id,1,1,] # initialize to the biggest-`s` state always...
            
        end

        return Positions
    end
    # run the above for all workers
    FullPositions = map(x->get_some_positions(),1:each_iteration_nr_workers )

    # can only use the new positions this way
    if startingPos!=nothing
        L = length(startingPos)
        for j in 1:length(FullPositions)
            FullPositions[j]=deepcopy(startingPos[mod(j-1,L)+1])
        end
    end

    # initialize adam's cumulants IN THE SHAPE OF A USUAL g-funct gradient!

    vt = zeros(Float64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4],dims[5],dims[5]))
    mt = zeros(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4],dims[5],dims[5]))

    adam_base = 0 
    if adam_nr_done!=nothing && adam_nr_done>0
        vt = deepcopy(adam_previous_v)
        vm = deepcopy(adam_previous_m)
        adam_base = adam_nr_done
    end


    Energy_EV_LOG = zeros(ComplexF64,NUMBER_OPTIMIZER_STEPS)
    Denominator_value_log = zeros(ComplexF64,NUMBER_OPTIMIZER_STEPS) # the expectation of that < e^{i\theta_{s's}} > thing - if it is <<1, you have a sign problem!
    Chern_nr_log = zeros(Float64,NUMBER_OPTIMIZER_STEPS)
    Steptime_log =zeros(Float64,NUMBER_OPTIMIZER_STEPS)
   
    MCSAMPLERRUNTIMES = [0,0,0,0,0]
    MCALLOCS = [0,0,0,0,0]

    SCALE_FACTOR = 1.0

    bose_cums = zeros(ComplexF64,(dims[1],dims[2],dims[3],dims[3]))
    bose_cumulated = 0.0+0.0*im

    # NOW START THE BIG LOOP!
    for it_nr in 1:NUMBER_OPTIMIZER_STEPS
        tstartiter = time()
        BoseCUM = false
        if it_nr > NUMBER_OPTIMIZER_STEPS-nr_steps_to_compute_bose_correlators
            BoseCUM = true#true
        end
        # first need to find the `entangled` g_{ss} matrix that will be used by these processes
        # no need in this primittive one
        
        # now run the monte carlos. The X iterates over all positions
        currtime = time()

        
        logs = Vector{Any}(undef,each_iteration_nr_workers)
        succesful_runs = zeros(Bool,each_iteration_nr_workers)

        @threads for stp in 1:each_iteration_nr_workers
            #try
                Ncum,phaseCum,eCum,gradCum,econjgradCum,boseCUM,FINALPOS,typical_psi_mag,times,mallocs = MC_sample(each_iteration_per_worker,each_iteration_warmups,FullPositions[stp],g_function,dims,validMoves,interactionTerms,fraction_particles_hopping=FRACTION_HOP,BCs=boundary_conditions,pfaffian_scale_factor=SCALE_FACTOR,collect_bose_data=BoseCUM,factor_in_sum_of_terms=factor_in_sum_of_terms)

                logs[stp] = [Ncum,phaseCum,eCum,gradCum,econjgradCum,boseCUM,FINALPOS,typical_psi_mag,times,mallocs]
                succesful_runs[stp]=true
            # catch x
            #     println("Had issiue on thread $(threadid()), discarding its data. Error code: $x")
            # end
        end



        TOTAL_TIME_MULTITHREADING+=time()-currtime

        # (1) sum cumulants, including MCSAMPLERRUNTIMES!
        Nr_Samples = 0
        Phase_Cumulant = 0.0+0.0*im
        energy_cumulant = 0.0+0.0*im
        grad_cumulant = zeros(ComplexF64,size(g_function))
        eConjgrad_cumulant = zeros(ComplexF64,size(g_function))
        PSIMAG = 0.0

        
        for stp in 1:each_iteration_nr_workers
            if succesful_runs[stp]
                Ncum,phaseCum,eCum,gradCum,econjgradCum,boseCUM,FINALPOS,typical_psi_mag,times,allocs = logs[stp]
                
                Nr_Samples+=Ncum
                Phase_Cumulant+=phaseCum
                energy_cumulant+=eCum
                grad_cumulant+=gradCum
                eConjgrad_cumulant+=econjgradCum
                
                MCSAMPLERRUNTIMES+=times
                MCALLOCS+=allocs
                PSIMAG+=typical_psi_mag/each_iteration_nr_workers
                if BoseCUM
                    bose_cums.+=boseCUM
                    bose_cumulated+=phaseCum
                end
                # and remember the final positions...
                FullPositions[stp] = FINALPOS
            end
        end
        
        # require at least half of the samples to be good to do anything...
        expected_nr_samples = each_iteration_per_worker*each_iteration_nr_workers
        if Nr_Samples<0.5*expected_nr_samples
            println("Did not get enough sampels at step $(it_nr), not updating g.")
        else
            
            
            # (2) compute expectations, nothing that the division should be by that angle-expectaion value! SAVE THE ONES YOU CAN TO THE LOG!
            
            Energy_EV_LOG[it_nr]=energy_cumulant/Phase_Cumulant
            Denominator_value_log[it_nr]=Phase_Cumulant/Nr_Samples
            
            
            # note: the pfaffian takes the scale factor to the power (NBOSE*NPARTONS/2)
            SCALE_FACTOR = SCALE_FACTOR/ ((PSIMAG)^(2/(N_bose*dims[4])))

            # these are the F's used by ADAM...
            # The grad_cumulant is really the CONJUGATE gradient already, so no complication here!
            Fs = eConjgrad_cumulant/Phase_Cumulant - ((grad_cumulant)/Phase_Cumulant) *  (energy_cumulant/Phase_Cumulant)

            # (3) This is the `primitive one` which simply optimizes g_{ss'} with no regard for the actual parton decomposition...
            
            mt = adam_Beta1*mt + (1-adam_Beta1)*Fs
            mtPCorrected = mt/(1-adam_Beta1^(it_nr+adam_base))
            #
            vt = adam_Beta2*vt + (1-adam_Beta2)*(abs.(Fs).^2)
            vtPCorrected = vt/(1-adam_Beta2^(it_nr+adam_base))

        
            adamstep = adam_gamma_learn_rate*mtPCorrected./sqrt.(vtPCorrected.+adam_epsilon)

            if any(isnan.(adamstep)) || any(isinf.(adamstep)) 
                println("Got an invalid adam step at iteration number $(it_nr), re-setting ADAM's cumulants")

                vt = zeros(Float64,size(vt))
                mt = zeros(ComplexF64,size(mt))
            else
                g_function = g_function - adam_gamma_learn_rate*mtPCorrected./sqrt.(vtPCorrected.+adam_epsilon)
                g_function = antisymmetrise_g_f(g_function)
                MV = sqrt(mean(abs.(g_function).^2))
                g_function = g_function/MV
            end


            Chern_nr_log[it_nr],delta_rs,delta_ks,nks,berries=compute_properties(g_function[:,:,:,:,1,1],dims) 
        end

        # (4) ADAM update on all the parameters


        # (5) Re-normalization of the parameters, also re-orthogonalization of the U's?

        dt=time()-tstartiter


        println("Finished iter $it_nr/$NUMBER_OPTIMIZER_STEPS, took total time $(dt/60) minutes. Current energy: $(energy_cumulant/Phase_Cumulant) and Chern:$(Chern_nr_log[it_nr])")
        Steptime_log[it_nr]=dt/60


        # save the logs as you go..
        dfE = DataFrame(Index=1:length(Energy_EV_LOG),Real_Energy=real.(Energy_EV_LOG),Imag_Energy=imag.(Energy_EV_LOG))
        dfE."Denominator"=Denominator_value_log
        dfE."Chern"=Chern_nr_log
        dfE."Time(minutes)"=Steptime_log
        CSV.write("logs/Energies_$identifier.csv",dfE)
    
    
    end

    FirstToShow = 1 #round(Int64,NUMBER_OPTIMIZER_STEPS/4)

    plt=lineplot(FirstToShow:NUMBER_OPTIMIZER_STEPS, real.(Energy_EV_LOG[FirstToShow:NUMBER_OPTIMIZER_STEPS]), title="Optimization of Energy", name="Re", xlabel="Iteration number",ylabel="Energy EV")
    #lineplot!(plt,FirstToShow:NUMBER_OPTIMIZER_STEPS, imag.(Energy_EV_LOG[FirstToShow:NUMBER_OPTIMIZER_STEPS]), name="Im",color=:cyan)

    display(plt)

    # only save the energy for now...
    dfE = DataFrame(Index=1:length(Energy_EV_LOG),Real_Energy=real.(Energy_EV_LOG),Imag_Energy=imag.(Energy_EV_LOG))
    dfE."Denominator"=Denominator_value_log
    dfE."Chern"=Chern_nr_log
    dfE."Time(minutes)"=Steptime_log
    CSV.write("logs/Energies_$identifier.csv",dfE)



    # actually, also save the full g(r)
    dfg = DataFrame(Index=1:dims[1]*dims[2])
    dfg."X"=zeros(Int64,size(dfg)[1])
    dfg."Y"=zeros(Int64,size(dfg)[1])


    for pL in 1:dims[4], pR in 1:dims[4], ucL in 1:dims[3], ucR in 1:dims[3], s in 1:dims[5], sprime in 1:dims[5]
        dfg[!,"P$(pL)_UC$(ucL)_S_$(s)-_P$(pR)_UC$(ucR)_S_$(sprime)"]=zeros(ComplexF64,size(dfg)[1])
    end

    for a in 1:dims[1], b in 1:dims[2]
        row = (a-1)*dims[2]+b

        dfg[row,"X"]=a
        dfg[row,"Y"]=b

        for pL in 1:dims[4], pR in 1:dims[4], ucL in 1:dims[3], ucR in 1:dims[3], s in 1:dims[5], sprime in 1:dims[5]
            dfg[row,"P$(pL)_UC$(ucL)_S_$(s)-_P$(pR)_UC$(ucR)_S_$(sprime)"]=g_function[a,b,(pL-1)*dims[3]+ucL,(pR-1)*dims[3]+ucR,s,sprime]
        end
    end

    gfn = "logs/big_g_function_$identifier.csv"
    CSV.write(gfn,dfg)

    bose_EVS = bose_cums./bose_cumulated
    # actually, also save the full g(r)
    dfb = DataFrame(Index=1:dims[1]*dims[2])
    dfb."X"=zeros(Int64,size(dfb)[1])
    dfb."Y"=zeros(Int64,size(dfb)[1])


    for ucL in 1:dims[3], ucR in 1:dims[3]
        dfb[!,"UC_$(ucL)_UC_$(ucR)"]=zeros(ComplexF64,size(dfb)[1])
    end

    for a in 1:dims[1], b in 1:dims[2]
        row = (a-1)*dims[2]+b

        dfb[row,"X"]=a
        dfb[row,"Y"]=b

        for ucL in 1:dims[3], ucR in 1:dims[3]
            dfb[row,"UC_$(ucL)_UC_$(ucR)"]=bose_EVS[a,b,ucL,ucR]
        end
    end

    CSV.write("logs/bose_evs_$identifier.csv",dfb)



    OPTIMIZER_RUNTIME = time()-TIME_WHEN_RAN_OPTIMIZER
    # you have also:
    #TOTAL_TIME_MULTITHREADING

    # and (cumulated over workers)
#    MCSAMPLERRUNTIMES # component go: [total worker runtime, hamtime, gradtime]


    println("Optimzer ran for $OPTIMIZER_RUNTIME s. Out of this, $(TOTAL_TIME_MULTITHREADING/OPTIMIZER_RUNTIME) was spent multi-threading.")

    println("In total, ran $(MCSAMPLERRUNTIMES[1]) of MC sampling across the workers. There was $(OPTIMIZER_RUNTIME*nthreads()) time available")
    println("So multi-threadig efficiency is really $(((MCSAMPLERRUNTIMES[1]))/(OPTIMIZER_RUNTIME*nthreads()))")
    println("Out of this:")
    println("$(MCSAMPLERRUNTIMES[3]/MCSAMPLERRUNTIMES[1]) was spent computing H")
    println("$(MCSAMPLERRUNTIMES[4]/MCSAMPLERRUNTIMES[1]) was spent cumulating")
    println("$(MCSAMPLERRUNTIMES[5]/MCSAMPLERRUNTIMES[1]) was spent computing inverses")
    println("The remaining $((MCSAMPLERRUNTIMES[1]-MCSAMPLERRUNTIMES[3]-MCSAMPLERRUNTIMES[4]-MCSAMPLERRUNTIMES[5])/MCSAMPLERRUNTIMES[1]) is the rest of the code!")
    println("Fraction of MC calltime spent actually iterating: $(MCSAMPLERRUNTIMES[2]/MCSAMPLERRUNTIMES[1]).")
    println("Memory allocation: $(MCALLOCS[1]), ratios: (ALL,Ham,pf_update,Grad,Steps): $(MCALLOCS/MCALLOCS[1])")


    return dfE, g_function,FullPositions, adam_base+NUMBER_OPTIMIZER_STEPS,mt, vt,gfn
end


