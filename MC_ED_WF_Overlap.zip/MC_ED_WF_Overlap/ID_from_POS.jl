# given a set of positions (and overall dimensions), compute the state ID and the translation necessary to get there

# dims: [Number_X,Number_Y,Sites_per_UC]
# positions: a list of [x,y,s]

# simply compute ID from state
function get_state_ID(positions,dims;posshift=[0,0])
    id = UInt64(0) # 64-bit should be enough as long as you have fewer than 64 sites... (you always do I think)

    for position in positions
        shift = position[3]-1 + mod(position[2]-1-posshift[2],dims[2])*dims[3] + mod(position[1]-1-posshift[1],dims[1])*dims[2]*dims[3]
        id |= UInt64(0x1) << shift
        # now add a one shifted by that amount...
    end
    return id
end

# try all the possible X,Y shifts, output the one minimizing the value.
function get_canonical_ID(positions,dims)
    shifts = [[x,y] for x in 1:dims[1], y in 1:dims[2]]

    ids = map(shift -> get_state_ID(positions,dims,posshift=shift),shifts)

    best_val = minimum(ids)
    
    good_ones = ids.==best_val

    return best_val, shifts[good_ones] # it may output multiple shifts - in that case, e^i k.shifts must be a constant which constraints momenta...
end
