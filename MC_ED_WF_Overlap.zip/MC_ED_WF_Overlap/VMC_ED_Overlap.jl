include("ED_amplitude.jl")
include("threaded_sampler.jl")
include("g_from_file.jl")


#### ED FUNCTIONS INPUT
# ED_WFS is a list of [hilbert_space_file, WF_file]

# dispersivness = 0 
ED_WFS = [
    ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_0_ky_0.txt","9partEDWFs/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
    ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_3_ky_0.txt","9partEDWFs/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_3_ky_0.0.vec"],
    ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_0_ky_0.txt","9partEDWFs/anExcitedState/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.1.vec"]
    # last one is a 1st excited state to see what happens...
]

# dispersivness = 0.3
# ED_WFS = [
#     ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_0_ky_0.txt","9partEDWFs/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.205025_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
#     ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_3_ky_0.txt","9partEDWFs/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.205025_tpp_0.207107_gx_0.000000_gy_0.000000_kx_3_ky_0.0.vec"]
# ]

# dispersivness = 0.5
# ED_WFS = [
#     ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_0_ky_0.txt","9partEDWFs/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.146447_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
#     ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_3_ky_0.txt","9partEDWFs/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.146447_tpp_0.207107_gx_0.000000_gy_0.000000_kx_3_ky_0.0.vec"]
# ]

# dispersivness = 0.95
# ED_WFS = [
#     ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_0_ky_0.txt","9partEDWFs/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.014645_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
#     ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_3_ky_0.txt","9partEDWFs/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.014645_tpp_0.207107_gx_0.000000_gy_0.000000_kx_3_ky_0.0.vec"],
# ]

# # fermions...
# ED_WFS = [
#     ["8partFERMI_EDWF/HilbertSpace/fermi_p_8_x_6_y_4_hilberspace_kx_0_ky_0.txt","8partFERMI_EDWF/WFs/fermions_realspace_checkerboardlattice_n_8_ns_48_x_6_y_4_u_2.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
#     ["8partFERMI_EDWF/HilbertSpace/fermi_p_8_x_6_y_4_hilberspace_kx_2_ky_0.txt","8partFERMI_EDWF/WFs/fermions_realspace_checkerboardlattice_n_8_ns_48_x_6_y_4_u_2.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_2_ky_0.0.vec"],
#     ["8partFERMI_EDWF/HilbertSpace/fermi_p_8_x_6_y_4_hilberspace_kx_4_ky_0.txt","8partFERMI_EDWF/WFs/fermions_realspace_checkerboardlattice_n_8_ns_48_x_6_y_4_u_2.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_4_ky_0.0.vec"],
# ]

# small bosons
# ED_WFS = [
#     ["6boseEDWFs/boson_p_6_x_4_y_3_HS_kx_0_ky_0.txt","6boseEDWFs/u1v0.2/bosons_realspace_gutzwiller_checkerboardlattice_n_6_ns_24_x_4_y_3_u_1.000000_v_0.200000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
#     ["6boseEDWFs/boson_p_6_x_4_y_3_HS_kx_2_ky_0.txt","6boseEDWFs/u1v0.2/bosons_realspace_gutzwiller_checkerboardlattice_n_6_ns_24_x_4_y_3_u_1.000000_v_0.200000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_2_ky_0.0.vec"],
#     ]

# # actual v=1 strong interaction small bosons 
# ED_WFS = [
#     ["6boseEDWFs/boson_p_6_x_4_y_3_HS_kx_0_ky_0.txt","6boseEDWFs/u0v1.0/bosons_realspace_gutzwiller_checkerboardlattice_n_6_ns_24_x_4_y_3_u_0.000000_v_1.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
#     ["6boseEDWFs/boson_p_6_x_4_y_3_HS_kx_2_ky_0.txt","6boseEDWFs/u0v1.0/bosons_realspace_gutzwiller_checkerboardlattice_n_6_ns_24_x_4_y_3_u_0.000000_v_1.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_2_ky_0.0.vec"],
#     ]


# other small bosons 
# ED_WFS = [
#     ["6boseEDWFs/boson_p_6_x_4_y_3_HS_kx_0_ky_0.txt","6boseEDWFs/u3v0.5/bosons_realspace_gutzwiller_checkerboardlattice_n_6_ns_24_x_4_y_3_u_3.000000_v_0.500000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
#     ["6boseEDWFs/boson_p_6_x_4_y_3_HS_kx_2_ky_0.txt","6boseEDWFs/u3v0.5/bosons_realspace_gutzwiller_checkerboardlattice_n_6_ns_24_x_4_y_3_u_3.000000_v_0.500000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_2_ky_0.0.vec"],
#     ]


# nu quarter bosons...
# ED_WFS = [
#     ["5partED_nu_quarter/HilbertSpace/part_5_x_4_y_5_s_2boson_HS_kx_0_ky_0.txt", "5partED_nu_quarter/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_5_ns_40_x_4_y_5_u_0.000000_v_8.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
#     ["5partED_nu_quarter/HilbertSpace/part_5_x_4_y_5_s_2boson_HS_kx_1_ky_0.txt", "5partED_nu_quarter/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_5_ns_40_x_4_y_5_u_0.000000_v_8.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_1_ky_0.0.vec"],
#     ["5partED_nu_quarter/HilbertSpace/part_5_x_4_y_5_s_2boson_HS_kx_2_ky_0.txt", "5partED_nu_quarter/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_5_ns_40_x_4_y_5_u_0.000000_v_8.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_2_ky_0.0.vec"],
#     ["5partED_nu_quarter/HilbertSpace/part_5_x_4_y_5_s_2boson_HS_kx_3_ky_0.txt", "5partED_nu_quarter/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_5_ns_40_x_4_y_5_u_0.000000_v_8.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_3_ky_0.0.vec"]
# ]


# # # nu 23 bosons
# ED_WFS = [
#     ["8part_bose_23_filling_ED/nu23_bose_x_3_y_4_p_8_kx_0_ky_0.txt","8part_bose_23_filling_ED/bosons_realspace_gutzwiller_checkerboardlattice_n_8_ns_24_x_3_y_4_u_1.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
#     ["8part_bose_23_filling_ED/nu23_bose_x_3_y_4_p_8_kx_1_ky_0.txt","8part_bose_23_filling_ED/bosons_realspace_gutzwiller_checkerboardlattice_n_8_ns_24_x_3_y_4_u_1.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_1_ky_0.0.vec"],
#     ["8part_bose_23_filling_ED/nu23_bose_x_3_y_4_p_8_kx_2_ky_0.txt","8part_bose_23_filling_ED/bosons_realspace_gutzwiller_checkerboardlattice_n_8_ns_24_x_3_y_4_u_1.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_2_ky_0.0.vec"],
# ]

#####
# g_function_file = "5partVMC_nu_quarter/g_function_QUENCH_7,BC_PP,PFAFFIAN_4partons,filling-1.0,checkerboard,V18.0,V20.0,size_1x5_nrRuns_555.csv"


FERMIONS = false
#### VMC INPUT
# dispersivness = 0
g_function_file = "9partVMCgs2/g_function_QUENCH_2,BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V10,V20,size_3x3_nrRuns_700.csv"
# dispersivness = 0.3
# g_function_file = "9partVMCgs/g_function_QUENCH_14,BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V10,V20,size_3x3_nrRuns_700.csv"
# dispersivness = 0.5
# g_function_file = "9partVMCgs/g_function_QUENCH_22,BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V10,V20,size_3x3_nrRuns_700.csv"
# dispersivness = 0.95
#g_function_file = "9partVMCgs/g_function_QUENCH_40,BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V10,V20,size_3x3_nrRuns_700.csv"

# fermions...
#g_function_file = "8partFERMI_VMC/logs_other_interaction/g_function_QUENCH_5,BC_PP,PFAFFIAN_3partons,filling-1.0,checkerboard,V12.0,V20,size_2x4_nrRuns_900.csv"
#FERMIONS = true

# # small bosons...
# g_function_file = "6boseVMC/g_function_QUENCH_2,BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V11,V20.2,size_2x3_nrRuns_1200.csv"
# # other small bosons
# g_function_file =  "6boseVMC/g_function_QUENCH_2,BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V13,V20.5,size_2x3_nrRuns_1200.csv"
# g_function_file = "6boseVMC/g_function_QUENCH_1,BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V10.5,V20.0,size_2x3_nrRuns_1200.csv"

# g_function_file = "6boseVMC/g_function_QUENCH_1,BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V10.2,V20.0,size_2x3_nrRuns_600.csv"

# g_function_file = "6boseVMC/g_function_QUENCH_1,BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V11.0,V20.0,size_2x3_nrRuns_600.csv"

# nu = 2/3 bosons
#g_function_file = "8part_bose_23_filling_VMC/g_function_QUENCH_6,BC_PP,PFAFFIAN_2partons,filling-2.0,checkerboard,V10.0,V20,size_1x4_nrRuns_1000.csv"


# number_partons = 2
# number_sites_extended_UC = 4
number_partons = 2
number_sites_extended_UC = 4


if FERMIONS
    number_partons=3
    number_sites_extended_UC=6
end

dims_ED = [6,3,2]
VMC_NR_BOSONS_PER_UC = 1 # for the nu=2/3 only!

if FERMIONS
    dims_ED=[6,4,2]
    VMC_NR_BOSONS_PER_UC = 1
end

#####

#### Program input

WarmupWorker = Dict("runs_per_iter"=>20000,"iterations"=>200)
#BIGworker = Dict("runs_per_iter"=>100000,"iterations"=>2000)
BIGworker = Dict("runs_per_iter"=>30000,"iterations"=>500) #maybe 50k, 1000 better, will see
#BIGworker = Dict("runs_per_iter"=>80000,"iterations"=>1000) #maybe 50k, 1000 better, will see

####


# Step 1: read g-function and parse VMC functions
println("Reading g function")
g_funct = read_g_from_file(g_function_file,number_partons,number_sites_extended_UC)
dims_VMC = [size(g_funct)[1],size(g_funct)[2],number_sites_extended_UC,number_partons]

# converting all the WFs...
println("Reading ED Wavefunctions")
edwfs = map(x->read_ED_WF_from_files(x[1],x[2],compact_fermi=FERMIONS), ED_WFS)

# dims_ED = [6,3,2] # simply hard-code IDK....
# dims_ED = [4,3,2]


UNIT_CELL_FACTOR = round(Int64,number_sites_extended_UC/dims_ED[3])

function CONVERTPOS(positions)
    newpos = Vector{Vector{Int64}}(undef,0)
    for pos in positions
        np = [UNIT_CELL_FACTOR*pos[1]-1,pos[2],pos[3]]
        while np[3]>dims_ED[3]
            np[1]+=1
            np[3]-=dims_ED[3]
        end
        push!(newpos,np)
    end
    return newpos
end

# function CONVERTPOS2(positions)
#     newpos = Vector{Vector{Int64}}(undef,0)
#     for pos in positions
#         np = [UNIT_CELL_FACTOR*pos[1]-1,pos[2],pos[3]]
#         while np[3]>dims_ED[3]
#             np[1]+=1
#             np[3]-=dims_ED[3]
#         end
#         np[1]+=1 # shift by one to see what effect it has!
#         push!(newpos,np)
#     end
#     return newpos
# end



ed_amplitude_functions = map(currITEM -> (Pos -> EDWF_amplitude(CONVERTPOS(Pos),dims_ED,currITEM,FERMI_STATISTICS=FERMIONS)),edwfs)

# Step 2: A small multi-threading VMC to figure out Psi scale factor.

println("Starting small preliminary chain")
df_small, finalPos = threaded_sampler(WarmupWorker,g_funct,dims_VMC,[],NR_BOSONS_PER_UC=VMC_NR_BOSONS_PER_UC);

psiscale=sum(df_small."PsiMag_EV".*df_small."NR_CUMULATED")/sum(df_small."NR_CUMULATED")
pfaffian_scale_factor=(1/psiscale)^(2/(dims_VMC[4]*dims_VMC[1]*dims_VMC[2]))

# Step 3: The big data collection!

println("Collecting data now!")
df_big, finalPos = threaded_sampler(BIGworker,g_funct,dims_VMC,ed_amplitude_functions,startingPos=finalPos,pfaffian_scale_factor=pfaffian_scale_factor,NR_BOSONS_PER_UC=VMC_NR_BOSONS_PER_UC)

# Step 4: analyse


function get_overlaps(filter)
    overall_r_evs = sum(df_big."r_EV"[filter].*df_big."NR_CUMULATED"[filter])/sum(df_big."NR_CUMULATED"[filter])
    overall_abssq_evs = sum(df_big."absSqr_EV"[filter].*df_big."NR_CUMULATED"[filter])/sum(df_big."NR_CUMULATED"[filter])

    Overlap_estimates = overall_r_evs./sqrt.(overall_abssq_evs)
    AbsSqOL = abs.(Overlap_estimates).^2
    return AbsSqOL
end
full_overlaps = get_overlaps(df_big."NR_CUMULATED".>0)
total_overlap = sum(full_overlaps)


nr_split_into = 100

partial_olaps = []
partial_all_olaps = []
L = size(df_big)[1]
for splitID in 1:nr_split_into
    LB=(splitID-1)*round(Int64,L/nr_split_into)+1
    RB=splitID*round(Int64,L/nr_split_into)
    if RB>L
        RB=L
    end
    
    filter = ((1:L).>=LB) .&& ((1:L).<=RB)
    colaps = get_overlaps(filter)
    push!(partial_olaps,sum(colaps))
    push!(partial_all_olaps,colaps)
end

rmsdev = sqrt(sum((partial_olaps.-total_overlap).^2)/nr_split_into)
uncertainty = rmsdev/sqrt(nr_split_into-1)

println("Full overlap is $total_overlap +- $uncertainty")


overlapInfo = Dict("All_WF_Overlap"=>total_overlap, "All_WF_Uncertainty"=>uncertainty)

wf_uncertainties = []
wf_overlaps = []
for wfid in 1:length(ED_WFS)
    trueval = full_overlaps[wfid]
    
    rmsdevs = sqrt(sum((getindex.(partial_all_olaps,wfid).-trueval).^2)/nr_split_into)
    unctnow = rmsdevs/sqrt(nr_split_into-1)

    overlapInfo["WF_$(wfid)_Overlap"]=trueval
    overlapInfo["WF_$(wfid)_Uncertainty"]=unctnow

    push!(wf_overlaps,trueval)
    push!(wf_uncertainties,unctnow)
    println("With WF $wfid have overlap $trueval +- $unctnow")
end