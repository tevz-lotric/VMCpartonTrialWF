include("ED_amplitude.jl")
include("threaded_sampler.jl")
include("g_from_file.jl")
using CSV
using DataFrames

#### ED FUNCTIONS INPUT
# ED_WFS is a list of [hilbert_space_file, WF_file]
ED_HSs = ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_0_ky_0.txt","9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_3_ky_0.txt"]


allwffolder = split(read(`ls 9partEDWFs/INTERACTION_STRENGTH_SWEEP/`,String),"\n")
allwffolder = allwffolder[length.(allwffolder).>0]

sort!(allwffolder)

kxs = parse.(Int64,getindex.(split.(getindex.(split.(allwffolder,"_kx_"),2),"_ky_"),1))

kzeros = allwffolder[kxs.==0]
kpis = allwffolder[kxs.==3]

kzero_WF_list = (["9partEDWFs/INTERACTION_STRENGTH_SWEEP/$name" for name in kzeros])
kpi_WF_list = (["9partEDWFs/INTERACTION_STRENGTH_SWEEP/$name" for name in kpis])

#####


kzero_WF_list = kzero_WF_list
kpi_WF_list = kpi_WF_list

# Give names to steps, ie just list the `dispersivness`
iteration_names = (0:0.1:2)


#### VMC INPUT

which_sign_to_take = -1 # 1 or -1 means which momentum of the FCI state you care about!


gffl = split(read(`ls 9partVMC_INTERACTION_SWEEP`,String),"\n")[1:end-1]

goodgffl = gffl[contains.(gffl,"big_g_function_QUENCH_4_TERMFACTOR_$which_sign_to_take")]

g_function_file_list = ["9partVMC_INTERACTION_SWEEP/$x" for x in goodgffl]

number_partons = 2
number_sites_extended_UC = 4

#####

#### Program input

WarmupWorker = Dict("runs_per_iter"=>25000,"iterations"=>200)
#BIGworker = Dict("runs_per_iter"=>100000,"iterations"=>2000)
BIGworker = Dict("runs_per_iter"=>55000,"iterations"=>500) #maybe 50k, 1000 better, will see

####
nsteps = length(g_function_file_list)
if nsteps!=length(kzero_WF_list) || nsteps!=length(kpi_WF_list) || nsteps!=length(iteration_names)
    println("Some sort of mismatch with your vector lengths...")
end

overlap_info = []

for dispersivness_step in 1:nsteps
    dsp = iteration_names[dispersivness_step]
    println("Starting Interaction $dsp")
    g_function_file = g_function_file_list[dispersivness_step]

    ED_WFS = [[ED_HSs[1], kzero_WF_list[dispersivness_step]]]
    if which_sign_to_take<0
        ED_WFS=[[ED_HSs[2],kpi_WF_list[dispersivness_step]]]
    end

    # Step 1: read g-function and parse VMC functions
    println("Reading g function")
    g_funct = read_g_from_file_S(g_function_file,number_partons,number_sites_extended_UC)
    dims_VMC = [size(g_funct)[1],size(g_funct)[2],number_sites_extended_UC,number_partons]

    # converting all the WFs...
    println("Reading ED vectors")
    ct = time()
    edwfs = map(x->read_ED_WF_from_files(x[1],x[2]), ED_WFS)
    println("ED readout took $(time()-ct) sec")
    dims_ED = [6,3,2] # simply hard-code IDK....


    function CONVERTPOS(positions)
        newpos = Vector{Vector{Int64}}(undef,0)
        for pos in positions
            np = [2*pos[1]-1,pos[2],pos[3]]
            if np[3]>dims_ED[3]
                np[1]+=1
                np[3]-=dims_ED[3]
            end
            push!(newpos,np)
        end
        return newpos
    end


    ed_amplitude_functions = map(currITEM -> (Pos -> EDWF_amplitude(CONVERTPOS(Pos),dims_ED,currITEM)),edwfs)

    # Step 2: A small multi-threading VMC to figure out Psi scale factor.

    println("Warming up for Interaction $dsp")
    df_small, finalPos = threaded_sampler(WarmupWorker,g_funct,dims_VMC,[];termsumfactor=which_sign_to_take);

    psiscale=sum(df_small."PsiMag_EV".*df_small."NR_CUMULATED")/sum(df_small."NR_CUMULATED")
    pfaffian_scale_factor=(1/psiscale)^(2/(dims_VMC[4]*dims_VMC[1]*dims_VMC[2]))

    # Step 3: The big data collection!
    println("Sampling Interaction $dsp")
    df_big, finalPos = threaded_sampler(BIGworker,g_funct,dims_VMC,ed_amplitude_functions,startingPos=finalPos,pfaffian_scale_factor=pfaffian_scale_factor,termsumfactor=which_sign_to_take)

    # Step 4: analyse


    function get_overlaps(filter)
        overall_r_evs = sum(df_big."r_EV"[filter].*df_big."NR_CUMULATED"[filter])/sum(df_big."NR_CUMULATED"[filter])
        overall_abssq_evs = sum(df_big."absSqr_EV"[filter].*df_big."NR_CUMULATED"[filter])/sum(df_big."NR_CUMULATED"[filter])

        Overlap_estimates = overall_r_evs./sqrt.(overall_abssq_evs)
        AbsSqOL = abs.(Overlap_estimates).^2
        return AbsSqOL
    end
    full_overlaps = get_overlaps(df_big."NR_CUMULATED".>0)
    total_overlap = sum(full_overlaps)


    nr_split_into = 100

    partial_olaps = []
    partial_all_olaps = []
    L = size(df_big)[1]
    for splitID in 1:nr_split_into
        LB=(splitID-1)*round(Int64,L/nr_split_into)+1
        RB=splitID*round(Int64,L/nr_split_into)
        if RB>L
            RB=L
        end
        
        filter = ((1:L).>=LB) .&& ((1:L).<=RB)
        colaps = get_overlaps(filter)
        push!(partial_olaps,sum(colaps))
        push!(partial_all_olaps,colaps)
    end

    rmsdev = sqrt(sum((partial_olaps.-total_overlap).^2)/nr_split_into)
    uncertainty = rmsdev/sqrt(nr_split_into-1)
    println("This is information for Interaction $(iteration_names[dispersivness_step]):")
    println("Full overlap is $total_overlap +- $uncertainty")

    overlapInfo = Dict("All_WF_Overlap"=>total_overlap, "All_WF_Uncertainty"=>uncertainty)

    wf_uncertainties = []
    wf_overlaps = []
    for wfid in 1:length(ED_WFS)
        trueval = full_overlaps[wfid]
        
        rmsdevs = sqrt(sum((getindex.(partial_all_olaps,wfid).-trueval).^2)/nr_split_into)
        unctnow = rmsdevs/sqrt(nr_split_into-1)

        overlapInfo["WF_$(wfid)_Overlap"]=trueval
        overlapInfo["WF_$(wfid)_Uncertainty"]=unctnow

        push!(wf_overlaps,trueval)
        push!(wf_uncertainties,unctnow)
        println("With WF $wfid have overlap $trueval +- $unctnow")
    end

    # now need to save all this data


    overlapInfo["Interaction"]=iteration_names[dispersivness_step]

    push!(overlap_info,overlapInfo)

    overlap_df = DataFrame(overlap_info)

    CSV.write("overlap_results_interactionsweep_sign_$which_sign_to_take.csv", overlap_df)
end

overlap_df = DataFrame(overlap_info)

CSV.write("overlap_results_interactionsweep_sign_$which_sign_to_take.csv", overlap_df)