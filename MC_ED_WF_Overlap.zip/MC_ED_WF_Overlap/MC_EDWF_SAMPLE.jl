include("ED_amplitude.jl")
include("threaded_sampler_EDWF.jl")

#### ED FUNCTIONS INPUT
# ED_WFS is a list of [hilbert_space_file, WF_file]

# small bosons
ED_WFS = [
    ["6boseEDWFs/boson_p_6_x_4_y_3_HS_kx_0_ky_0.txt","6boseEDWFs/u1v0.2/bosons_realspace_gutzwiller_checkerboardlattice_n_6_ns_24_x_4_y_3_u_1.000000_v_0.200000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
    ["6boseEDWFs/boson_p_6_x_4_y_3_HS_kx_2_ky_0.txt","6boseEDWFs/u1v0.2/bosons_realspace_gutzwiller_checkerboardlattice_n_6_ns_24_x_4_y_3_u_1.000000_v_0.200000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_2_ky_0.0.vec"],
    ]

# other small bosons 
ED_WFS = [
    ["6boseEDWFs/boson_p_6_x_4_y_3_HS_kx_0_ky_0.txt","6boseEDWFs/u3v0.5/bosons_realspace_gutzwiller_checkerboardlattice_n_6_ns_24_x_4_y_3_u_3.000000_v_0.500000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
    ["6boseEDWFs/boson_p_6_x_4_y_3_HS_kx_2_ky_0.txt","6boseEDWFs/u3v0.5/bosons_realspace_gutzwiller_checkerboardlattice_n_6_ns_24_x_4_y_3_u_3.000000_v_0.500000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_2_ky_0.0.vec"],
    ]

# the fermions - with strong interactions
ED_WFS = [
    ["8partFERMI_EDWF/HilbertSpace/fermi_p_8_x_6_y_4_hilberspace_kx_0_ky_0.txt","8partFERMI_EDWF/WFs/fermions_realspace_checkerboardlattice_n_8_ns_48_x_6_y_4_u_5.000000_v_1.500000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"],
    ["8partFERMI_EDWF/HilbertSpace/fermi_p_8_x_6_y_4_hilberspace_kx_2_ky_0.txt","8partFERMI_EDWF/WFs/fermions_realspace_checkerboardlattice_n_8_ns_48_x_6_y_4_u_5.000000_v_1.500000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_2_ky_0.0.vec"],
    ["8partFERMI_EDWF/HilbertSpace/fermi_p_8_x_6_y_4_hilberspace_kx_4_ky_0.txt","8partFERMI_EDWF/WFs/fermions_realspace_checkerboardlattice_n_8_ns_48_x_6_y_4_u_5.000000_v_1.500000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_4_ky_0.0.vec"],
]
# other fermions, weaker interaction
# ED_WFS = [
#     ["8partFERMI_EDWF/HilbertSpace/fermi_p_8_x_6_y_4_hilberspace_kx_0_ky_0.txt", "8partFERMI_EDWF/WFs/fermions_realspace_checkerboardlattice_n_8_ns_48_x_6_y_4_u_2.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec" ],
#     ["8partFERMI_EDWF/HilbertSpace/fermi_p_8_x_6_y_4_hilberspace_kx_2_ky_0.txt","8partFERMI_EDWF/WFs/fermions_realspace_checkerboardlattice_n_8_ns_48_x_6_y_4_u_2.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_2_ky_0.0.vec"],
#     ["8partFERMI_EDWF/HilbertSpace/fermi_p_8_x_6_y_4_hilberspace_kx_4_ky_0.txt","8partFERMI_EDWF/WFs/fermions_realspace_checkerboardlattice_n_8_ns_48_x_6_y_4_u_2.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_4_ky_0.0.vec"],
# ]
# FERMI_FLAG = true

# quarter-density bosons...
# ED_WFS = [
#     ["5partED_nu_quarter/HilbertSpace/part_5_x_4_y_5_s_2boson_HS_kx_0_ky_0.txt", "5partED_nu_quarter/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_5_ns_40_x_4_y_5_u_0.000000_v_8.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"]
# ]
FERMI_FLAG = true


ED_WF_to_USE = ED_WFS[1]

#####

#### Program input

HAMILTONIAN = Dict("name"=>"checkerboard","V1"=>5.0,"V2"=>1.5,"t"=>1*exp(im*π/4), "tp1"=>1/(2+sqrt(2)), "tp2"=>-1/(2+sqrt(2)), "tpp"=>1/(2+2*sqrt(2)))

WarmupWorker = Dict("runs_per_iter"=>100000,"iterations"=>10)
#BIGworker = Dict("runs_per_iter"=>100000,"iterations"=>2000)
BIGworker = Dict("runs_per_iter"=>6*70000,"iterations"=>10) #maybe 50k, 1000 better, will see

####


# converting all the WFs...
println("Reading ED Wavefunctions")
edwfs = read_ED_WF_from_files(ED_WF_to_USE[1],ED_WF_to_USE[2],compact_fermi=FERMI_FLAG)

dims_ED = [4,3,2] # simply hard-code IDK....
NPARTICLES_ED = 6

dims_ED = [6,4,2]
NPARTICLES_ED = 8

# # for nu=1/4 bosons...
# dims_ED = [4,5,2]
# NPARTICLES_ED = 5



HAMILTONIAN["NR_PARTICLES"]=NPARTICLES_ED


function HardCoreWrap(Pos,dims_ED,edwfs;FERMISTAT=false)
    # check for hard core...
    sp = sort(Pos)
    if sum((sp[2:end]-sp[1:end-1]).==[[0,0,0]])>0
        return 0+0*im
    end

    return EDWF_amplitude(Pos,dims_ED,edwfs,FERMI_STATISTICS=FERMISTAT)
end


ed_amplitude_function = Pos -> HardCoreWrap(Pos,dims_ED,edwfs,FERMISTAT=FERMI_FLAG)

# Step 2: A small multi-threading VMC to figure out Psi scale factor.

println("Starting small preliminary chain")
df_small, finalPos = threaded_sampler_EDWF(WarmupWorker,ed_amplitude_function,dims_ED,HAMILTONIAN);
@show df_small
# Step 3: The big data collection!

println("Collecting data now!")
df_big, finalPos = threaded_sampler_EDWF(BIGworker,ed_amplitude_function,dims_ED,HAMILTONIAN,startingPos=finalPos)

# Step 4: see what happens?
#@show df_big

tote = (NPARTICLES_ED*mean(df_big."Total_Energy_EV"))

println("Energy value (total) is $tote.")