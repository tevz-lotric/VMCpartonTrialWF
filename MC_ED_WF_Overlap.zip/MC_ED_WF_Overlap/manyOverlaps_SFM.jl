include("ED_amplitude.jl")
include("threaded_sampler.jl")
include("g_from_file.jl")
using CSV
using DataFrames

#### ED FUNCTIONS INPUT
# ED_WFS is a list of [hilbert_space_file, WF_file]
ED_HSs = ["9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_0_ky_0.txt","9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_3_ky_0.txt"]


allwffolder = split(read(`ls 9partEDWFs/allWFsSFM/`,String),"\n")
allwffolder = allwffolder[length.(allwffolder).>0]

sort!(allwffolder)

kxs = parse.(Int64,getindex.(split.(getindex.(split.(allwffolder,"_kx_"),2),"_ky_"),1))
vectprIDS = parse.(Int64,getindex.(split.(getindex.(split.(allwffolder,".ve"),1),"."),9))


kzeros = allwffolder[kxs.==0 .&& vectprIDS.==0]
kpis = allwffolder[kxs.==3]
kzeroEXCITED =allwffolder[vectprIDS.==1]

# need to flip these as the smaller t (by which you sort) is actually the bigger dispersivness...
kzero_WF_list = reverse(["9partEDWFs/allWFsSFM/$name" for name in kzeros])
kpi_WF_list = reverse(["9partEDWFs/allWFsSFM/$name" for name in kpis])
kzero_EXCWF_list = reverse(["9partEDWFs/allWFsSFM/$name" for name in kzeroEXCITED])

#####

# Give names to steps, ie just list the `dispersivness`
iteration_names = [0,0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75,0.8,0.85,0.9,0.95]


#### VMC INPUT
g_function_file_list1 = ["9partVMCgsSFM/g_function_QUENCH_$(2*x),BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V10,V20,size_3x3_nrRuns_400.csv" for x in 1:20]
g_function_file_list2 = reverse(["9partVMCgsSFM/g_function_REV_QUENCH_$(2*x),BC_PP,PFAFFIAN_2partons,filling-1.0,checkerboard,V10,V20,size_3x3_nrRuns_400.csv" for x in 1:20])

g_function_file_list = vcat(g_function_file_list1,g_function_file_list2)
# double in length both interation_names AND ED WF list.
kzero_WF_list = vcat(kzero_WF_list,kzero_WF_list)
kpi_WF_list = vcat(kpi_WF_list,kpi_WF_list)

iteration_names_fwd = [("F",x) for x in iteration_names]
iteration_names_Rev = [("R",x) for x in iteration_names]
iteration_names = vcat(iteration_names_fwd,iteration_names_Rev)


number_partons = 2
number_sites_extended_UC = 4

#####

#### Program input

WarmupWorker = Dict("runs_per_iter"=>15000,"iterations"=>200)
#BIGworker = Dict("runs_per_iter"=>100000,"iterations"=>2000)
BIGworker = Dict("runs_per_iter"=>35000,"iterations"=>500) #maybe 50k, 1000 better, will see

####
nsteps = length(g_function_file_list)
if nsteps!=length(kzero_WF_list) || nsteps!=length(kpi_WF_list) || nsteps!=length(iteration_names)
    println("Some sort of mismatch with your vector lengths...")
end

overlap_info = []

for dispersivness_step in 1:nsteps
    dsp = iteration_names[dispersivness_step]
    println("Starting Dispersivness $dsp")
    g_function_file = g_function_file_list[dispersivness_step]

    ED_WFS = [[ED_HSs[1], kzero_WF_list[dispersivness_step]],[ED_HSs[2],kpi_WF_list[dispersivness_step]],[ED_HSs[1],kzero_EXCWF_list[dispersivness_step]]]

    # Step 1: read g-function and parse VMC functions
    println("Reading g function")
    g_funct = read_g_from_file(g_function_file,number_partons,number_sites_extended_UC)
    dims_VMC = [size(g_funct)[1],size(g_funct)[2],number_sites_extended_UC,number_partons]

    # converting all the WFs...
    println("Reading ED vectors")
    ct = time()
    edwfs = map(x->read_ED_WF_from_files(x[1],x[2]), ED_WFS)
    println("ED readout took $(time()-ct) sec")
    dims_ED = [6,3,2] # simply hard-code IDK....


    function CONVERTPOS(positions)
        newpos = Vector{Vector{Int64}}(undef,0)
        for pos in positions
            np = [2*pos[1]-1,pos[2],pos[3]]
            if np[3]>dims_ED[3]
                np[1]+=1
                np[3]-=dims_ED[3]
            end
            push!(newpos,np)
        end
        return newpos
    end


    ed_amplitude_functions = map(currITEM -> (Pos -> EDWF_amplitude(CONVERTPOS(Pos),dims_ED,currITEM)),edwfs)

    # Step 2: A small multi-threading VMC to figure out Psi scale factor.

    println("Warming up for Dispersivness $dsp")
    df_small, finalPos = threaded_sampler(WarmupWorker,g_funct,dims_VMC,[]);

    psiscale=sum(df_small."PsiMag_EV".*df_small."NR_CUMULATED")/sum(df_small."NR_CUMULATED")
    pfaffian_scale_factor=(1/psiscale)^(2/(dims_VMC[4]*dims_VMC[1]*dims_VMC[2]))

    # Step 3: The big data collection!
    println("Sampling dispersivness $dsp")
    df_big, finalPos = threaded_sampler(BIGworker,g_funct,dims_VMC,ed_amplitude_functions,startingPos=finalPos,pfaffian_scale_factor=pfaffian_scale_factor)

    # Step 4: analyse


    function get_overlaps(filter)
        overall_r_evs = sum(df_big."r_EV"[filter].*df_big."NR_CUMULATED"[filter])/sum(df_big."NR_CUMULATED"[filter])
        overall_abssq_evs = sum(df_big."absSqr_EV"[filter].*df_big."NR_CUMULATED"[filter])/sum(df_big."NR_CUMULATED"[filter])

        Overlap_estimates = overall_r_evs./sqrt.(overall_abssq_evs)
        AbsSqOL = abs.(Overlap_estimates).^2
        return AbsSqOL
    end
    full_overlaps = get_overlaps(df_big."NR_CUMULATED".>0)
    total_overlap = sum(full_overlaps)


    nr_split_into = 100

    partial_olaps = []
    partial_all_olaps = []
    L = size(df_big)[1]
    for splitID in 1:nr_split_into
        LB=(splitID-1)*round(Int64,L/nr_split_into)+1
        RB=splitID*round(Int64,L/nr_split_into)
        if RB>L
            RB=L
        end
        
        filter = ((1:L).>=LB) .&& ((1:L).<=RB)
        colaps = get_overlaps(filter)
        push!(partial_olaps,sum(colaps))
        push!(partial_all_olaps,colaps)
    end

    rmsdev = sqrt(sum((partial_olaps.-total_overlap).^2)/nr_split_into)
    uncertainty = rmsdev/sqrt(nr_split_into-1)
    println("This is information for Dispersivness $(iteration_names[dispersivness_step]):")
    println("Full overlap is $total_overlap +- $uncertainty")

    overlapInfo = Dict("All_WF_Overlap"=>total_overlap, "All_WF_Uncertainty"=>uncertainty,"Direction"=>iteration_names[dispersivness_step][1],"Dispersivness"=>iteration_names[dispersivness_step][2])

    wf_uncertainties = []
    wf_overlaps = []
    for wfid in 1:length(ED_WFS)
        trueval = full_overlaps[wfid]
        
        rmsdevs = sqrt(sum((getindex.(partial_all_olaps,wfid).-trueval).^2)/nr_split_into)
        unctnow = rmsdevs/sqrt(nr_split_into-1)

        overlapInfo["WF_$(wfid)_Overlap"]=trueval
        overlapInfo["WF_$(wfid)_Uncertainty"]=unctnow

        push!(wf_overlaps,trueval)
        push!(wf_uncertainties,unctnow)
        println("With WF $wfid have overlap $trueval +- $unctnow")
    end

    # now need to save all this data
    push!(overlap_info,overlapInfo)
end

overlap_df = DataFrame(overlap_info)

CSV.write("overlaps_results_SFM_3olaps.csv", overlap_df)