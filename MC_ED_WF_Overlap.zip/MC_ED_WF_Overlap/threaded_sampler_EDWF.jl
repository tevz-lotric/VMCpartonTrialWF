# muc

using .Threads
using UnicodePlots
using DataFrames
using CSV
using ParallelDataTransfer
using ProgressMeter
using LinearAlgebra


include("WF_computation.jl")
include("MC_sampler_using_ED.jl")
include("EDWF_hamiltonian.jl")


function threaded_sampler_EDWF(workdict,ED_WF_CALL,dims,HAM_DICT;startingPos = nothing)
    # use HAM_DICT to compute the hopping and interaction terms!
    hops=[]
    ints = []

    V1=0;V2=0

    if haskey(HAM_DICT,"V1")
        V1 = HAM_DICT["V1"]
    end
    if haskey(HAM_DICT, "V2")
        V2 = HAM_DICT["V2"]
    end

    if HAM_DICT["name"]=="hex"
        hops = get_valid_moves_hex(HAM_DICT["t"],HAM_DICT["tprime"],HAM_DICT["tpp"])
        ints = get_interactions_hex(V1,V2)
    else
        hops = get_valid_moves_checkerboard(HAM_DICT["t"],HAM_DICT["tp1"],HAM_DICT["tp2"],HAM_DICT["tpp"])
        ints = get_interactions_checkerboard(V1,V2)
    end
    
    
    # very crucial!
    number_threads = nthreads()

    # DEFINE YOUR MONTE CARLO PARAMETERS HERE....
    each_iteration_per_worker = workdict["runs_per_iter"]
    total_number_iterations = workdict["iterations"]



    function get_some_positions(dims,nP)
        Positions = Vector{Vector{Int64}}(undef,0)
        for j in 1:nP
            ganw = false
            while !ganw
                newPos = [rand(1:dims[1]),rand(1:dims[2]),rand(1:dims[3])]
                
                different = true
                for op in Positions
                    if op == newPos
                        different=false
                    end
                end

                if different
                    ganw=true
                    push!(Positions,newPos)
                end
            end
        end
        return Positions
    end
    # run the above for all THREADS!
    FullPositions = map(x->get_some_positions(dims,HAM_DICT["NR_PARTICLES"]),1:number_threads)

    if startingPos!=nothing
        FullPositions=deepcopy(startingPos)
    end


    logs = []

    @showprogress @threads for _ in 1:total_number_iterations
        # do a run with that thread's own position...
        NR_CUMULATED,cum_INT,cum_KIN,FullPositions[threadid()] = MC_sample_EDWF(each_iteration_per_worker,0,FullPositions[threadid()],ED_WF_CALL,dims,hops,ints)

        # save the cumulants! Do it this way to avoid fighting...
        push!(logs,Dict("Int_EV"=>cum_INT/NR_CUMULATED, "Re_KE_EV"=>real(cum_KIN)/NR_CUMULATED, "Im_KE_EV"=>imag(cum_KIN)/NR_CUMULATED,"NR_CUMULATED"=>NR_CUMULATED))
 

        
    end

    # only save the energy for now...
    dfE = DataFrame(logs)
    dfE."Total_Energy_EV"=dfE."Re_KE_EV" .+ dfE."Int_EV"
    return dfE,FullPositions
end

