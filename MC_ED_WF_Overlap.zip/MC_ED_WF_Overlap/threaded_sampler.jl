# muc

using .Threads
using UnicodePlots
using DataFrames
using CSV
using ParallelDataTransfer
using ProgressMeter
using LinearAlgebra


include("WF_computation.jl")
include("MC_sampler_forcing_Q_zero.jl")
#include("MC_sampler.jl")

function threaded_sampler(workdict,g_function_input,dims,comparing_WF_functions;startingPos = nothing,pfaffian_scale_factor=1,NR_BOSONS_PER_UC=1,termsumfactor=1)
    # very crucial!
    number_threads = nthreads()

    # DEFINE YOUR MONTE CARLO PARAMETERS HERE....
    each_iteration_per_worker = workdict["runs_per_iter"]
    total_number_iterations = workdict["iterations"]


    function antisymmetrise_g_f(gfun)
        antisym_g = zeros(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4]))
        
        for xval in 1:dims[1],yval in 1:dims[2], p1val in 1:dims[3]*dims[4], p2val in 1:dims[3]*dims[4]
            minusX = mod(-xval-1,dims[1])+1
            minusY = mod(-yval-1,dims[2])+1 
            antisym_g[xval,yval,p1val,p2val] = 0.5*(gfun[xval,yval,p1val,p2val] - gfun[minusX,minusY,p2val,p1val])
        end
        return antisym_g
    end


    g_function = antisymmetrise_g_f(g_function_input)

    function get_some_positions(dims,nP)
        Positions = Vector{Vector{Int64}}(undef,0)
        for j in 1:nP
            ganw = false
            while !ganw
                newPos = [rand(1:dims[1]),rand(1:dims[2]),rand(1:dims[3])]
                
                different = true
                for op in Positions
                    if op == newPos
                        different=false
                    end
                end

                if different
                    ganw=true
                    push!(Positions,newPos)
                end
            end
        end
        return Positions
    end
    # run the above for all THREADS!
    FullPositions = map(x->get_some_positions(dims,dims[1]*dims[2]*NR_BOSONS_PER_UC),1:number_threads)

    if startingPos!=nothing
        FullPositions=deepcopy(startingPos)
    end


    logs = []

    @showprogress @threads for _ in 1:total_number_iterations
        # do a run with that thread's own position...
        NR_CUMULATED,PsiMagCum,ratioCum,absrCum,FullPositions[threadid()] = MC_sample(each_iteration_per_worker,0,FullPositions[threadid()],g_function,dims,comparing_WF_functions,pfaffian_scale_factor=pfaffian_scale_factor,termsumfactor=termsumfactor)

        # save the cumulants! Do it this way to avoid fighting...
        push!(logs,Dict("r_EV"=>ratioCum/NR_CUMULATED, "absSqr_EV"=>absrCum/NR_CUMULATED, "Overlap_Estimate"=>(ratioCum/NR_CUMULATED)./sqrt.(absrCum/NR_CUMULATED),"PsiMag_EV"=>PsiMagCum/NR_CUMULATED,"NR_CUMULATED"=>NR_CUMULATED))
 

        
    end

    # only save the energy for now...
    dfE = DataFrame(logs)
    return dfE,FullPositions
end

