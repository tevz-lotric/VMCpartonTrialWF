using SkewLinearAlgebra
using LinearAlgebra
using BenchmarkTools

# computes new pfaffian divided by old one!
function update_pfaffian(mover_id,new_location,old_g_inverse,g_funct,Positions,dims)
# moves a FULL PARTICLE!
    # first check if zero...
    for oid in 1:length(Positions)
        if oid!=mover_id && all(abs.(Positions[oid]-new_location).<0.1)
            return 0+0*im
        end
    end
    old_location = Positions[mover_id]
    r = dims[4] # number of partons...
    # start by finding the delta vectors
    deltas = zeros(ComplexF64,(length(Positions)*dims[4],r))
    
    for j in 1:dims[4],otherparticle in 1:length(Positions), otherparton in 1:dims[4]

        parton_ID = (mover_id-1)*dims[4]+j
        newUC = new_location[3]+(j-1)*dims[3] #the parton UC ID
        oldUC = old_location[3]+(j-1)*dims[3]
        
        if otherparticle!=mover_id
            ndx=mod(new_location[1]-Positions[otherparticle][1]-1,dims[1])+1
            ndy=mod(new_location[2]-Positions[otherparticle][2]-1,dims[2])+1

            odx=mod(old_location[1]-Positions[otherparticle][1]-1,dims[1])+1
            ody=mod(old_location[2]-Positions[otherparticle][2]-1,dims[2])+1

            deltas[(otherparticle-1)*dims[4]+otherparton,j]=g_funct[ndx,ndy,newUC,(otherparton-1)*dims[3]+Positions[otherparticle][3]]-g_funct[odx,ody,oldUC,(otherparton-1)*dims[3]+Positions[otherparticle][3]]

        else
            # special treatment to not mess up the elements that get updated more times. Only update half the times
            if otherparton<j # if ==, then it's the diagonal element anyway which remains zero!
                # set dx=0, dy=0 BUT USE THE NEW UNITCELL POSITION!
                deltas[(otherparticle-1)*dims[4]+otherparton,j]=g_funct[dims[1],dims[2],newUC,(otherparton-1)*dims[3]+new_location[3]]-g_funct[dims[1],dims[2],oldUC,(otherparton-1)*dims[3]+old_location[3]]
            end
        end
    end


    # now compute the Bt ginv B...
    btginvb=zeros(ComplexF64,(2*r,2*r))

    # this is the only O(N^2) step...
    btginvb[1:r,1:r]=transpose(deltas)*old_g_inverse*deltas
        
    first_one = (mover_id-1)*dims[4]+1
    last_one = mover_id*dims[4] 
    
    btginvb[r+1:2*r,r+1:2*r]=old_g_inverse[first_one:last_one,first_one:last_one]
    # need to do the off-diagonal ones, INCLUDE the C^{-1} TERM!
    btginvb[1:r,r+1:2*r]=transpose(deltas)*old_g_inverse[:,first_one:last_one]+I # adding the identity from the C^{-1}
    btginvb[1+r:2*r,1:r]=-transpose(btginvb[1:r,r+1:2*r])

    cinvpf = 1
    if mod(r,4)==2 || mod(r,4)==3
        cinvpf=-1
    end

    # B = zeros(ComplexF64,(length(Positions)*dims[4],2*r))
    # B[:,1:r]=deltas

    # for j in 1:r
    #     B[(mover_id-1)*dims[4]+j,r+j]=1
    # end

    # need to do this -transpose because numerics..

    return pfaffian(0.5*btginvb-0.5*transpose(btginvb))*cinvpf#, B*kron([0 -1;1 0],Matrix(I,r,r))*transpose(B)
end


function update_inverse(mover_id,new_location,old_g_inverse,g_funct,Positions,dims)
    # could do similarly to the above - might be faster in the end...
    old_location = Positions[mover_id]
    r = dims[4] # number of partons...
    # start by finding the delta vectors
    deltas = zeros(ComplexF64,(length(Positions)*dims[4],r))
    
    for j in 1:dims[4],otherparticle in 1:length(Positions), otherparton in 1:dims[4]

        parton_ID = (mover_id-1)*dims[4]+j
        newUC = new_location[3]+(j-1)*dims[3] #the parton UC ID
        oldUC = old_location[3]+(j-1)*dims[3]
        
        if otherparticle!=mover_id
            ndx=mod(new_location[1]-Positions[otherparticle][1]-1,dims[1])+1
            ndy=mod(new_location[2]-Positions[otherparticle][2]-1,dims[2])+1

            odx=mod(old_location[1]-Positions[otherparticle][1]-1,dims[1])+1
            ody=mod(old_location[2]-Positions[otherparticle][2]-1,dims[2])+1

            deltas[(otherparticle-1)*dims[4]+otherparton,j]=g_funct[ndx,ndy,newUC,(otherparton-1)*dims[3]+Positions[otherparticle][3]]-g_funct[odx,ody,oldUC,(otherparton-1)*dims[3]+Positions[otherparticle][3]]

        else
            # special treatment to not mess up the elements that get updated more times. Only update half the times
            if otherparton<j # if ==, then it's the diagonal element anyway which remains zero!
                # set dx=0, dy=0 BUT USE THE NEW UNITCELL POSITION!
                deltas[(otherparticle-1)*dims[4]+otherparton,j]=g_funct[dims[1],dims[2],newUC,(otherparton-1)*dims[3]+new_location[3]]-g_funct[dims[1],dims[2],oldUC,(otherparton-1)*dims[3]+old_location[3]]
            end
        end
    end

    # now compute the Bt ginv B...
    btginvb=zeros(ComplexF64,(2*r,2*r))

    # this is the only O(N^2) step...
    btginvb[1:r,1:r]=transpose(deltas)*old_g_inverse*deltas
        
    first_one = (mover_id-1)*dims[4]+1
    last_one = mover_id*dims[4] 
    
    btginvb[r+1:2*r,r+1:2*r]=old_g_inverse[first_one:last_one,first_one:last_one]
    # need to do the off-diagonal ones, INCLUDE the C^{-1} TERM!
    btginvb[1:r,r+1:2*r]=transpose(deltas)*old_g_inverse[:,first_one:last_one]+I # adding the identity from the C^{-1}
    btginvb[1+r:2*r,1:r]=-transpose(btginvb[1:r,r+1:2*r])


    # create the bigger B matrix
    bmat = zeros(ComplexF64,(length(Positions)*dims[4],2*r))
    bmat[:,1:r]=deltas
    for j in 1:r
        bmat[(mover_id-1)*dims[4]+j,r+j]=1
    end
    # now what you need is this matrix btginvb inverted
    return old_g_inverse-old_g_inverse*bmat*inv(btginvb)*transpose(bmat)*old_g_inverse
end


# now check this:

# 1. Initialize random g_funct, random positions
# 2. Then check

# reasonable-ish
# dims=[4,10,4,2]

# g_funct = randn(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4]))
# function antisymmetrise_g_f(gfun)
#     antisym_g = zeros(ComplexF64,(dims[1],dims[2],dims[3]*dims[4],dims[3]*dims[4]))
    
#     for xval in 1:dims[1],yval in 1:dims[2], p1val in 1:dims[3]*dims[4], p2val in 1:dims[3]*dims[4]
#         minusX = mod(-xval-1,dims[1])+1
#         minusY = mod(-yval-1,dims[2])+1 
#         antisym_g[xval,yval,p1val,p2val] = 0.5*(gfun[xval,yval,p1val,p2val] - gfun[minusX,minusY,p2val,p1val])
#     end
#     return antisym_g
# end
# g_funct=antisymmetrise_g_f(g_funct)/sqrt(dims[1]*dims[2]);
# filling_fraction=1;

# function get_some_positions(X,Y,Nparticles)
#     RMAT = rand(1:dims[3],(Nparticles,3))
#     Positions = [RMAT[i,:] for i in 1:size(RMAT,1)]

#     for pn in 1:Nparticles
#         val = pn/filling_fraction
#         Positions[pn][1]=floor(Int64,(val-0.999)/Y)+1
#         Positions[pn][2]=val%Y+1
#     end
#     return Positions
# end

# Pos = get_some_positions(dims[1],dims[2],dims[1]*dims[2]);


# include("WF_computation.jl")
# pf,gmat,ginv=get_wf_g_inv(Pos,g_funct,dims) #same as the other one, but only does the pfafian


# mover_id = 2
# new_pos = [4,1,2]

# newFULLPOS=deepcopy(Pos)
# newFULLPOS[mover_id]=new_pos

# println("Proper ratio: $(get_just_pfaffian(newFULLPOS,g_funct,dims)/get_just_pfaffian(Pos,g_funct,dims))")


# npf,newgmat,ngi = get_wf_g_inv(newFULLPOS,g_funct,dims)
# properdiffmat= newgmat-gmat

# myratio = update_pfaffian(mover_id,new_pos,ginv,g_funct,Pos,dims);
# println("My ratio: $(myratio)")


# proper_inverse = get_g_inv(newFULLPOS,g_funct,dims);
# my_inveres = update_inverse(mover_id,new_pos,ginv,g_funct,Pos,dims);

# @show  maximum(abs.(proper_inverse-my_inveres));