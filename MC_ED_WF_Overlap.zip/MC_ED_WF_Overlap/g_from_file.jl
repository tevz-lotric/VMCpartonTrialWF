using DataFrames
using CSV

function read_g_from_file(filename,nr_partons,nr_ucs)
    gdf= select(DataFrame(CSV.File(filename)), Not("Index"))

    all_columns = DataFrames.names(gdf)
    all_columns = all_columns[length.(all_columns).>4] # filter out the "X" and "Y" columns...


    Nx=maximum(gdf[!,:X])
    Ny=maximum(gdf[!,:Y])


    dims = [Nx,Ny,nr_ucs,nr_partons]

    g_real = zeros(ComplexF64,(Nx,Ny,nr_ucs*nr_partons,nr_ucs*nr_partons))

    for p1 in 1:nr_partons, p2 in 1:nr_partons, uc1 in 1:nr_ucs, uc2 in 1:nr_ucs, rX in 1:Nx, rY in 1:Ny
        column_name="P$(p1)_UC$(uc1)_-_P$(p2)_UC$(uc2)"

        row_id=(rX-1)*Ny+rY
        # check that you have the right row
        if gdf[row_id,:X]!=rX || gdf[row_id,:Y]!=rY
            println("Row mismatch in reading g dataframe :(")
        end

        g_real[rX,rY,(p1-1)*nr_ucs+uc1,(p2-1)*nr_ucs+uc2]=parse(ComplexF64,gdf[row_id,column_name])
    end
    return g_real
end

function read_g_from_file_S(filename,nr_partons,nr_ucs)
    gdf= select(DataFrame(CSV.File(filename)), Not("Index"))

    all_columns = DataFrames.names(gdf)
    all_columns = all_columns[length.(all_columns).>4] # filter out the "X" and "Y" columns...


    Nx=maximum(gdf[!,:X])
    Ny=maximum(gdf[!,:Y])


    dims = [Nx,Ny,nr_ucs,nr_partons]

    g_real = zeros(ComplexF64,(Nx,Ny,nr_ucs*nr_partons,nr_ucs*nr_partons))

    for p1 in 1:nr_partons, p2 in 1:nr_partons, uc1 in 1:nr_ucs, uc2 in 1:nr_ucs, rX in 1:Nx, rY in 1:Ny
        column_name="P$(p1)_UC$(uc1)_S_1-_P$(p2)_UC$(uc2)_S_1"

        row_id=(rX-1)*Ny+rY
        # check that you have the right row
        if gdf[row_id,:X]!=rX || gdf[row_id,:Y]!=rY
            println("Row mismatch in reading g dataframe :(")
        end

        g_real[rX,rY,(p1-1)*nr_ucs+uc1,(p2-1)*nr_ucs+uc2]=parse(ComplexF64,gdf[row_id,column_name])
    end
    return g_real
end