include("ED_amplitude.jl")


include("WF_computation.jl")
include("linear_alg_lib.jl")

include("EDWF_hamiltonian.jl")


using ProgressMeter

# sample according to the ED Wavefunction!!
function MC_sample_EDWF(NR_RUNS,NR_WARMUP,initial_positions,ED_WF_CALL,dims,hopping_terms,interaction_terms) # the last argument should be a list of functions [f1,f2,...] where f: positions -> amplitude

    Pos = initial_positions
    L = length(Pos)

    currPsi = ED_WF_CALL(Pos)

    cum_v_en = 0.0
    cum_hop_en = 0.0+0.0*im

    curr_v_en = 0.0
    curr_hop_en = 0.0+0.0*im

    NR_CUMULATED = 0

    USE_OLD_VALS = false

    for ind in 1:(NR_RUNS+NR_WARMUP)
        if !USE_OLD_VALS
            # need to compute POTENTIAL ENERGY, ...
            curr_v_en = full_interaction_HAM(Pos,interaction_terms,dims)
            curr_hop_en = full_hop_ham(Pos,currPsi,ED_WF_CALL,hopping_terms,dims)
        end

        #cumulate if Psi is nonzero nd you have done enough warmup...
        if !iszero(currPsi) && ind>NR_WARMUP
            cum_v_en+=curr_v_en
            cum_hop_en+=curr_hop_en
            NR_CUMULATED+=1
        end

        # now decide on a move, do it MAYBE.
        mover_identity = rand(1:L)

        Dx=rand(-2:2)
        Dy=rand(-2:2)

        newID = rand(1:dims[3])
        
        # to ensure it is not the same as before...

        while (abs(Dx)<0.5 && abs(Dy)<0.5 && abs(newID-Pos[mover_identity][3])<0.5)
            Dx=rand(-2:2)
            Dy=rand(-2:2)

            newID = rand(1:dims[3])
        end

        newX = mod(Pos[mover_identity][1]+Dx-1,dims[1])+1
        newY = mod(Pos[mover_identity][2]+Dy-1,dims[2])+1

        newPos = deepcopy(Pos)
        newPos[mover_identity]=[newX,newY,newID]

        fullratio=abs(ED_WF_CALL(newPos)/currPsi)^2

        if isnan(fullratio) # if currPsi was zero...
            fullratio=1
        end

        if rand()<fullratio
            # make the move
            USE_OLD_VALS=false # obviously need to compute now
            Pos[mover_identity]=[newX,newY,newID] # UPDATE POS FIRST TO GET USE THE NEW ONE
            currPsi = ED_WF_CALL(Pos)
        else
            # no move, so just remember that to not wast time re-computing
            USE_OLD_VALS = true
        end
    end
    
    return NR_CUMULATED, cum_v_en,cum_hop_en, Pos
end