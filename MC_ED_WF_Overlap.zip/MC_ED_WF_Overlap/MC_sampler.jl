include("WF_computation.jl")
include("linear_alg_lib.jl")

using Distributed

using ProgressMeter

# Given current wavefunction parameters and some initial position,
# sample Monte Carlo and return the objects of interest for the optimizer.
# also return the position where you end up...
@everywhere function MC_sample(NR_RUNS,NR_WARMUP,initial_positions,g_function,dims,comparing_WF_functions;pfaffian_scale_factor=1) # the last argument should be a list of functions [f1,f2,...] where f: positions -> amplitude

    L = length(initial_positions)

    NrCumulants = length(comparing_WF_functions)

    # keep it as a vector to be able to do the 'S' inversion sensibly.
    ratioCum = zeros(ComplexF64,NrCumulants)
    absSqRC =zeros(ComplexF64,NrCumulants)
    PSIMAGCUM=0
    
    Pos = initial_positions

    currRatio = zeros(ComplexF64,NrCumulants)
    currAbsSqR = zeros(ComplexF64,NrCumulants)

    g_matrix_inverse = zeros(ComplexF64,(L*dims[4],L*dims[4]))
    g_mat = zeros(ComplexF64,(L*dims[4],L*dims[4]))


    # if you did NOT make a move!
    USE_OLD_VALS = false 


    # only start cumulating AFTER you reach a nonzero psi
    NR_CUMULATED = 0

    
    # do the first inverse now already as later on you always do it AFTER the move...
    currPsi,gmat,g_matrix_inverse=get_wf_g_inv(Pos,g_function,dims,scale_factor=pfaffian_scale_factor)

    for ind in 1:(NR_RUNS+NR_WARMUP)
        if !USE_OLD_VALS
            for j in 1:NrCumulants
                otherPsi = comparing_WF_functions[j](Pos)
                currRatio[j]=otherPsi/currPsi
                currAbsSqR[j] = abs(otherPsi/currPsi)^2
            end
        end

        #cumulate if Psi is nonzero nd you have done enough warmup...
        if !iszero(currPsi) && ind>NR_WARMUP
            ratioCum+=currRatio
            absSqRC+=currAbsSqR
            PSIMAGCUM+=abs(currPsi)
            NR_CUMULATED+=1
        end

        # now decide on a move, do it MAYBE.
        mover_identity = rand(1:L)

        Dx=rand(-2:2)
        Dy=rand(-2:2)

        newID = rand(1:dims[3])
        
        # to ensure it is not the same as before...

        while (abs(Dx)<0.5 && abs(Dy)<0.5 && abs(newID-Pos[mover_identity][3])<0.5)
            Dx=rand(-2:2)
            Dy=rand(-2:2)

            newID = rand(1:dims[3])
        end

        newX = mod(Pos[mover_identity][1]+Dx-1,dims[1])+1
        newY = mod(Pos[mover_identity][2]+Dy-1,dims[2])+1

        fullratio=abs(update_pfaffian(mover_identity,[newX,newY,newID],g_matrix_inverse,g_function,Pos,dims))^2

        if isnan(fullratio) # if currPsi was zero...
            fullratio=1
        end

        if rand()<fullratio
            # make the move
            USE_OLD_VALS=false # obviously need to compute now
            Pos[mover_identity]=[newX,newY,newID] # UPDATE POS FIRST TO GET USE THE NEW ONE
            currPsi,gmat,g_matrix_inverse=get_wf_g_inv(Pos,g_function,dims,scale_factor=pfaffian_scale_factor)
            

        else
            # no move, so just remember that to not wast time re-computing
            USE_OLD_VALS = true
        end
    end
    
    return NR_CUMULATED, PSIMAGCUM, ratioCum, absSqRC, Pos
end