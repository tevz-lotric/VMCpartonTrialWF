using BenchmarkTools
using Random


# this encodes the FULL PARTICLE Hamiltonian ----------------------------------------------------------------------

# should be a list of moves: each move is [Ending_IND,Starting_IND,EndX-StartX,EndY-StartY, AMPLITUDE]
# sorted by STARTING_IND
# note the amplitude should include the overall (-1) factor in front!

# the valid moves now have only two valid i
function get_valid_moves_hex(t,tprime,tpp)

    valid_moves = [
        Dict("End" => 1, "Start" => 1, "Dx" => 0, "Dy" => 1,"amplitude"=>-conj(tprime)), #OK
        
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => 0,"amplitude"=>-t), #OK
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => 1,"amplitude"=>-tpp), #OK
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => -1,"amplitude"=>-tpp), #OK

        Dict("End" => 2, "Start" => 1, "Dx" => -2, "Dy" => 1,"amplitude"=>-tpp), #OK

        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => 0,"amplitude"=>-tprime), #OK
        Dict("End" => 1, "Start" => 1, "Dx" => -1, "Dy" => 1,"amplitude"=>-tprime), #OK

        
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => 0,"amplitude"=>-t), #OK
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => 1,"amplitude"=>-t), #OK

        Dict("End" => 2, "Start" => 2, "Dx" => 0, "Dy" => 1,"amplitude"=>-tprime), #OK

        Dict("End" => 2, "Start" => 2, "Dx" => -1, "Dy" => 1,"amplitude"=>-conj(tprime)), #OK
        Dict("End" => 2, "Start" => 2, "Dx" => -1, "Dy" => 0,"amplitude"=>-tprime), #OK
    ]

    # Now ensure this is hermitian [ADD REVERSE MOVES!]
    L = length(valid_moves)
    for moveID in 1:L #have to do this, otherwise you get an infinite loop...
        move = valid_moves[moveID]
        reverseDir = Dict("Start"=>move["End"],"End"=>move["Start"],"Dx"=>-move["Dx"],"Dy"=>-move["Dy"],"amplitude"=>conj(move["amplitude"]))
        #print(reverseDir)
        push!(valid_moves,reverseDir)
    end

    sort!(valid_moves,by=x->x["End"]) # sort by the end of the move...

    return valid_moves, 2 # the 2 means two sites per uc end
end


function get_valid_moves_checkerboard(t,t1p,t2p,tpp)
    # from [42] with a (-1) sign to make flatband the bottom!

    valid_moves = [
        # first NN
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => 0,"amplitude"=>conj(t))
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => 0,"amplitude"=>t)
        Dict("End" => 2, "Start" => 1, "Dx" => 0, "Dy" => -1,"amplitude"=>t)
        Dict("End" => 2, "Start" => 1, "Dx" => -1, "Dy" => -1,"amplitude"=>conj(t))
        # this is NNN        
        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => 0,"amplitude"=>t1p)
        Dict("End" => 1, "Start" => 1, "Dx" => 0, "Dy" => 1,"amplitude"=>t2p)
        Dict("End" => 2, "Start" => 2, "Dx" => 1, "Dy" => 0,"amplitude"=>t2p)
        Dict("End" => 2, "Start" => 2, "Dx" => 0, "Dy" => 1,"amplitude"=>t1p)
        # finally NNNN 
        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => 1,"amplitude"=>tpp)
        Dict("End" => 1, "Start" => 1, "Dx" => 1, "Dy" => -1,"amplitude"=>tpp)
        Dict("End" => 2, "Start" => 2, "Dx" => 1, "Dy" => 1,"amplitude"=>tpp)
        Dict("End" => 2, "Start" => 2, "Dx" => 1, "Dy" => -1,"amplitude"=>tpp)
    ]

    # Now ensure this is hermitian [ADD REVERSE MOVES!]
    L = length(valid_moves)
    for moveID in 1:L #have to do this, otherwise you get an infinite loop...
        move = valid_moves[moveID]
        reverseDir = Dict("Start"=>move["End"],"End"=>move["Start"],"Dx"=>-move["Dx"],"Dy"=>-move["Dy"],"amplitude"=>conj(move["amplitude"]))
        #print(reverseDir)
        push!(valid_moves,reverseDir)
    end

    sort!(valid_moves,by=x->x["End"]) # sort by the end of the move...

    return valid_moves, 2 # the 2 means two sites per uc 
end

# END of full particle Hamiltonian definition ----------------------------------------------------------------------


# Should return (H_j PSI) / PSI  for j = ID_of_mover!!
function ham_move_one(ID_of_mover,positions,base_psi,ED_WF_CALL,validMoves_p,dims) #the scale factor tells you what to do in pf.
    Hamvalue = 0.0 + 0.0*im
    pos_in_UC = positions[ID_of_mover][3]
    origX = positions[ID_of_mover][1]
    origY = positions[ID_of_mover][2]

    validMoves, sites_per_uc = validMoves_p

    for move in validMoves
        if pos_in_UC==move["End"] 

            currUC=move["Start"]
            currX=origX-round(Int64,move["Dx"]) # - sign as the otherpos is start and positions is end...
            currY=origY-round(Int64,move["Dy"])

            currX = mod(currX-1,dims[1])+1
            currY = mod(currY-1,dims[2])+1

            # now get the relative WF value...
            positions[ID_of_mover]=[currX,currY,currUC]
            Hamvalue+=move["amplitude"]*ED_WF_CALL(positions)
            positions[ID_of_mover]=[origX,origY,pos_in_UC]
        end
    end
    # finally, re-normalize this so that the typical magnitude is independent of how many terms you are taking!
    return Hamvalue/base_psi
end

# a fast H on Psi. Note that this one returns (Hamiltonian on Psi ) / Hamiltonian 
function full_hop_ham(positions,base_psi,ED_WF_CALL,validMoves_p,dims)
    
    allHams = map(x->ham_move_one(x,positions,base_psi,ED_WF_CALL,validMoves_p,dims),1:length(positions))
    # always look at energy per particle... Should not be the biggest deal ever, just a scale factor!
    return sum(allHams)/length(positions)
end

# do function which give the ONE-SIDED interaction terms..

@inline function nicemod(x,M)
    return sign(x)* ( (abs(x)+3*M/2)%M -M/2)
end


# do an interaction one
function full_interaction_HAM(positions::Vector{Vector{Int64}}, interaction_terms_p, dims) # WF doesnt matter here if you assume your Monte Carlo is sampling correctly
    interaction_terms, number_sites_in_UC = interaction_terms_p
    
    # Take both positions, check if their locations are meant to interact, add the interaction strength to the cumulant
    ham_cumulant = 0.0
    
    L = length(positions)

    for a in 1:L, b in 1:L, int in interaction_terms
        diffX = positions[a][1]-positions[b][1]
        diffY = positions[a][2]-positions[b][2]

        startUC = positions[b][3]
        endUC = positions[a][3]
        # now increase the diffs, ie need diffUC to be 1 or 2, the rest of the factor must be added to diffX... 

        diffX = nicemod(diffX,dims[1])
        diffY = nicemod(diffY,dims[2])

        if iszero(diffX-int["dx"]) && iszero(diffY-int["dy"]) && iszero(startUC-int["startIND"]) && iszero(endUC-int["endIND"])
            ham_cumulant+=int["Strength"]
        end
    end
    return ham_cumulant/L # DOUBLE CHECK - IS THIS THE NORMALIZATION YOU WANT?
end

function get_interactions_checkerboard(V1,V2) # MAKE IT ONE-WAY ONLY! FUNCTIOJN ABOVE SYMMETRIZES ANYWAY!
    valid_moves = [
        Dict("startIND" => 1, "endIND" => 2, "dx" => 0, "dy" => 0,"Strength"=>V1),
        Dict("startIND" => 1, "endIND" => 2, "dx" => -1, "dy" => 0,"Strength"=>V1),
        Dict("startIND" => 1, "endIND" => 2, "dx" => 0, "dy" => -1,"Strength"=>V1),
        Dict("startIND" => 1, "endIND" => 2, "dx" => -1, "dy" => -1,"Strength"=>V1),

        Dict("startIND" => 1, "endIND" => 1, "dx" => 1, "dy" => 0,"Strength"=>V2),
        Dict("startIND" => 1, "endIND" => 1, "dx" => 0, "dy" => 1,"Strength"=>V2),
        Dict("startIND" => 2, "endIND" => 2, "dx" => 1, "dy" => 0,"Strength"=>V2),
        Dict("startIND" => 2, "endIND" => 2, "dx" => 0, "dy" => 1,"Strength"=>V2)
    ]
    number_sites_per_basis = 2
    return valid_moves, number_sites_per_basis
end

function get_interactions_hex(V1,V2) # MAKE IT ONE-WAY ONLY! FUNCTIOJN ABOVE SYMMETRIZES ANYWAY!
    valid_moves = [

        Dict("endIND" => 2, "startIND" => 1, "dx" => 0, "dy" => 0,"Strength"=>V1),
        Dict("endIND" => 2, "startIND" => 1, "dx" => -1, "dy" => 0,"Strength"=>V1),
        Dict("endIND" => 2, "startIND" => 1, "dx" => -1, "dy" => 1,"Strength"=>V1),

        Dict("endIND" => 1, "startIND" => 1, "dx" => 1, "dy" => 0,"Strength"=>V2),
        Dict("endIND" => 1, "startIND" => 1, "dx" => -1, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 1, "startIND" => 1, "dx" => 0, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 2, "startIND" => 2, "dx" => 0, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 2, "startIND" => 2, "dx" => -1, "dy" => 1,"Strength"=>V2),
        Dict("endIND" => 2, "startIND" => 2, "dx" => -1, "dy" => 0,"Strength"=>V2)
    ]
    number_sites_per_basis = 2
    return valid_moves, number_sites_per_basis
end
