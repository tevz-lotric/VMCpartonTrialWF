include("ID_from_POS.jl")
using DataFrames
using CSV
using .Threads
using ThreadTools
using BenchmarkTools
using Permutations

# k00_hilbert_space_file = "9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_0_ky_0.txt"
# k00_WF_file = "9partEDWFs/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_0_ky_0.0.vec"

# k30_hilbert_space_file = "9partEDWFs/HilbertSpaces/HS_boson_gutzwiller_p_9_x_6_y_3_kx_3_ky_0.txt"
# k30_WF_file = "9partEDWFs/WFs/bosons_realspace_gutzwiller_checkerboardlattice_n_9_ns_36_x_6_y_3_u_0.000000_v_0.000000_t1_1.000000_t2_0.292893_tpp_0.207107_gx_0.000000_gy_0.000000_kx_3_ky_0.0.vec"


function read_ED_WF_from_files(hilbert_space_file,WF_file;compact_fermi = false)
    ks = parse.(Int64,[split(split(WF_file,"_kx_")[2],"_ky_")[1],split(split(WF_file,"_ky_")[2],".")[1]])

    # first read line-by-line the .txt
    f=CSV.File(hilbert_space_file,header=false,delim=",")

    offset = 0
    if compact_fermi
        offset = 1
    end

    HILBERT_SPACE_DIMENSION=parse(Int64,String(f[6-offset].Column1))

    # now can compute the important array
    state_id_of_row = zeros(UInt64,HILBERT_SPACE_DIMENSION)

    if compact_fermi
        state_id_of_row=map(x->parse(UInt64,String(x.Column1)),f[6:end])
    else
        state_id_of_row=map(x->parse(UInt64,split(String(x.Column1)," ")[end]),f[7:end])
    end
    # check that the dimensions match up
    if length(state_id_of_row)!=HILBERT_SPACE_DIMENSION
        println("H.S. dimsnsion does not match the file $hilbert_space_file.")
    end

    HILBERT_SPACE_DIMENSION=length(state_id_of_row) # might as well...

    # ok now read the vector file.
    wf = open(WF_file)
    HSDIM = convert(Int64,read(wf, UInt32))

    if HSDIM!=HILBERT_SPACE_DIMENSION
        println("Hilbert Space dimension of $hilbert_space_file does not match with $WF_file")
    end

    #now need to read the following 2*HSDIM lines...
    fullvec =Array{Float64}(undef,2*HSDIM) 
    read!(wf,fullvec)

    # finally can combine the two into a dictionary
    dict = Dict()

    for id in 1:HSDIM
        dict[state_id_of_row[id]]=fullvec[(2*id)-1]+im*fullvec[2*id]
    end

    return dict,ks
end

# wfk00 = read_ED_WF_from_files(k00_hilbert_space_file,k00_WF_file)
# wfk30 = read_ED_WF_from_files(k30_hilbert_space_file,k30_WF_file)

# need:
# A function taking in position inputs, using ID_from_POS to find the ID + shift and applying the shift according to total momentum

function EDWF_amplitude(positions,dims,ed_wf;FERMI_STATISTICS = false) # ed_wf is a pair (dict, [kx,ky])
    wfdict,momentum_vector = ed_wf

    # find the binary
    binary_state, shifts = get_canonical_ID(positions,dims)

    base_amplitude = 0
    if haskey(wfdict,binary_state)
        base_amplitude = wfdict[binary_state]
    end

    # now using the shift compute the amplitude!
    phases = []
    for shift in shifts
        dx = shift[1]*momentum_vector[1]/dims[1]
        dy = shift[2]*momentum_vector[2]/dims[2]

        push!(phases,exp(im*2*π * (dx+dy)))
    end

    mp = phases[1]
    
    if maximum(abs.(phases.-mp))>1e-5 && FERMI_STATISTICS==false # a momentum-invalid state. More complicated for fermions so just dont bother there
        base_amplitude = 0
    end

    # now IF FERMIONS, GIVE SOME SIGN... Hope this is right...
    
    statsign = 1
    posshift = shifts[1]
    if FERMI_STATISTICS    
        # trivial attempt, clearly wrong...
        posnumbers = getindex.(positions,3).-1 + mod.(getindex.(positions,2).-1 .-posshift[2],dims[2])*dims[3] + mod.(getindex.(positions,1).-1 .-posshift[1],dims[1])*dims[2]*dims[3]
        statsign=  sign(Permutation(sortperm(posnumbers)))
        # my attemt at copying diagham...

    end

    return statsign*base_amplitude*mp
end


# # try it out: need to generate positions of 9 particles on a 6x3 grid...
# dims = [6,3,2]
# nP = 9

# Positions = []
# for j in 1:nP
#     ganw = false
#     while !ganw
#         newPos = [rand(1:dims[1]),rand(1:dims[2]),rand(1:dims[3])]
        
#         different = true
#         for op in Positions
#             if op == newPos
#                 different=false
#             end
#         end

#         if different
#             ganw=true
#             push!(Positions,newPos)
#         end
#     end
# end

# println("For 00 WF: $(EDWF_amplitude(Positions,dims,wfk00))")
# println("For 30 WF: $(EDWF_amplitude(Positions,dims,wfk30))")