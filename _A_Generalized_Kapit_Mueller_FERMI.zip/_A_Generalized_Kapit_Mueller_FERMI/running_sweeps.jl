include("quencher_FUNCTION.jl")



for Vm in [0.005,0.01]#,0.1]
    for nparticles in -1:-1:-4#[-2,-4]
        flux_groups_list = []

        for Xflux in (-3*abs(nparticles)):1:3*(abs(nparticles)),Yflux in (-3*abs(nparticles)):1:(3*abs(nparticles))
            part1flux = Xflux
            part2flux = Yflux-Xflux
            part3flux = -Yflux

            pfs = [part1flux,part2flux,part3flux]
            if all(pfs.>-abs(nparticles)-0.01) 
                push!(flux_groups_list,sort(pfs))
            end
        end
        to_care_about = unique(flux_groups_list)

        for partonfluxes in to_care_about
            Xflux = partonfluxes[1]
            Yflux = -partonfluxes[3]

            tp = (partonfluxes.-nparticles)[end:-1:1]
            println("Parton hole numbers: $tp")

            run_with_data(nparticles,Xflux,Yflux,Vm)

        end            
    end
end
